#include<iostream>
#include<algorithm>
#include<queue>
using namespace std;
int n, m, k, a[500005], t, ans, p, tt, val;
signed main() {
	ios::sync_with_stdio(0);
	cin >> t;
	while (t--) {
		cin >> n >> m >> k; ans = 0; tt = 0;
		priority_queue<int>pq;
		for (int i = 1; i <= n; ++i) {
			cin >> a[i];
			if (a[i] != a[i - 1]) pq.push(tt), tt = 1, ans++;
			else tt++;
		}
		pq.push(tt);
		for (int i = 1; i <= m; ++i) {
			val = pq.top(); pq.pop();
			if (val <= 1) break; val -= 2;
			ans += 1 + (val > 0);
			if (val > 1) pq.push(val);
		}
		cout << ans << endl;
	}
}