#include<bits/stdc++.h>
using namespace std;
#define int long long
int t, a, b, c, d, ans;
inline int dec() {
	if (c < a || d < b) return -5e18;
	if (a == c) {
		int rc = (d - b);
		if (rc % a) return -5e18;
		d = b;
		return rc / a;
	}
	if (b == d) {
		int rc = (c - a);
		if (rc % b) return -5e18;
		c = a;
		return rc / b;
	}
	if (d > c) {
		int dec = min((d - c) / c, (d - b) / c);
		ans += dec; d -= dec * c;
		if (d == b) return 0;
		if (d == c) return -5e18;
		d -= c; ans++;
	}
	else {
		int dec = min((c - d) / d, (c - a) / d);
		ans += dec; c -= dec * d;
		if (c == a) return 0;
		if (d == c) return -5e18;
		c -= d; ans++;
	}
	return 0;
}
signed main() {
	ios::sync_with_stdio(0);
	for (cin >> t; t; t--) {
		cin >> a >> b >> c >> d; ans = 0;
		while ((a != c || b != d) && ans >= 0) ans += dec();
		cout << (ans >= 0 ? ans : -1) << endl;
	}
}