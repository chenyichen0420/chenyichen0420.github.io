#include<bits/stdc++.h>
using namespace std;
int n, m, t;
struct node { int l, r, v; }h[50005];
struct tree_array {
	int v[50005];
	inline static int lb(int v) { return v & ~v + 1; }
	inline void add(int p) {
		do v[p]++; while ((p += lb(p)) <= n);
	}
	inline int que(int p) {
		int t = 0; do t += v[p];
		while (p -= lb(p)); return t;
	}
}ta;
int main() {
	ios::sync_with_stdio(0);
	for (cin >> t; t; t--) {
		cin >> m; n = 50000;
		memset(ta.v, 0, sizeof ta.v);
		for (int i = 1; i <= m; ++i)
			cin >> h[i].l >> h[i].r >> h[i].v;
		sort(h + 1, h + m + 1, [&](const node& l, const node& r) {
			return l.r != r.r ? l.r<r.r : l.l>r.l;
			});
		for (int i = 1, s, e, v; i <= m; ++i) {
			s = h[i].l; e = h[i].r;
			v = ta.que(e) - ta.que(s - 1);
			if (v >= h[i].v) continue;
			for (int j = e; j >= s && v != h[i].v; --j)
				if (ta.que(j) - ta.que(j - 1) == 0)
					ta.add(j), v++;
		}
		cout << ta.que(n) << endl;
	}
}