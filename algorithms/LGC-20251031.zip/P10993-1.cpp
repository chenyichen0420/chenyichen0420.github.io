#include<bits/stdc++.h>
using namespace std;
int a,v;
int main(){
	cin>>a; a*=37; v=a%10;
	while(a)
		if(a%10!=v){
			cout<<"No\n"; return 0;
		}
		else a/=10;
	cout<<"Yes\n";
} 