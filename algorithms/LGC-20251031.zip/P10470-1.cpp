#include<bits/stdc++.h>
using namespace std;
int t, n, m, rans[1000005]; string s;
int tri[1000005][26], k;
inline void pluswd(string s) {
	int sz = s.size(), np = 0, tmp;
	for (int i = 0;i < sz;++i) {
		if (s[i] <= 'z') tmp = s[i] - 'a';
		else tmp = s[i] - 'A' + 26;
		if (!tri[np][tmp]) tri[np][tmp] = ++k;
		np = tri[np][tmp];
	}
	rans[np]++;
}
inline int gas(string s) {
	int sz = s.size(), np = 0, tmp, ran = 0;
	for (int i = 0;i < sz;++i) {
		if (s[i] <= 'z') tmp = s[i] - 'a';
		else tmp = s[i] - 'A' + 26;
		if (!tri[np][tmp]) return ran;
		np = tri[np][tmp]; ran += rans[np];
	}
	return ran;
}
int main() {
	ios::sync_with_stdio(false);
	t = 1;
	while (t--) {
		cin >> n >> m;
		//memset(tri, 0, sizeof tri);
		while (n--)
			cin >> s,
			pluswd(s);
		while (m--)
			cin >> s,
			cout << gas(s) << endl;
	}
	return 0;
}