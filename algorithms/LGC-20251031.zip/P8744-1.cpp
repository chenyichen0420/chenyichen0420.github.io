#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr int mod = 1e9 + 7;
vector<int>son[100005]; int n, dp[100005];
inline void dfs(int p, int f) {
	for (int sp : son[p])
		dfs(sp, p), dp[p] = max(dp[p], dp[sp]);
	dp[p] += son[p].size();
}
signed main() {
	ios::sync_with_stdio(0); cin >> n;
	for (int i = 2, p; i <= n; ++i)
		cin >> p, son[p].emplace_back(i);
	dfs(1, 0); cout << dp[1] << endl;
}