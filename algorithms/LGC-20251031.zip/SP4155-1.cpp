#include<bits/stdc++.h>
using namespace std;
constexpr int sz = 3e4 + 5;
struct IO {
#define mxsz (1 << 21)
	char buf[mxsz], * p1, * p2;
	char pbuf[mxsz], * pp; bool acc[128];
	IO() : p1(buf), p2(buf), pp(pbuf) {}
	~IO() { fwrite(pbuf, 1, pp - pbuf, stdout); }
	inline char gc() {
		if (p1 == p2) p2 = (p1 = buf) + fread(buf, 1, mxsz, stdin);
		return p1 == p2 ? ' ' : *p1++;
	}
	inline void setacc(const char* c) { while (*c) acc[*c++] = 1; }
	inline char getc() { char c; while (!acc[c = gc()]); return c; }
#ifndef sipt
	inline int read() {
		int r = 0; char c = gc(); while (c < '0' || c>'9') c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return r;
	}
#else
	inline int read() {
		int r = 0; char c = gc(); bool rev = 0;
		while (c < '0' || c>'9') rev |= (c == '-'), c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return rev ? ~r + 1 : r;
	}
#endif
	inline void push(const char& c) {
		if (pp - pbuf == mxsz) fwrite(pbuf, 1, mxsz, stdout), pp = pbuf;
		*pp++ = c;
	}
	inline void write(int x) {
		static char sta[22]; int top = 0;
		do sta[top++] = x % 10, x /= 10; while (x);
		while (top) push(sta[--top] ^ 48);
	}
	inline void write(int x, char opc) {
#ifdef sopt
		if (x < 0) push('-'), x = ~x + 1;
#endif
		write(x), push(opc);
	}
	inline void puts(const char* c) { while (*c) push(*c++); }
} io;
int n, m, a[sz];
class tree {
	//变量：sn(子节点),f(父节点),v(子树异或值),r(反转标记)
	int sn[sz][2], f[sz], r[sz], v[sz];
	//是不是右儿子
	inline bool bel(int p) { return sn[f[p]][0] != p; }
	//更新答案(v)
	inline void pup(int p) { v[p] = v[sn[p][0]] + v[sn[p][1]] + a[p]; }
	//not - root = nrt
	inline bool nrt(int p) { return sn[f[p]][bel(p)] == p; }
	//rev：reverse
	inline void rev(int p) { swap(sn[p][0], sn[p][1]); r[p] ^= 1; }
	//pud：下传反转标记
	inline void pud(int p) {
		if (r[p]) {
			if (sn[p][0]) rev(sn[p][0]);
			if (sn[p][1]) rev(sn[p][1]);
			r[p] = 0;
		}
	}
	//dnr：down - rotate(下传链顶到自己的翻转标记)
	inline void dnr(int p) { if (nrt(p)) dnr(f[p]); pud(p); }
	/*
	rot：最根本的旋转操作，但是和普通的 splay 有区别
	1. 要判断 f[p] 是不是当前 splay 的根，不是才能更新 f[f[p]] 的子节点信息
	2. 要判断 sn[p][...] 的存在性，存在才更新 f[sn[p][...]]，否则 f[0] 会被改
	*/
	inline void rot(int p) {
		int fp = f[p], pp = f[fp]; 
		bool t = bel(p); int sp = sn[p][!t];
		if (nrt(fp)) sn[pp][bel(fp)] = p;
		//错误1：nrt(fp) 而非 pp
		sn[p][!t] = fp; sn[fp][t] = sp;
		if (sp) f[sp] = fp; f[fp] = p; f[p] = pp;
		pup(fp); pup(p);
	}
	/*
	splay：最基本的操作，但是也有不同，更像文艺 splay
	要下传从 splay 树的树根开始的反转懒标记，但是只反转这条链的。
	*/
	inline void splay(int p) {
		dnr(p); int fp;
		for (; fp = f[p], nrt(p); rot(p))
			if (nrt(fp)) rot(bel(p) ^ bel(fp) ? p : fp);
	}
	/*
	access：LCT 的根本操作
	作用：在原树中将 p 到“树根”的边置为实边
	方式：
	1. 将 p 转到当前 splay 树的根
	2. p 作为父亲认前一个节点 ap 互认父子
	3. 更新 p 点答案，p 跃到其父节点上。
	4. 循环直至 p 变为 0 (虚无令使)。
	解释：如果 2 中 p 有右节点，那么置右节点只会将原有的一条实边变为虚边。
	这时候，因为认父不认子，修边完成。
	*/
	inline void access(int p) {
		for (int sp = 0; p; sp = p, p = f[p])
			splay(p), sn[p][1] = sp, pup(p);
	}
	/*
	mkrt：make_root
	作用：将 p 变为原树的根节点
	方式：打通路径，旋至顶点，交换儿子
	交换儿子干了什么呢？
	access 会使他成为 splay 树中最深的节点。
	上去了之后他会成为中序最后，但是交换完左右就成为中序最前了。
	根据其特殊性质，他变相地成为了原树的根节点。
	*/
	inline void mkrt(int p) { access(p); splay(p); rev(p); }
	/*
	fnrt：find_root
	作用：找这个原树的根节点
	方式：打通路径，旋至顶点，走左子树，重新旋顶，返回答案。
	*/
	inline int fnrt(int p){
		access(p); splay(p);
		while (pud(p), sn[p][0]) p = sn[p][0];
		splay(p); return p;
	}
	/*
	exlnk：extract_link
	作用：将两个点的路径提取为一个 splay
	方式：提为树根，打通路径，旋至树顶
	access 链底，mkrt 必为链顶。
	*/
	inline void exlnk(int l, int r) { mkrt(l); access(r); splay(r); }
	//断开边：先作为根，判断有边后双向断边即可。（此题无用）
	inline void cut(int l, int r) {
		if (mkrt(l), fnrt(r) == l && f[r] == l && !sn[r][0])
			f[r] = sn[l][1] = 0, pup(l);
	}
public:
	inline bool conn(int l, int r) { return fnrt(l) == fnrt(r); }
	//连接边：先作为根，判断不同树后单向认父（虚边）即可。
	inline void link(int l, int r) { (mkrt(l), fnrt(r) != l) && (f[l] = r); }
	inline int que(int l, int r) { exlnk(l, r); return v[r]; }
	inline void chg(int p, int v) { splay(p); a[p] = v; pup(p); }
}re;
int main() {
	ios::sync_with_stdio(0); char op;
	cin.tie(0); cout.tie(0); n = io.read();
	for (int i = 1; i <= n; ++i) a[i] = io.read();
	m = io.read(); io.setacc("epb");
	for (int i = 1, l, r; i <= m; ++i)
		if (op = io.getc(), l = io.read(), r = io.read(), op == 'e')
			if (!re.conn(l, r)) io.puts("impossible\n");
			else io.write(re.que(l, r), '\n');
		else if (op == 'p') re.chg(l, r);
		else if (re.conn(l, r)) io.puts("no\n");
		else re.link(l, r), io.puts("yes\n");
}