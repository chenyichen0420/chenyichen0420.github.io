#include<bits/stdc++.h>
using namespace std;
#define int long long
const int mod = 1e9 + 7;
int n, m, jc[1000005], ny[1000005], ans;
inline int qpow(int a, int b, int mod = ::mod) {
	int ret = 1;
	for (;b;b >>= 1, a = a * a % mod)
		(b & 1) && (ret = ret * a % mod);
	return ret;
}
inline int cvl(int n, int m) {
	return jc[n] * ny[m] % mod * ny[n - m] % mod;
}
inline int calc(int v) {
	return cvl(n, v) * cvl(v, m) % mod * (qpow(2, qpow(2, n - v, mod - 1)) - 1) % mod;
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m; jc[0] = 1;
	for (int i = 1;i <= 1000000;++i) jc[i] = jc[i - 1] * i % mod;
	ny[1000000] = qpow(jc[1000000], mod - 2);
	for (int i = 1000000;i >= 1;i--) ny[i - 1] = ny[i] * i % mod;
	for (int i = m;i <= n;++i)
		ans = (ans + qpow(-1, i - m & 1) * calc(i) + mod) % mod;
	cout << ans << endl;
}