#include<bits/stdc++.h>
using namespace std;
#define int long long
string s1,s2,s3; vector<char>v;
unordered_set<char>s;
vector<int>vl;
unordered_map<char,int>vtv;
inline bool check(){
	if(!vtv[s1[0]]||!vtv[s2[0]]||!vtv[s3[0]]) return 0;
	int v1(0),v2(0),v3(0);
	for(char c:s1) v1=v1*10+vtv[c];
	for(char c:s2) v2=v2*10+vtv[c];
	for(char c:s3) v3=v3*10+vtv[c];
	if(v1+v2==v3) cout<<v1<<'\n'<<v2<<'\n'<<v3<<'\n';
	return (v1+v2==v3);
}
signed main(){
	cin>>s1>>s2>>s3;
	for(char c:s1) s.insert(c);
	for(char c:s2) s.insert(c);
	for(char c:s3) s.insert(c);
	if(s.size()>10) return puts("UNSOLVABLE"),0;
	for(unordered_set<char>::iterator it
		=s.begin();it!=s.end();++it) v.push_back(*it);
	for(int i=0;i!=10;++i) vl.emplace_back(i);
	do{
		for(int i=0;i!=v.size();++i) vtv[v[i]]=vl[i];
		if(check()) return 0;
	}while(next_permutation(vl.begin(),vl.end()));
	return puts("UNSOLVABLE"),0;
} 