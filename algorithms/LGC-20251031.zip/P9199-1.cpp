#include<bits/stdc++.h>
using  namespace std;
int n, m, a[5005], np, ans; bool hs[5005];
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m;
	for (int i = 1; i <= n; ++i) cin >> a[i];
	if (!m) {
		for (int i = 1; i <= n; ++i)
			if (a[i]) ans++;
		cout << ans << endl; return 0;
	}
	for (int i = 1; i <= n; ++i) {
		hs[a[i]] = 1;
		if (a[i] == m) {
			memset(hs, 0, sizeof hs);
			np=0; continue;
		}
		while (hs[np]) np++;
		if (np == m) {
			ans++; np = 0;
			memset(hs, 0, sizeof hs);
		}
	}
	cout << ans << endl;
	return 0;
}