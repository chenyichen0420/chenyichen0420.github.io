#include<bits/stdc++.h>
using namespace std;
#define int long long
int t, n, h[200005], a[200005], v[200005], p[200005], l[200005], r[200005], al, ar;
signed main() {
	ios::sync_with_stdio(0);
	for (cin >> t; t; t--) {
		cin >> n; ar = 1e9 + 7; al = 0;
		for (int i = 1; i <= n; ++i) cin >> h[i];
		for (int i = 1; i <= n; ++i) cin >> a[i];
		for (int i = 1; i <= n; ++i)
			cin >> v[i], p[n - v[i] - 1] = i;
		for (int i = 1; i != n; ++i) {
			int lp = p[i - 1], rp = p[i];
			//a[rp]>a[lp]
			if (h[rp] > h[lp]) {
				l[i] = 0;
				if (a[rp] >= a[lp]) r[i] = 1e9 + 7;
				else r[i] = floor(double(h[rp] - h[lp] - 1) / (a[lp] - a[rp]));
			}
			else {
				if (a[rp] <= a[lp]) l[i] = r[i] = -1;
				else r[i] = 1e9 + 7, l[i] = ceil(double(h[lp] - h[rp] + 1) / (a[rp] - a[lp]));
			}
			al = max(al, l[i]); ar = min(ar, r[i]);
		}
		if (ar < al) cout << -1 << endl;
		else cout << al << endl;
	}
}
/*
1
3
4 8 5
3 1 3
2 1 0
0 1 2
*/