#include<bits/stdc++.h>
using namespace std;
#define int long long
vector<pair<int, int>>ed[305];
int n, a[305], b[305], dp[305][305][3], s[305], rd[305][305];
inline void tmin(int& l, const int r) { (l > r) && (l = r); }
signed main() {
	ios::sync_with_stdio(0); cin >> n;
	memset(dp, 0x0f, sizeof dp);
	for (int i = 1; i <= n; ++i)
		cin >> a[i], s[i] = a[i] + s[i - 1];
	for (int i = 1; i <= n; ++i)
		cin >> b[i], dp[i][i][b[i]] = 0;
	for (int i = 1; i <= n; ++i)
#define r (l + i - 1)
		for (int l = 1; r <= n; ++l)
			for (int p = l; p != r; ++p) {
				tmin(dp[l][r][0], dp[l][p][2] + dp[p + 1][r][2] + s[r] - s[l - 1]);
				tmin(dp[l][r][1], dp[l][p][0] + dp[p + 1][r][0] + s[r] - s[l - 1]);
				tmin(dp[l][r][2], dp[l][p][1] + dp[p + 1][r][1] + s[r] - s[l - 1]);
			}
	for (int i = 1; i <= n; ++i)
		for (int j = i; j <= n; ++j)
			if (min({ dp[i][j][0],dp[i][j][1],dp[i][j][2] }) <= 1e12)
				ed[i].emplace_back(j + 1, min({ dp[i][j][0],dp[i][j][1],dp[i][j][2] }));
	memset(rd, 0x0f, sizeof rd); rd[1][0] = 0;
	for (int i = 1; i <= n; ++i)
		for (int j = 0; j <= n; ++j)
			if (rd[i][j] <= 1e12)
				for (const auto& v : ed[i])
					tmin(rd[v.first][j + 1], rd[i][j] + v.second);
	for (int i = 1; i <= n; ++i)
		if (rd[n + 1][i] <= 1e12) {
			cout << i << " " << rd[n + 1][i] << endl;
			return 0;
		}
}