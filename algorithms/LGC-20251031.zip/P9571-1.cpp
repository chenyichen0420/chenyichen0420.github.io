#include<bits/stdc++.h>
using  namespace std;
constexpr int ad = 1e5;
int n, lc; map<int, int>ln[200005], kn; set<int>hs;
signed main() {
	ios::sync_with_stdio(0);
	cin >> n;
	for (int i = 1, o, l, r; i <= n; ++i)
		if (cin >> o >> l >> r, o == 1)
			ln[l + ad][r]++, lc++, kn[l]++, hs.emplace(l);
		else if (o == 2) cout << lc - kn[l] << endl;
		else {
			for (const auto& v : hs)
				if (v != l) {
					for (const auto& s : ln[v + ad]) lc -= s.second;
					kn[v] = 0; ln[v + ad].clear();
				}
			hs.clear(); hs.emplace(l);
			lc -= ln[l + ad][r]; kn[l] -= ln[l + ad][r]; ln[l + ad][r] = 0;
		}
	return 0;
}