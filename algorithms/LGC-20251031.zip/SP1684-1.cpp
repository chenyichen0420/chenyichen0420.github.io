#include<bits/stdc++.h>
using namespace std;
#define sipt //signed-input
#define sopt //signed-output
struct IO {
#define mxsz (1 << 20)
	char buf[mxsz], * p1, * p2;
	char pbuf[mxsz], * pp;
	IO() : p1(buf), p2(buf), pp(pbuf) {}
	~IO() { fwrite(pbuf, 1, pp - pbuf, stdout); }
	inline char gc() {
		if (p1 == p2) p2 = (p1 = buf) + fread(buf, 1, mxsz, stdin);
		return p1 == p2 ? ' ' : *p1++;
	}
#ifndef sipt
	inline int read() {
		int r = 0; char c = gc(); while (c < '0' || c>'9') c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return r;
	}
#else
	inline int read() {
		int r = 0; char c = gc(); bool rev = 0;
		while (c < '0' || c>'9') rev |= (c == '-'), c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return rev ? ~r + 1 : r;
	}
#endif
	inline void push(const char& c) {
		if (pp - pbuf == mxsz) fwrite(pbuf, 1, mxsz, stdout), pp = pbuf;
		*pp++ = c;
	}
	inline void write(int x) {
		static char sta[22]; int top = 0;
		do sta[top++] = x % 10, x /= 10; while (x);
		while (top) push(sta[--top] ^ 48);
	}
	inline void write(int x, char opc) {
#ifdef sopt
		if (x < 0) push('-'), x = ~x + 1;
#endif
		write(x), push(opc);
	}
} io;
int n, a[100005], l[1550], r[1550], miv[1550][1550], sz, blk[100005], m;
unordered_map<int, int>um; int cnttt, v[100005], bls, lp, rp;
vector<int>app[100005], qur; int t[100005]; bool vis[100005];
inline void sol(const int& vl) {
	memset(t, 0, sizeof t); int id = 0;
	for (int i = l[vl]; i <= n; ++i) {
		if (++t[a[i]] > t[id] || t[a[i]] == t[id] && v[id] > v[a[i]])
			id = a[i];
		miv[vl][blk[i]] = id;
	}
}
inline int ser(const int& l, const int& r, const int& v) {
	return
		upper_bound(app[v].begin(), app[v].end(), r) -
		lower_bound(app[v].begin(), app[v].end(), l);
}
signed main() {
	ios::sync_with_stdio(0);
	while (n = io.read()) {
		cnttt = 0; um.clear(); m = io.read(); 
		for (int i = 1;i <= n;++i) app[i].clear();
		sz = pow(n, 1.0 / 2.698); bls = n / sz + (n % sz != 0);
		for (int i = 1; i <= n; ++i) {
			if (!um[a[i] = io.read()])
				um[a[i]] = ++cnttt,
				v[cnttt] = a[i];
			a[i] = um[a[i]];
			app[a[i]].emplace_back(i);
		}
		for (int i = 1; i <= bls; ++i)
			l[i] = r[i - 1] + 1, r[i] = i * sz;
		r[bls] = n; v[0] = 0x3f3f3f3f;
		for (int i = 1; i <= bls; ++i)
			for (int j = l[i]; j <= r[i]; ++j)
				blk[j] = i;
		for (int i = 1; i <= bls; ++i) sol(i);
		for (int i = 1, la = 0; i <= m; ++i) {
			lp = io.read(); rp = io.read();
			int tmp = miv[blk[lp] + 1][blk[rp] - 1];
			int mxcn = ser(lp, rp, tmp), ans = tmp;
			vis[tmp] = 1; qur.emplace_back(tmp);
			for (int i = lp; i <= r[blk[lp]]; ++i)
				if (!vis[a[i]]) {
					vis[a[i]] = 1; tmp = ser(lp, rp, a[i]); qur.push_back(a[i]);
					if (tmp > mxcn || tmp == mxcn && v[a[i]] < v[ans])
						ans = a[i], mxcn = tmp;
				}
			for (int i = l[blk[rp]]; i <= rp; ++i)
				if (!vis[a[i]]) {
					vis[a[i]] = 1; tmp = ser(lp, rp, a[i]); qur.push_back(a[i]);
					if (tmp > mxcn || tmp == mxcn && v[a[i]] < v[ans])
						ans = a[i], mxcn = tmp;
				}
			io.write(mxcn, '\n');
			while (qur.size()) vis[qur.back()] = 0, qur.pop_back();
		}
	}
	return 0;
}