#include<iostream>
using namespace std;
int main() {
	long long n, k; cin >> n >> k;
	while (n != 1) {
		if (k == 0) break;
		k--; n++;
		if (n % 3 == 0) n /= 3;
	}
	if (k == 0) cout << n << endl;
	else {
		if (k % 2) cout << 2 << endl;
		else cout << 1 << endl;
	}
	return 0;
}