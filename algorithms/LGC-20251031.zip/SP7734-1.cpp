#include<bits/stdc++.h>
#include<ctime>
using namespace std;
#ifdef _WIN32
#define getchar_unlocked getchar
#define putchar_unlocked putchar
#endif
inline int read() {
	int r = 0; char c = getchar_unlocked();
	while (c < '0' || c>'9') c = getchar_unlocked();
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar_unlocked();
	return r;
}
inline void write(int x) {
	if (x > 9) write(x / 10);
	putchar_unlocked(x % 10 ^ 48);
	return;
}
inline void writi(int args) {
	write(args); putchar_unlocked(32);
}
mt19937 mt(time(0));
struct FHQ {
	struct node {
		int v, sz, rv, sp[2]; bool fp;
	}re[100005]; int cnt;
	inline void pud(int p) {
		swap(re[p].sp[0], re[p].sp[1]);
		if (re[p].sp[0]) re[re[p].sp[0]].fp ^= 1;
		if (re[p].sp[1]) re[re[p].sp[1]].fp ^= 1;
		re[p].fp = 0;
	}
	inline void pup(int p) {
		re[p].sz = re[re[p].sp[0]].sz + re[re[p].sp[1]].sz + 1;
	}
	inline int newn(int v) {
		cnt++; re[cnt].v = v; re[cnt].sz = 1; re[cnt].rv = mt();
		return cnt;
	}
	inline int merge(int l, int r) {
		if (!l || !r) return l | r;
		if (re[l].rv < re[r].rv) {
			if (re[l].fp) pud(l);
			re[l].sp[1] = merge(re[l].sp[1], r);
			pup(l); return l;
		}
		else {
			if (re[r].fp) pud(r);
			re[r].sp[0] = merge(l, re[r].sp[0]);
			pup(r); return r;
		}
	}
	inline void blyat(int p, int v, int& l, int& r) {
		if (!p) return void(l = r = 0); if (re[p].fp) pud(p);
		if (re[re[p].sp[0]].sz < v) l = p, blyat(re[p].sp[1], v - re[re[p].sp[0]].sz - 1, re[p].sp[1], r);
		else r = p, blyat(re[p].sp[0], v, l, re[p].sp[0]); pup(p);
	}
	inline void solve(int p) {
		if (!p) return; if (re[p].fp) pud(p);
		solve(re[p].sp[0]);
		writi(re[p].v);
		solve(re[p].sp[1]);
	}
}fhq;
int n, m, l, r, rt, r1, r2, r3;
signed main() {
	n = read(); m = read();
	for (int i = 1; i <= n; ++i)
		rt = fhq.merge(rt, fhq.newn(i));
	while (m--) {
		l = read(); r = read();
		fhq.blyat(rt, l - 1, r1, r2);
		fhq.blyat(r2, r - l + 1, r2, r3);
		fhq.re[r2].fp ^= 1;
		rt = fhq.merge(r1, fhq.merge(r2, r3));
	}
	fhq.solve(rt); return 0;
}