#include<bits/stdc++.h>
using namespace std;
struct IO {
#define mxsz (1 << 21)
	char buf[mxsz], * p1, * p2;
	char pbuf[mxsz], * pp; bool acc[128];
	IO() : p1(buf), p2(buf), pp(pbuf) {}
	~IO() { fwrite(pbuf, 1, pp - pbuf, stdout); }
	inline void setacc(const char* c) {
		while (*c) acc[*c++] = 1;
	}
	inline char gc() {
		if (p1 == p2) p2 = (p1 = buf) + fread(buf, 1, mxsz, stdin);
		return p1 == p2 ? ' ' : *p1++;
	}
	inline char getc() {
		char c; while (!acc[c = gc()]); return c;
	}
#ifndef sipt
	inline int read() {
		int r = 0; char c = gc(); while (c < '0' || c>'9') c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return r;
	}
#else
	inline int read() {
		int r = 0; char c = gc(); bool rev = 0;
		while (c < '0' || c>'9') rev |= (c == '-'), c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return rev ? ~r + 1 : r;
	}
#endif
	inline void push(const char& c) {
		if (pp - pbuf == mxsz) fwrite(pbuf, 1, mxsz, stdout), pp = pbuf;
		*pp++ = c;
	}
	inline void puts(const char* c) {
		while (*c) push(*c++);
	}
	inline void write(int x) {
		static char sta[22]; int top = 0;
		do sta[top++] = x % 10, x /= 10; while (x);
		while (top) push(sta[--top] ^ 48);
	}
	inline void write(int x, char opc) {
#ifdef sopt
		if (x < 0) push('-'), x = ~x + 1;
#endif
		write(x), push(opc);
	}
} io;
int t, n, m; char mp[12][12];
int id[12][12][12][12][12][12][2], cnt;
inline bool ok(int a, int b, int u, int v, int x, int y) {
	if (a<1 || a>n || b<1 || b>m || mp[a][b] == '#') return 0;
	if (u<1 || u>n || v<1 || v>m || mp[u][v] == '#') return 0;
	if (x<1 || x>n || y<1 || y>m || mp[x][y] == '#') return 0;
	return (u != x || v != y);
}
inline void genid() {
	for (int a = 1; a <= n; ++a)
		for (int b = 1; b <= m; ++b)
			for (int u = 1; u <= n; ++u)
				for (int v = 1; v <= m; ++v)
					for (int x = 1; x <= n; ++x)
						for (int y = 1; y <= m; ++y)
							if (ok(a, b, u, v, x, y))
								id[a][b][u][v][x][y][0] = ++cnt,
								id[a][b][u][v][x][y][1] = ++cnt;
}
constexpr int dx[] = { -1,0,0,1 }, dy[] = { 0,1,-1,0 };
struct node { int p, nt; }e[2000005 << 3]; int ecn, h[2000005];
char ep[2000005], rd[2000005]; int ans[2000005], sp;
inline void adde(int l, int r) {
	rd[r]++; e[++ecn].nt = h[l]; e[ecn].p = r; h[l] = ecn;
}
inline void genmap() {
	for (int a = 1; a <= n; ++a)
		for (int b = 1; b <= m; ++b)
			for (int u = 1; u <= n; ++u)
				for (int v = 1; v <= m; ++v)
					for (int x = 1; x <= n; ++x)
						for (int y = 1; y <= m; ++y)
							if (ok(a, b, u, v, x, y)) {
								int nd = id[a][b][u][v][x][y][0];
								for (int k = 0; k != 4; ++k)
									if (ok(a, b, u, v, x + dx[k], y + dy[k]))
										adde(id[a][b][u][v][x + dx[k]][y + dy[k]][1], nd);
								for (int k = 0; k != 4; ++k)
									if (ok(a, b, u + dx[k], v + dy[k], x, y))
										adde(id[a][b][u + dx[k]][v + dy[k]][x][y][1], nd);
								for (int k = 0; k != 3; ++k)
									if (ok(a + dx[k], b + dy[k], u, v, x, y))
										adde(id[a + dx[k]][b + dy[k]][u][v][x][y][0], nd ^ 1);
								//这里是按照 1 红动，0 黑动写的
								if (a == 1) { //黑子/黑动必胜态
									ep[nd] = 2; ep[nd ^ 1] = 3;
									ans[nd] = ans[nd ^ 1] = 0;
								}
								else if (a == u && b == v) //棋子重叠(黑-红1),谁动谁输
									ep[nd] = ep[nd ^ 1] = 2,
									ans[nd] = ans[nd ^ 1] = 0;
								else if (a == x && b == y) //棋子重叠(黑-红2),谁动谁输
									ep[nd] = ep[nd ^ 1] = 2,
									ans[nd] = ans[nd ^ 1] = 0;
								else {
									if (!rd[nd]) ep[nd] = 2, ans[nd] = 0; //无后继,谁动谁输
									if (!rd[nd ^ 1]) ep[nd ^ 1] = 2, ans[nd ^ 1] = 0;
								}
							}
}
inline void gensp() {
	int xb, yb, xr1, yr1, xr2, yr2;
	xb = yb = xr1 = yr1 = xr2 = yr2 = 0;
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j)
			if (mp[i][j] == 'X') xb = i, yb = j;
			else if (mp[i][j] == 'O')
				if (xr1) xr2 = i, yr2 = j;
				else xr1 = i, yr1 = j;
	sp = id[xb][yb][xr1][yr1][xr2][yr2][0];
}
struct qeueu {
	int l, r, v[2000005];
	inline void reset() { l = 1; r = 0; }
	inline int front()const { return v[l]; }
	inline int size()const { return r - l + 1; }
	inline void emplace(int t) { v[++r] = t; }
	inline void pop() { l++; }
}q;
inline bool bfs() {
	int tp; q.reset();
	for (int i = 1; i <= cnt; ++i)
		if (ep[i]) q.emplace(i);
	while (q.size()) {
		tp = q.front(); q.pop();
		if (tp == sp) return 0;
		for (int i = h[tp], sp; i; i = e[i].nt)
			if (!ep[sp = e[i].p])
				if (!(ep[tp] & 1))
					ep[sp] = 3, q.emplace(sp),
					ans[sp] = ans[tp] + 1;
				else if (!--rd[sp])
					ep[sp] = 2, q.emplace(sp),
					ans[sp] = ans[tp] + 1;
	}
	return 1;
}
inline void clean() {
	memset(h, 0, sizeof h);
	memset(rd, 0, sizeof rd);
	memset(ep, 0, sizeof ep);
	memset(ans, 0, sizeof ans);
	memset(id, 0, sizeof id);
	cnt = 1; ecn = 0;
}
signed main() {
	ios::sync_with_stdio(0); io.setacc(".#OX");
	for (io.read(), t = io.read(); t; t--) {
		n = io.read(); m = io.read();
		for (int i = 1; i <= n; ++i)
			for (int j = 1; j <= m; ++j)
				mp[i][j] = io.getc();
		clean(); genid(); genmap(); gensp();
		if (bfs()) io.puts("Tie\n");
		else if (ep[sp] & 1)
			io.puts("Red "), io.write(ans[sp], '\n');
		else io.puts("Black "), io.write(ans[sp], '\n');
	}
} //the future passed away, for it was always you