#include<bits/stdc++.h>
using namespace std;
int main(){
	ios::sync_with_stdio(false);
    string s; cin>>s;
    for(int i=0;i<s.size();++i) if(s[i]>='a'&&s[i]<='z') s[i]-='a'-'A';
    cout<<s<<endl; return 0;
} 