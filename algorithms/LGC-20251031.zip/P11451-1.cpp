#include<bits/stdc++.h>
using namespace std;
#define int long long
int dp[200005][2], n, m, mx[200005][2];
char s[200005]; vector<pair<int,int>>moo;
inline int get(int x, int y) {
	for (int i = 3; i <= n; ++i) {
		int s1 = s[i - 2] == x, s2 = s[i - 1] == y, s3 = s[i] == y;
		dp[i][0] = mx[i - 3][0] + (s1 && s2 && s3);
		dp[i][1] = mx[i - 3][1] + (s1 && s2 && s3);
		dp[i][1] = max(dp[i][1], mx[i - 3][0] + (s1 + s2 + s3 >= 2));
		mx[i][1] = max(mx[i - 1][1], dp[i][1]);
		mx[i][0] = max(mx[i - 1][0], dp[i][0]);
	}
	return mx[n][1];
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m >> (s + 1);
	for (int i = 1; i <= n; ++i)
		s[i] = s[i] - 'a' + 1;
	for (int i = 1; i <= 26; ++i)
		for (int j = 1; j <= 26; ++j)
			if (i != j&&get(i,j)>=m)
				moo.emplace_back(make_pair(i, j));
	cout << moo.size() << endl;
	for (pair<int, int>& p : moo)
		putchar(p.first + 'a' - 1),
		putchar(p.second + 'a' - 1),
		putchar(p.second + 'a' - 1),
		putchar('\n');
}
/*
hack:
8 2
baacaacc
*/