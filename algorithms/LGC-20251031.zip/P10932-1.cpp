#include<bits/stdc++.h>
using namespace std;
struct node {
	int p, v, id;
	node(int pi = 0, int vi = 0, int ii = 0) :
		p(pi), v(vi), id(ii) { }
}; vector<node>son[10005], nsn[20005];
int n, m, k, cnt, dfn[20005], low[20005], cln[20005], dp[20005];
int f[20005][16], v[20005], fe[20005], d[20005], vcn, dis[20005], fl, fr;
inline void tmin(int& l, int r) { (l > r) && (l = r); }
inline void mkcir(int ep, int sp, int sv) {
	for (int p = sp; p != ep; p = f[p][0]) d[p] = sv, sv += v[p];
	d[ep] = cln[ep] = sv; nsn[ep].emplace_back(++vcn);
	for (int p = sp; p != ep; p = f[p][0])
		cln[p] = sv, nsn[vcn].emplace_back(p, min(d[p], sv - d[p]));
}
inline void tarjan(int p, int id) {
	dfn[p] = low[p] = ++cnt;
	for (const node& sp : son[p])
		if (!dfn[sp.p]) {
			f[sp.p][0] = p; v[sp.p] = sp.v; fe[sp.p] = sp.id;
			tarjan(sp.p, sp.id), tmin(low[p], low[sp.p]);
			if (dfn[p] < low[sp.p]) nsn[p].emplace_back(sp.p, sp.v);
		}
		else if (id != sp.id) tmin(low[p], dfn[sp.p]);
	for (const node& sp : son[p])
		if (dfn[p] < dfn[sp.p] && fe[sp.p] != sp.id)
			mkcir(p, sp.p, sp.v);
}
inline void dfs(int p, int fa) {
	f[p][0] = fa; dp[p] = dp[fa] + 1;
	for (int i = 1;i <= 15;++i)
		f[p][i] = f[f[p][i - 1]][i - 1];
	for (const node& sp : nsn[p])
		dis[sp.p] = dis[p] + sp.v, dfs(sp.p, p);
}
inline int lca(int l, int r) {
	if (dp[l] < dp[r]) swap(l, r);
	for (int i = 15;i >= 0;i--)
		(dp[f[l][i]] >= dp[r]) && (l = f[l][i]);
	if (l == r) return l;
	for (int i = 15;i >= 0;i--)
		(f[l][i] != f[r][i]) && (l = f[l][i], r = f[r][i]);
	return fl = l, fr = r, f[l][0];
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m >> k; vcn = n;
	for (int i = 1, l, r, v;i <= m;++i)
		cin >> l >> r >> v,
		son[l].emplace_back(r, v, i),
		son[r].emplace_back(l, v, i);
	tarjan(1, 0); dfs(1, 0);
	for (int i = 1, l, r, la;i <= k;++i)
		if (cin >> l >> r, (la = lca(l, r)) > n) {
			int lln = abs(d[fl] - d[fr]), rln = cln[fl] - lln;
			cout << (dis[l] - dis[fl]) + (dis[r] - dis[fr]) + min(lln, rln) << endl;
		}
		else cout << dis[l] + dis[r] - dis[la] * 2 << endl;
}