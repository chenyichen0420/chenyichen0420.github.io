#include<bits/stdc++.h>
using namespace std;
struct node{
	int pos,len;
	node(int pi=0,int li=0){
		pos=pi,len=li;
	}
	friend bool operator<(node l,node r){
		return l.len>r.len;
	}
}tmp;
int t,n,m,a,b,x,y,z; vector<node>son[100005]; bool vis[100005];
priority_queue<node>pq;
int main(){
	ios::sync_with_stdio(false);
	cin>>t;
	while(t--){
		cin>>n>>m>>a>>b;
		for(int i=1;i<=n;++i) son[i].clear(),vis[i]=0;
		for(int i=1;i<=m;++i)
			cin>>x>>y>>z,
			son[x].push_back(node(y,z)),
			son[y].push_back(node(x,z));
		while(!pq.empty()) pq.pop();
		pq.push(node(a,0)); bool cn=1;
		while(!pq.empty()){
			tmp=pq.top(); pq.pop();
			if(vis[tmp.pos]) continue;
			vis[tmp.pos]=1;
			if(tmp.pos==b){
				cout<<tmp.len<<endl;
				cn=0; break;
			}
			for(int i=0;i<son[tmp.pos].size();++i)
				if(!vis[son[tmp.pos][i].pos]) pq.push(node(son[tmp.pos][i].pos,tmp.len+son[tmp.pos][i].len));
		}
		if(cn) cout<<"NONE\n";
	}
	return 0;
}