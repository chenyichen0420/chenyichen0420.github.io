#include<iostream>
#include<cmath>
#include<algorithm>
#include<vector>
#include<cstring>
using namespace std;
#define int long long
int n, k, t; pair<int, int>pr[101];
signed main() {
	ios::sync_with_stdio(0);
	cin >> t;
	while (t--) {
		cin >> n >> k;
		for (int i = 1; i <= n; ++i) {
			cin >> pr[i].first >> pr[i].second;
		}
		sort(pr + 1, pr + n + 1);
		int np = 0, nt = 0; bool can = 1;
		for (int i = 1; i <= n; ++i) {
			nt += (pr[i].first - np) * k;
			np = pr[i].first;
			if (nt < pr[i].second) {
				can = 0;
				break;
			}
			nt -= pr[i].second;
		}
		if (can) cout << "Yes\n";
		else cout << "No\n";
	}
	return 0;
}