#include<bits/stdc++.h>
using namespace std;
#define int unsigned
int n, m, t[200005], lp, a, rt, ans, rp, ap, rt2;
vector<pair<int, int>>dt;
struct seg_tree {
	struct node { int ls, rs, v, t; }re[200005 * 128]; int id;
	inline void pud(int p, int l, int r) {
		if (!re[p].t) return; int t = re[p].t; re[p].t = 0;
		if (!re[p].ls) re[p].ls = ++id;
		if (!re[p].rs) re[p].rs = ++id;
		int mid = l + r >> 1;
		re[re[p].ls].t += t; re[re[p].rs].t += t;
		re[re[p].ls].v += t * (mid - l + 1);
		re[re[p].rs].v += t * (r - mid);
	}
	inline void pup(int p) {
		re[p].v = re[re[p].ls].v + re[re[p].rs].v;
	}
	inline void ins(int cl, int cr, int l, int r, int& p) {
		if (!p) p = ++id;
		if (cl <= l && cr >= r)
			return re[p].v += (r - l + 1), void(re[p].t++);
		pud(p, l, r); int mid = l + r >> 1;
		if (cl <= mid) ins(cl, cr, l, mid, re[p].ls);
		if (cr > mid) ins(cl, cr, mid + 1, r, re[p].rs);
		pup(p);
	}
	inline int que(int ql, int qr, int l, int r, int p) {
		if (ql <= l && qr >= r || !p) return re[p].v;
		int ret = 0, mid = l + r >> 1; pud(p, l, r);
		if (ql <= mid) ret += que(ql, qr, l, mid, re[p].ls);
		if (qr > mid) ret += que(ql, qr, mid + 1, r, re[p].rs);
		return ret;
	}
}sgt, sgt2;
signed main() {
	ios::sync_with_stdio(0); cin >> n >> m;
	for (int i = 1; i <= n; ++i) cin >> t[i];
	for (int i = 1; i <= n; ++i)
		dt.emplace_back(t[i], 1),
		dt.emplace_back(t[i] + m, -1);
	sort(dt.begin(), dt.end());
	for (const auto& v : dt) {
		if (a == 2 && lp != v.first) sgt.ins(lp, v.first - 1, 1, 2e9, rt);
		if (a == 1 && rp != v.first) sgt2.ins(rp, v.first - 1, 1, 2e9, rt2), ap += v.first - rp;
		a += v.second; 
		if (a == 2) lp = v.first;
		if (a == 1) rp = v.first;
	}
	cerr << ap << endl;
	for (int i = 1; i <= n; ++i)
		ans = max(ans, ap + m +
			sgt.que(t[i], t[i] + m - 1, 1, 2e9, rt)
			- sgt2.que(t[i], t[i] + m - 1, 1, 2e9, rt2));
	cout << ans << endl;
}