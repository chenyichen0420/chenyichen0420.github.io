#include <bits/stdc++.h>
using namespace std;
#define int unsigned long long
int n, ph[1000005], ps[1000005], ans;; signed p[1000005], pc; bool isp[1000005];
signed main() {
	ios::sync_with_stdio(0); ph[1] = 1;
	for (int i = 2; i <= 1e6; ++i) {
		if (!isp[i]) ph[p[++pc] = i] = i - 1;
		for (int j = 1; j <= pc && i * p[j] <= 1e6; ++j) {
			isp[i * p[j]] = 1; ph[i * p[j]] = ph[i] * (p[j] - 1);
			if (i % p[j] == 0) { ph[i * p[j]] += ph[i]; break; }
		}
	}
	for (int i = 1; i <= 1e6; ++i) ps[i] = ps[i - 1] + ph[i];
	while (cin >> n, n) {
		for (int l = 1, r = 0; l <= n; l = r + 1)
			r = n / (n / l), ans += (ps[r] - ps[l - 1]) * (n / l) * (n / l);
		cout << (ans - n * (n + 1) / 2) / 2 << endl; ans = 0;
	}
}