#include<bits/stdc++.h>
using namespace std;
int t,l,r,sm[1000005]; string str=" ";
int main(){
	cin>>t; int val=1;
	while(str.size()<=1000000){
		for(int i=1;i<=val;++i) str+=to_string(val);
		val++;
	}
    for(int i=1;i<=1000000;++i) sm[i]=sm[i-1]+str[i]-'0';
	for(int i=1;i<=t;++i){
		scanf("%d%d",&l,&r);
		printf("%d\n",sm[r]-sm[l-1]);
	} 
	return 0;
}