#include<bits/stdc++.h>
using namespace std;
#define int __int128
int A,B,a,b,t1,t2,tmp,gc,md;
long long t,a_,b_;
inline void exgcd(int a,int b,int &x,int &y){
	if(!b) x=1,y=0,gc=a;
	else exgcd(b,a%b,y,x),y-=a/b*x;
}
inline void solve(){
	exgcd(A,a,t1,t2),
	tmp=b-B;
	if(tmp%gc){
		cout<<-1<<endl;
		exit(0);
	}
	t1=(t1*tmp/gc+a/gc)%(a/gc),
	md=A/__gcd(A,a)*a,
	B=(A*t1+B+md)%md,A=md;
}
signed main(){
	ios::sync_with_stdio(0);
	cin>>t>>a_>>b_,A=a_,B=b_;
	for(int i=1;i<t;++i)
		cin>>a_>>b_,
		a=a_, b=b_,
		solve();
	cout<<(long long)(B%A)<<endl;
	return 0;
}