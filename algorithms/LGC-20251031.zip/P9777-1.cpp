#include<bits/stdc++.h>
using namespace std;
#define int long long
int mod,n,v;
struct mat{
	int v[2][2]={{0,0},{0,0}};
	mat operator*(const mat&nd){
		mat res;
	    for(int i=0;i^2;++i)
    		for(int j=0;j^2;++j)
        		for(int k=0;k^2;++k)
 	        		res.v[i][j]=(res.v[i][j]+v[i][k]*nd.v[k][j])%mod;
  		return res;
	}
}qr,ans;
signed main(){
	cin>>mod>>n>>v;
	if(v==0){
		cout<<2<<endl;
		return 0;
	}
	if(v==1){
		cout<<n%mod<<endl;
		return 0;
	}
	qr.v[0][0]=n;
	qr.v[0][1]=1;
	qr.v[1][0]=-1;
	ans.v[0][0]=(n%mod*n-2)%mod;
	ans.v[0][1]=n%mod;
	v-=2;
	while(v){
		if(v&1) ans=ans*qr;
		qr=qr*qr; v>>=1;
	}
	cout<<(ans.v[0][0]+mod)%mod<<endl;
	return 0;
}