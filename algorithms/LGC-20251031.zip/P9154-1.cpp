#include<iostream>
using namespace std;
#define int long long
inline int cf(int val_) {
	int num = 0, val = val_;
	while (val > 0ll) {
		int tt = val % 3ll;
		if (tt == 1) num++;
		val /= 3ll;
	}
	return num;
}
signed main() {
	int a, t; ios::sync_with_stdio(false);
	cin >> t;
	while (t--) {
		cin >> a; int tmp = cf(a);
		if (a % 3 == 2) cout << "0\n";
		else cout << (1ll << tmp) / ((a % 3ll) + 1ll) << endl;
	}
}