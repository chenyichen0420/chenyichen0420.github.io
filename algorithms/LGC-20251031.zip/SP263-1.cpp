#include<bits/stdc++.h>
using namespace std;
struct IO {
#define mxsz (1 << 21)
	char buf[mxsz], * p1, * p2;
	char pbuf[mxsz], * pp;
	IO() : p1(buf), p2(buf), pp(pbuf) {}
	~IO() { fwrite(pbuf, 1, pp - pbuf, stdout); }
	inline char gc() {
		if (p1 == p2) p2 = (p1 = buf) + fread(buf, 1, mxsz, stdin);
		return p1 == p2 ? ' ' : *p1++;
	}
#ifndef sipt
	inline int read() {
		int r = 0; char c = gc(); while (c < '0' || c>'9') c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return r;
	}
#else
	inline int read() {
		int r = 0; char c = gc(); bool rev = 0;
		while (c < '0' || c>'9') rev |= (c == '-'), c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return rev ? ~r + 1 : r;
	}
#endif
	inline void push(const char& c) {
		if (pp - pbuf == mxsz) fwrite(pbuf, 1, mxsz, stdout), pp = pbuf;
		*pp++ = c;
	}
	inline void write(int x) {
		static char sta[22]; int top = 0;
		do sta[top++] = x % 10, x /= 10; while (x);
		while (top) push(sta[--top] ^ 48);
	}
	inline void write(int x, char opc) {
#ifdef sopt
		if (x < 0) push('-'), x = ~x + 1;
#endif
		write(x), push(opc);
	}
} io;
using has = unsigned long long;
int t, n, mx[1000005], tt; char c[1000005];
constexpr has p = 131, md = 1e9 + 97;
has q[1000005], v[1000005];
inline has hsv(int l, int r) {
	return (v[r] - v[l] * q[r - l] % md + md) % md;
}
signed main() {
	ios::sync_with_stdio(0);
	for (int i = q[0] = 1; i <= 1e6; ++i)
		q[i] = q[i - 1] * p % md;
	for (cin >> t; t; t--) {
		cin >> n >> (c + 1);
		for (int i = 1; i <= n; ++i)
			v[i] = (v[i - 1] * p + c[i]) % md, mx[i] = 0;
		for (int i = 1; i * 2 <= n; ++i) {
			has tc = hsv(0, i);
			for (int j = 2; i * j <= n; ++j) {
				if (hsv((j - 1) * i, i * j) != tc) break;
				else if (!mx[i * j]) mx[i * j] = j;
			}
		}
		cout << "Test case #" << ++tt << endl;
		for (int i = 1; i <= n; ++i)
			if (mx[i]) cout << i << " " << mx[i] << endl;
		cout << endl;
	}
}