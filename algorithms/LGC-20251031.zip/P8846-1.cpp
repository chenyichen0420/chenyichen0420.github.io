#include<iostream>
using namespace std;
int main() {
	int n; cin >> n;
	for (int i = 0; i < 26 && i < n; ++i)printf("%c", (char)('a' + i % 26));
	for (int i = 26; i < n; ++i) printf("b");
	return 0;
}