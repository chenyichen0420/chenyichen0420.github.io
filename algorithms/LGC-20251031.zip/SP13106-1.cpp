#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr int mod = 1e9 + 7;
int n, m, sv, dp[(1ll << 21) + 5], ee[(1ll << 21) + 5], ans;
inline void mad(int& l, const int& r) {
	if ((l += r % mod) >= mod) l -= mod;
}
#ifdef _MSC_VER
#define __builtin_popcount __popcnt
#endif
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m; ee[0] = 1; const int mxv = (1ll << m) - 1;
	for (int i = 1, ct, v; i <= n; ++i, dp[sv ^ mxv]++, sv = 0)
		for (cin >> ct; ct; ct--) cin >> v, sv |= (1ll << v - 1);
	for (int i = 1; i <= 1ll << 21; ++i) ee[i] = (ee[i - 1] << 1) % mod;
	for (int i = 0; i < m; ++i)
		for (int j = 1; j < (1ll << m); ++j)
			if (j & (1ll << i)) mad(dp[j ^ (1ll << i)], dp[j]);
	for (int i = 0; i < (1ll << m); ++i)
		ans += (ee[dp[i]] - 1) * (__builtin_popcount(i) & 1 ? -1 : 1),
		ans = (ans + mod * 2) % mod;
	cout << ans << endl;
	return 0;
}
//私は猫です