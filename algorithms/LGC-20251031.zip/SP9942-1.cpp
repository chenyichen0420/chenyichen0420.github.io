#include<bits/stdc++.h>
using namespace std;
#define int long long
struct node {
	int p, v;
	node(int p = 0, int v = 0) :p(p), v(v) {};
}; vector<node>son[100005];
int t, n, sz[100005], ans;
inline void dfs(int p, int f, int e) {
	sz[p] = 1;
	for (const auto& sp : son[p]) if (sp.p != f)
		dfs(sp.p, p, sp.v), sz[p] += sz[sp.p];
	ans += min(sz[p], n - sz[p]) * 2 * e;
}
signed main() {
	ios::sync_with_stdio(0); cin >> t;
	for (int tt = 1; tt <= t; ++tt) {
		cin >> n; 
		for (int i = 1; i <= n; ++i) son[i].clear();
		for (int i = 1, l, r, v; i != n; ++i)
			cin >> l >> r >> v,
			son[l].emplace_back(r, v),
			son[r].emplace_back(l, v);
		ans = 0; dfs(1, 0, 0);
		cout << "Case #" << tt << ": " << ans << endl;
	}
}