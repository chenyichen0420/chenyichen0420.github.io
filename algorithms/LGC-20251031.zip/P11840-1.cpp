#include<bits/stdc++.h>
using namespace std;
int n, a[1000005], d[1000005], p, ans;
bool vis[1000005]; stack<int> av, va;
inline int dfs(int p) {
	vis[p] = 1; if (!p) return ans = d[p] = 0;
	if (vis[a[p]]) return ans = d[p] = d[a[p]] + 1;
	dfs(a[p]); return d[p] = d[a[p]] + 1;
}
int main() {
	ios::sync_with_stdio(0); cin >> n; vis[0] = 1;
	for (int i = 1; i <= n; ++i) cin >> a[i];
	while (cin >> p) av.emplace(p);
	dfs(av.top()); av.pop(); va.emplace(0);
	while (av.size())
		dfs(av.top()), av.pop(),
		va.emplace(ans);
	while (va.size())
		cout << va.top() << endl, va.pop();
}