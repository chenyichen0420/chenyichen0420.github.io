#include<bits/stdc++.h>
using namespace std;
#define int long long
#define Int __int128
constexpr bool online=0;
string s; int n; char c; Int ans;
struct info{
    int flg,ln,cnt,sm;
}v[10000005]; //sm 表示回文区间内的所有可行区间的 cnt 之和。
inline void write(Int ans){
    if(ans>9) write(ans/10); putchar(ans%10^48);
}
signed main(){
    if(online)
        freopen("namidame.in","r",stdin),
        freopen("namidame.out","w",stdout);
    ios::sync_with_stdio(0); cin>>n; s="!!";
    for(int i=1;i<=n;++i) cin>>c,s+=c,s+="!"; s+='^';
    for(int i=1,r=0,p=0;i<s.size()-1;++i){
        if(i>r){
            //出界，零帧起手
            if(s[i]=='?')
                v[i].cnt=v[i].sm=v[i].flg=1;
            else if(s[i]!='!') v[i].flg=-1;
        }
        else{
            //界内：拷贝截断
            int j=p*2-i; v[i]=v[j];
            while(i+v[i].ln>r){
                int k=j+v[i].ln; v[i].ln--;
                if(v[i].flg>=0&&s[k]!='!') v[i].sm-=v[i].cnt;
                if(s[k]=='?') v[i].cnt-=2,v[i].flg-=2;
                else if(s[k]!='!') v[i].flg+=2; 
            }
        }
        //起手/截断完毕，剩余过程都是暴力扩展，统一处理：
        while(1){
            if(s[i+v[i].ln+1]^s[i-v[i].ln-1]) break;
            v[i].ln++;
            if(s[i+v[i].ln]=='?') v[i].cnt+=2,v[i].flg+=2;
            else if(s[i+v[i].ln]!='!') v[i].flg-=2;
            if(v[i].flg>=0&&s[i+v[i].ln]!='!') v[i].sm+=v[i].cnt;
        }
        if(i+v[i].ln>=r) p=i,r=i+v[i].ln;
    }
    for(int i=1;i<s.size()-1;++i) ans+=__int128_t(v[i].sm)*i;
    ans>>=1; write(ans); putchar('\n');
    return 0;
}
