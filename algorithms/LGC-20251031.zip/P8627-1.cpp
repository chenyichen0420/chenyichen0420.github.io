#include<bits/stdc++.h>
using namespace std; 
int main(){ 
	int n,pg,ans; cin>>n;
	pg=n; ans=n;
	while(pg>=3){
		int t=pg/3;
		pg%=3; pg+=t; ans+=t;
	}
	cout<<ans<<endl;
	return 0; 
} 