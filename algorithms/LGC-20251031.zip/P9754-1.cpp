#include<bits/stdc++.h>
using namespace std;
#define int long long
struct ty{
    struct sub{
        int sid,sp; string na;
        sub(int s,int t,string n):sid(s),sp(t),na(n){}
    };
    vector<sub>sty; int sz,ali; unordered_set<int>ep;
}t[105]; int tc,nt; map<string,int>tid;
vector<ty::sub>vas; unordered_set<int>ep;
inline string split(string&s){
    string ret; int sp=0;
    while(sp!=s.size()&&s[sp]!='.') sp++;
    if(sp==s.size()){
        ret=s; s="";
        return ret;
    }
    ret=s.substr(0,sp);
    s=s.substr(sp+1);
    return ret;
}
signed main(){
    ios::sync_with_stdio(0); cin>>nt;
    tc++; t[1].sz=1; t[1].ali=1;
    tc++; t[2].sz=2; t[2].ali=2;
    tc++; t[3].sz=4; t[3].ali=4;
    tc++; t[4].sz=8; t[4].ali=8;
    tid["byte"]=1; tid["short"]=2;
    tid["int"]=3; tid["long"]=4;
    for(int i=1;i<=nt;++i){
        int op; cin>>op;
        if(i==27) cerr<<op<<endl;
        if(op==1){
            int k,cp=0; string s,n;
            cin>>s>>k; tid[s]=++tc;
            while(k--){
                cin>>s>>n;
                t[tc].sty.emplace_back(tid[s],0,n);
                while(cp%t[tid[s]].ali) t[tc].ep.emplace(cp),cp++;
                t[tc].sty.back().sp=cp; cp+=t[tid[s]].sz;
                t[tc].ali=max(t[tc].ali,t[tid[s]].ali);
            }
            while(cp%t[tc].ali) t[tc].ep.emplace(cp),cp++;t[tc].sz=cp;
            cout<<t[tc].sz<<" "<<t[tc].ali<<endl;
        }
        else if(op==2){
            string t,n; cin>>t>>n;
            int ptr=0;
            if(vas.size()) ptr=vas.back().sp+::t[vas.back().sid].sz;
            while(ptr% ::t[tid[t]].ali) ep.emplace(ptr),ptr++;
            cout<<ptr<<endl;
            vas.emplace_back(tid[t],ptr,n);
        }
        else if(op==3){
            string s,n; cin>>s;
            int ptr=0,pty=0;
            n=split(s);
            for(const auto&en:vas)
                if(en.na==n){
                    pty=en.sid;
                    ptr=en.sp;
                    break;
                }
            while(s.size()){
                n=split(s);
                for(const auto&en:t[pty].sty)
                    if(en.na==n){
                        pty=en.sid;
                        ptr+=en.sp;
                        break;
                    }
            }
            cout<<ptr<<endl;
        }
        else{
            int ptr=0,pty=0; string s;
            cin>>ptr; s="ERR.";
            if(ep.count(ptr)||!vas.size()||
                ptr>=vas.back().sp+t[vas.back().sid].sz){
                    cout<<"ERR\n"; continue;
                }
            for(int i=1;i<=vas.size();++i)
                if(i==vas.size()||vas[i].sp>ptr){
                    i--; ptr-=vas[i].sp;
                    s=vas[i].na+".";
                    pty=vas[i].sid;
                    break;
                }
            while(t[pty].sty.size()){
                if(t[pty].ep.count(ptr)){
                    s="ERR.";
                    break;
                }
                for(int i=1;i<=t[pty].sty.size();++i)
                    if(i==t[pty].sty.size()||t[pty].sty[i].sp>ptr){
                        i--; ptr-=t[pty].sty[i].sp;
                        s+=t[pty].sty[i].na+".";
                        pty=t[pty].sty[i].sid;
                        break;
                    }
            }
            s.pop_back();
            cout<<s<<endl;
        }
    }
    return 0;
}
/*
log.txt
1535 new passed 2023T2 using 35min
1610 re-passed 2024T2 using 25min
1645 re-passed 2024T3 using 35min

*/