#include<bits/stdc++.h>
using namespace std;
int n, a, t[200005], h[200005];
int main() {
	ios::sync_with_stdio(0); cin >> n;
	for (int i = 1; i <= n; ++i) cin >> a, t[a]++, h[a] = 1;
	for (int i = 1; i <= n; ++i) h[i] += h[i - 1];
	cout << t[0] << endl;
	for (int i = 1; i <= n; ++i)
		cout << max((i - h[i - 1]), t[i]) << endl;
}