#include<bits/stdc++.h>
using namespace std;
#define int long long
int n, a[100005], mg, ty, pro;
vector<int>son[100005], nd[100005];
int lov[100005], anp[100005];
inline void get(int x, int a) {
	int ans = 0, np = 0;
	lov[x] = 1e9 + 7; pro -= anp[x];
	while (np < son[x].size()) {
		int cp = upper_bound(son[x].begin(), son[x].end(), son[x][np] + a) - son[x].begin();
		if (cp != son[x].size()) lov[x] = min(lov[x], son[x][cp] - son[x][np]);
		ans++; np = cp;
	}
	if (ans != 1) nd[lov[x]].emplace_back(x);
	anp[x] = ans; pro += ans;
}
signed main() {
	ios::sync_with_stdio(0); cin >> n;
	for (int i = 1; i <= n; ++i)
		cin >> a[i], son[a[i]].emplace_back(i);
	for (int i = 1; i <= n; ++i)
		if (!son[i].size()) continue;
		else if (son[i].size() == 1) pro++;
		else nd[1].emplace_back(i);
	for (int i = 1; i <= n; ++i) {
		for (int sp : nd[i]) get(sp, i);
		cout << pro << endl;
	}
}