#include<bits/stdc++.h>
using namespace std;
int a,b,c;
int main(){
	ios::sync_with_stdio(0);
	cout<<"20 20\n";
	for(int i=1;i<=20;++i){
		if(i&1){
			cout<<"11111111111111111111\n";
		}
		else if(i&2){
			cout<<"00000000000000000001\n";
		}
		else{
			cout<<"10000000000000000000\n";
		}
	}
	return 0;
}