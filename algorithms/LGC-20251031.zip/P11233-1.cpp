#include<bits/stdc++.h>
using namespace std;
#define int long long
int t,n,a[200005],dp[200005],ans,sm[200005],lp[1000005];
signed main(){
    ios::sync_with_stdio(0);
    for(cin>>t;t;t--){
        cin>>n; ans=0; memset(lp,0,sizeof lp);
        for(int i=1;i<=n;++i) cin>>a[i],sm[i]=sm[i-1]+a[i]*(a[i]==a[i-1]);
        for(int i=1;i<=n;++i){
            dp[i]=dp[i-1];
            if(a[i]==a[i-1]) dp[i]=dp[i-1]+a[i];
            else if(lp[a[i]])
                dp[i]=max(dp[i],dp[lp[a[i]]+1]+a[i]+sm[i-1]-sm[lp[a[i]]+1]);
            lp[a[i]]=i;
        }
        cout<<dp[n]<<endl;
    }
    return 0;
}
/*
log.txt
1535 new passed 2023T2 using 35min
1610 re-passed 2024T2 using 25min
*/