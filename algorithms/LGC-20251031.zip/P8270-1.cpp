#include<bits/stdc++.h>
using namespace std;
int q; string s1,s2,t; map<pair<int,int>,bool>mp;
int main(){
	ios::sync_with_stdio(false);
	cin>>s1>>s2>>q;
	for(int i='a';i<='r';++i){
		for(int j='a';j<='r';++j){
			string a,b; a=b="";
			for(int k=0;k<s1.size();++k) if(s1[k]==i||s1[k]==j) a+=s1[k];
			for(int k=0;k<s2.size();++k) if(s2[k]==i||s2[k]==j) b+=s2[k];
			if(a==b) mp[make_pair(i-'a',j-'a')]=true;
		}
	}
	while(q--){
		bool f=true; cin>>t;
		for(int i=0;i<t.size();++i)
			for(int j=0;j<t.size();++j)
				if(!mp[make_pair(t[i]-'a',t[j]-'a')]){
					f=false; break;
				}
		if(f) cout<<"Y";
		else cout<<"N";
	}
	return 0;
}