#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 0;
int n, m; char c, mi[3005], ma[3005];
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m;
	fill(mi, mi + n + 1, 127);
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j)
			cin >> c,
			ma[i] = max(ma[i], c),
			mi[i] = min(mi[i], c);
	for (int i = 1; i <= n; ++i) {
		bool cn = 1;
		for (int j = 1; j <= n; ++j)
			if (i != j && mi[i] >= ma[j]) {
				cn = 0; break;
			}
		cout << cn;
	}
	return 0;
}
//exp:100