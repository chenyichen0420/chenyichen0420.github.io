#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr int mod=1e9+7;
int t,n,m,h[10000005],jc[10000005],ny[10000005];
inline int qpow(int a,int b){
    int ret=1;
    for(;b;b>>=1,a=a*a%mod)
        (b&1)&&(ret=ret*a%mod);
    return ret;
}
inline int nv(int v){return ny[v]*jc[v-1]%mod;}
signed main(){
    ios::sync_with_stdio(0);
    cin.tie(0); cout.tie(0); jc[0]=1;
    for(int i=1;i<=1e7;++i) jc[i]=jc[i-1]*i%mod;
    ny[10000000]=qpow(jc[10000000],mod-2);
    for(int i=1e7;i>=1;--i) ny[i-1]=ny[i]*i%mod;
    for(int i=1;i<=1e7;++i) h[i]=(h[i-1]+nv(i))%mod;
    for(t=1;t;t--)
        cin>>n>>m,cout<<jc[n]*(h[m]+h[n-m]-h[n]+(n-m)*nv(n)%mod+mod)%mod*ny[2]%mod<<endl;
}
