#include<bits/stdc++.h>
using namespace std;
int main(){
	register int n;cin>>n; register string t;
	while(n--){
		cin>>t;int mvn=1,ans=0;
		for(register int i=0;i<t.size();++i) ans+=t[i]-'0',mvn=min(mvn,t[i]-'0');
		cout<<ans+9-(mvn!=0)<<endl;
	}
	return 0;
}