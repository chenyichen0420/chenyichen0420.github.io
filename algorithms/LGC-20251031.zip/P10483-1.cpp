#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,ans=20,w,c[25],cab[25];
inline bool cmp(int x, int y){
	return x>y;
}
inline void dfs(int now,int cnt){
	if(cnt>=ans) return;
	if(now==n+1){
		ans=cnt;
		return;
	}
	for(int i=1; i<=cnt; i++){
		if(cab[i]+c[now] <= w){
			cab[i] += c[now];
			dfs(now+1, cnt);
			cab[i] -= c[now];
		}
	}
	cab[cnt+1] = c[now];
	dfs(now+1, cnt+1);
	cab[cnt+1] = 0;
	return;
}

signed main(){
	scanf("%lld%lld",&n,&w);
	for(int i=1;i<=n;i++)scanf("%lld", c+i);
	sort(c+1,c+1+n,cmp);
	cab[0]=w,ans=n;
	dfs(1,0);
	cout<<ans<<endl;
	return 0;
}