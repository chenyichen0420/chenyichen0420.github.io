#include<bits/stdc++.h>
using namespace std;
int t, n, m, k, x, y, d, xi, yi, ans;
char mp[1005][1005]; bool vis[1005][1005];
inline bool check() {
	if (xi<1 || xi>n || yi<1 || yi>m) return 0;
	if (mp[xi][yi] == 'x') return 0; return 1;
}
inline void chg() {
	vis[x][y] = 1;
	xi = x; yi = y;
	if (d == 0) yi++;
	else if (d == 1) xi++;
	else if (d == 2) yi--;
	else if (d == 3) xi--;
	if (!check()) d++, d &= 3;
	else x = xi, y = yi;
}
int main() {
	ios::sync_with_stdio(0);
	for (cin >> t; t; t--) {
		memset(vis, 0, sizeof vis); ans = 0;
		cin >> n >> m >> k >> x >> y >> d;
		for (int i = 1; i <= n; ++i)
			for (int j = 1; j <= m; ++j)
				cin >> mp[i][j];
		for (int i = 1; i <= k; ++i) chg();
		vis[x][y] = 1;
		for (int i = 1; i <= n; ++i)
			for (int j = 1; j <= m; ++j)
				ans += vis[i][j];
		cout << ans << endl;
	}
}