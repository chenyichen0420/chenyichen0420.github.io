#include<bits/stdc++.h>
#include<unordered_map>
#include<unordered_set>
using namespace std;
#ifdef _WIN32
#define getchar_unlocked getchar
#define putchar_unlocked putchar
#endif
inline int read() {
	int r = 0; char c = getchar_unlocked();
	while (c < '0' || c>'9') c = getchar_unlocked();
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar_unlocked();
	return r;
}
int n, m, ans; map<long long, set<int>>v; set<int>::iterator it;
inline long long gh(const int& a, const int& b) {
	return (long long)a * n + b;
}
signed main() {
	n = read(); m = read();
	for (int i = 1, l, r, x; i <= m; ++i) {
		l = read(); r = read(); x = read();
		const set<int>& va = v[gh(l, r)];
		int sa = va.size();
		const set<int>& vb = v[gh(l, x)];
		int sb = vb.size();
		const set<int>& vc = v[gh(r, x)];
		int sc = vc.size();
		if (sa <= sb && sa <= sc)
			for (it = va.begin(); it != va.end(); ++it) {
				if (vb.count(*it) && vc.count(*it)) ans++;
			}
		else if (sb <= sa && sb <= sc)
			for (it = vb.begin(); it != vb.end(); ++it) {
				if (va.count(*it) && vc.count(*it)) ans++;
			}
		else
			for (it = vc.begin(); it != vc.end(); ++it) {
				if (vb.count(*it) && va.count(*it)) ans++;
			}
		v[gh(l, r)].insert(x);
		v[gh(l, x)].insert(r);
		v[gh(r, x)].insert(l);
	}
	cout << ans << endl;
}