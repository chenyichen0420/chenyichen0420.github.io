#include<bits/stdc++.h>
using namespace std;
#define int long long
int t,a[5],mx,b[5]; bool cn;
signed main() {
	cin>>t;
	while(t--){
		for(int i=0;i<4;++i)
			cin>>a[i],b[i]=a[i];
		b[2]=abs(b[2]-b[0]);
		mx=max(b[1],max(b[2],b[3]));
		if(mx*2<b[1]+b[2]+b[3]){
			cout<<"yes\n"; continue;
		}
		a[1]=abs(a[1]-a[3]);
		mx=max(a[0],max(a[1],a[2]));
		if(mx*2<a[1]+a[2]+a[0]){
			cout<<"yes\n"; continue;
		}
		cout<<"no\n";
	}
	return 0;
}