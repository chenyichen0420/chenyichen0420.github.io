#include<iostream>
#include<cmath>
#include<algorithm>
#include<vector>
#include<stack>
#include<queue>
#include<unordered_map>
#include<map>
using namespace std;
bool chk[500000];
signed main() {
	ios::sync_with_stdio(false);
	register int n, m, v, cnt;
	cin >> n >> m; register bool cntco = 0;
	while(m--){
		cin >> v; 
		if (cntco) {
			cout << "0 "; continue;
		}
		register int ps = 0, thisct = 0;
		do {
			if (!chk[ps]) chk[ps] = 1, cnt++, thisct++;
			ps += v; ps %= n;
			if (cnt == n) cntco = 1;
		} while (ps);
		cout << thisct << " ";
	}
}