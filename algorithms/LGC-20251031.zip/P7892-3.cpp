#include<bits/stdc++.h>
using namespace std;
int main(){
    int t,n,m,ii,jj; cin>>t;
    for(int i=1;i<=t;i++){
        cin>>n>>m;
        for(int j=1;j<=sqrt(n)+1;j++)
            if(n%j==0) ii=j,jj=n/j;
        if(ii*2+jj*2+4<=m) cout<<"Good"<<endl;
        else cout<<"Miss"<<endl;
    }
} 