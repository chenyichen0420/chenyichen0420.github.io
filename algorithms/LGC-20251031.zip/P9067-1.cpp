#include<bits/stdc++.h>
using namespace std;
int n, m, f[1000005], c[1000005], op, l, r, tmp;
vector<int>son[1000005]; map<int, list<int>>com[1000005];
int fa[1000005], siz[1000005];
inline int find(const int& p) {
	return (fa[p] != p ? fa[p] = find(fa[p]) : p);
}
inline void merge(int l, int r) {
	l = find(l); r = find(r);
	fa[r] = l; siz[l] += siz[r];
}
inline void dfs(const int& p, const int& f) {
	::f[p] = f;
	for (int sp : son[p]) {
		if (sp == f) continue;
		if (c[p] == c[sp]) merge(p, sp);
		else com[find(p)][c[sp]].emplace_back(sp);
		dfs(sp, p);
	}
}
inline void mergm(int l, int r) {
	if (com[l].size() < com[r].size()) swap(com[l], com[r]);
	for (auto& i : com[r])
		com[l][i.first].splice(com[l][i.first].end(), i.second);
	com[r].clear();
}
signed main() {
	ios::sync_with_stdio(0); cin >> n >> m;
	for (int i = 2, p; i <= n; ++i)
		cin >> p, son[p].emplace_back(i);
	for (int i = 1; i <= n; ++i)
		cin >> c[i], siz[fa[i] = i] = 1;
	dfs(1, 0);
	while (m--)
		if (cin >> op >> l, l = find(l), op & 1) {
			cin >> r;
			if (c[l] == r) continue;
			list<int> lt = com[l][r];
			for (int vl : lt)
				if (r == c[vl] && l != find(vl))
					merge(l, vl), mergm(l, vl);
			tmp = find(f[l]);
			if (r == c[tmp]) merge(tmp, l), mergm(tmp, l);
			else if (tmp) com[tmp][r].emplace_back(l);
			com[find(l)][c[l] = r].clear();
		}
		else cout << siz[l] << endl;
	return 0;
}
//私は猫です