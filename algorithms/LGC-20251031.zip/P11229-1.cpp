#include<bits/stdc++.h>
using namespace std;
int t, n, ans[15] = { -1,-1,1,7,4,2,6,8,10,18,22,20,28,68,88 };
int main() {
	ios::sync_with_stdio(0);
	for (cin >> t; t; t--) {
		cin >> n;
		if (n <= 14) {
			cout << ans[n] << endl;
			continue;
		}
		int ct = n / 7 + 1, vt = n % 7;
		if (vt == 0) {
			for (int i = 1; i < ct; ++i) cout << "8";
			cout << endl;
		}
		else if (vt == 1) {
			cout << "10";
			for (int i = 3; i <= ct; ++i) cout << "8";
			cout << endl;
		}
		else if (vt == 2) {
			cout << "1";
			for (int i = 2; i <= ct; ++i) cout << "8";
			cout << endl;
		}
		else if (vt == 3) {
			cout << "200";
			for (int i = 4; i <= ct; ++i) cout << "8";
			cout << endl;
		}
		else if (vt == 4) {
			cout << "20";
			for (int i = 3; i <= ct; ++i) cout << "8";
			cout << endl;
		}
		else if (vt == 5) {
			cout << "2";
			for (int i = 2; i <= ct; ++i) cout << "8";
			cout << endl;
		}
		else if (vt == 6) {
			cout << "6";
			for (int i = 2; i <= ct; ++i) cout << "8";
			cout << endl;
		}
	}
}