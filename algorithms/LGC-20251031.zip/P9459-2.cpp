#include<bits/stdc++.h>
using namespace std;
int n; string s1,s2,s3,s4;
int main(){
	ios::sync_with_stdio(false);
	cin>>n;
	while(n--){
		cin>>s1>>s2>>s3>>s4;
		if(s1[0]==s2[0]&&s2[0]=='y'&&s3=="ding"&&s4=="zhen") cout<<"Yes\r\n";
		else cout<<"No\r\n";
	}
	return 0;
}