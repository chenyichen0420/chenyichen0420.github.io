#include<bits/stdc++.h>
using namespace std;
int n,ans;
int main(){
	cin>>n; int t1=n/4,t2=n%4;
	if(t1<t2) ans=0;
	else ans=(t1-t2)/5+1;
	cout<<ans<<endl;
	return 0;
}