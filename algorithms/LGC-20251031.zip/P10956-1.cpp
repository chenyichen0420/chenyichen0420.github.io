#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr int mod = 1e9;
int dp[305][305], n; char c[305];
signed main() {
	ios::sync_with_stdio(0);
	cin >> (c + 1); n = strlen(c + 1);
	for (int i = 1; i <= n; ++i) dp[i][i] = 1;
	for (int l = 2; l <= n; ++l)
#define j (i + l - 1)
		for (int i = 1; j <= n; ++i)
			for (int k = i + 2; k <= j; ++k)
				if (c[i] == c[k])
					dp[i][j] = (dp[i][j] + dp[i + 1][k - 1] * dp[k][j]) % mod;
	cout << dp[1][n] << endl;
}