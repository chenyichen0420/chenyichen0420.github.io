#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m,a[300005],p[300005],t,cnr[300005],cnl[300005];
signed main(){
	ios::sync_with_stdio(0); cin>>n>>m;
	for(int i=1;i<=n;++i) cin>>a[i],p[a[i]]=i;
	for(int i=1;i<=n;++i) 
		cnr[i]=cnr[i-1]+(n-p[i]+1),
		cnl[i]=cnr[i-1]+1;
	while(m--){
		cin>>t;
		int pt=upper_bound(cnl+1,cnl+n+1,t)-cnl-1;
		int mr=t-cnl[pt];
		cout<<p[pt]<<" "<<p[pt]+mr<<endl;
	}
} 