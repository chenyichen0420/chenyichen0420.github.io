#include<bits/stdc++.h>
using namespace std;
struct node {
	int p, id;
	node(int pi = 0, int ii = 0) :p(pi), id(ii) {};
};
int n, m; vector<node>son[500005];
int dfn[500005], low[500005], cnt; bool vis[2000005];
inline void tmin(int& l, const int r) { (l > r) && (l = r); }
inline void tarjan(int p, int f) {
	dfn[p] = low[p] = ++cnt;
	for (const node& sp : son[p])
		if (!dfn[sp.p]) {
			tarjan(sp.p, sp.id); tmin(low[p], low[sp.p]);
			if (low[sp.p] > dfn[p]) vis[sp.id] = 1;
		}
		else if (sp.id != f) tmin(low[p], low[sp.p]);
}
vector<vector<int>>ed; bool ev[500005];
inline void dfs(int p) {
	ed.back().emplace_back(p); ev[p] = 1;
	for (const node& sp : son[p])
		if (!ev[sp.p] && !vis[sp.id]) dfs(sp.p);
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m;
	for (int i = 1, l, r; i <= m; ++i)
		cin >> l >> r,
		son[l].emplace_back(r, i),
		son[r].emplace_back(l, i);
	for (int i = 1; i <= n; ++i)
		if (!dfn[i]) tarjan(i, 0);
	for (int i = 1; i <= n; ++i)
		if (!ev[i])
			ed.emplace_back(vector<int>()),
			dfs(i);
	cout << ed.size() << endl;
	for (const vector<int>& v : ed) {
		cout << v.size() << " ";
		for (int i : v) cout << i << " ";
		cout << endl;
	}
}