#include<bits/stdc++.h>
using namespace std;
int t, n, k, a, gc, ans;
inline int gcd(const int& l, const int& r) {
	if (!r) return l;
	return gcd(r, l % r);
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> t;
	while (t--) {
		cin >> n >> k; gc = ans = 0;
		while (n--) cin >> a, gc = gcd(a, gc);
		for (int i = 1; i * i <= gc; ++i)
			if (gc % i == 0) {
				if (i != 1) ans = max(ans, k / i * i);
				ans = max(ans, k / (gc / i) * (gc / i));
			}
		cout << ans << endl;
	}
	return 0;
}