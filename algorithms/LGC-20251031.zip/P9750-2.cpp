#include<bits/stdc++.h>
using namespace std;
#define int long long
const bool online=0;
int t,m,a,b,c,deta,prm[1145],cnt;
inline bool isp(int val){
	for(int i=2;i*i<=val;++i)
		if(val%i==0) return 0;
	return 1;
}
inline void init(){
	for(int i=2;i<=3000;++i)
		if(isp(i)) prm[++cnt]=i;
}
inline bool isokdet(){
	int tmp=sqrt(deta);
	return tmp*tmp==deta;
}
inline void slipp(int& lv,int& rv){
	if(rv<0) lv=-lv,rv=-rv;
	int tmp=abs(__gcd(lv,rv));
	lv/=tmp; rv/=tmp;
	return;
}
signed main(){
	if(online)
		freopen("uqe.in","r",stdin),
		freopen("uqe.out","w",stdout);
	ios::sync_with_stdio(0);
	cin>>t>>m; init();
	while(t--){
		cin>>a>>b>>c;
		deta=b*b-4*a*c;
		if(deta<0){
			cout<<"NO\n";
			continue;
		}
		if(isokdet()){
			deta=sqrt(deta);
			if(a<0) deta=-deta;
			deta-=b; a*=2;
			slipp(deta,a);
			if(a==1) cout<<deta<<endl;
			else cout<<deta<<"/"<<a<<endl;
		}
		else{
			int trp=1,tapp=a*2;
			b=-b; slipp(b,tapp);
			if(b!=0){
				if(tapp==1) cout<<b<<"+";
				else cout<<b<<"/"<<tapp<<"+";
			}
			for(int i=1;i<=cnt;++i)
				if(deta%(prm[i]*prm[i])==0){
					while(deta%(prm[i]*prm[i])==0)
						deta/=(prm[i]*prm[i]),
						trp*=prm[i];
				}
			a*=2; if(a<0) trp=-trp;
			slipp(trp,a);
			if(trp==1){
				if(a==1) cout<<"sqrt("<<deta<<")"<<endl;
				else cout<<"sqrt("<<deta<<")/"<<a<<endl;
			}
			else {
				if(a==1) cout<<trp<<"*sqrt("<<deta<<")"<<endl;
				else cout<<trp<<"*sqrt("<<deta<<")/"<<a<<endl;
			}
		}
	}
	return 0;
}