#include<bits/stdc++.h>
using namespace std;
#define int long long
int x,y,p,r,n,bs,ans;
#define blk(p) (p/bs)
struct node{
	int x,y,p,r,m;
	inline bool operator<(const node&v){ return m<v.m; }
	inline int dis() const{return x*x+y*y;}
}v[300005],tmp;
inline bool cmp(const node&l,const node&r){ return l.dis()<r.dis(); }
vector<node>bv[550]; queue<node>q; int mb[550];
signed main(){
	ios::sync_with_stdio(0);
	cin>>x>>y>>p>>r>>n;
	for(int i=1;i<=n;++i)
		cin>>v[i].x>>v[i].y>>v[i].m>>v[i].p>>v[i].r,
		v[i].x=abs(v[i].x-x), v[i].y=abs(v[i].y-y);
	bs=sqrt(n); sort(v+1,v+n+1);
	for(int i=1;i<=n;++i)
		bv[blk(i)].emplace_back(v[i]),
		mb[blk(i)] = v[i].m;
	for(int i=0;i<=blk(n);++i)
		sort(bv[i].begin(),bv[i].end(),cmp);
	tmp={x,y,p,r,0}; q.emplace(tmp);
	while(q.size()){
		tmp=q.front(); q.pop(); ans++;
		for(int i=0;i<=blk(n);++i){
			if(bv[i].size())
				if(mb[i]>tmp.p){
					for(int j=bv[i].size()-1;j>=0;j--)
						if(bv[i][j].m<=tmp.p&&bv[i][j].dis()<=tmp.r*tmp.r)
							q.emplace(bv[i][j]), bv[i].erase(bv[i].begin() + j);
					break;
				}
				else
					while(bv[i].size() && bv[i][0].dis()<=tmp.r*tmp.r)
						q.emplace(bv[i][0]), bv[i].erase(bv[i].begin());
		}
	}
	cout<<ans-1<<endl;
} 
/*
0 6 3 12 10
0 2 11 3 9
2 2 12 5 5
0 6 5 9 3
6 8 6 5 3
8 0 4 3 6
4 4 3 5 3
4 6 6 5 3
0 4 3 9 11
2 0 10 3 3
8 0 11 12 11

ans: 6
*/