#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,gc,ml,ph,vl,ans,lm;
inline int read(){
	int r=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') r=(r<<3)+(r<<1)+(c^48),c=getchar();
	return r;
}
inline void write(int x){
	if(x>9) write(x/10);
	putchar(x%10+'0');
	return;
}
inline void wrote(int argc,int args){
	putchar('C');
	putchar('a');
	putchar('s');
	putchar('e');
	putchar(' ');
	write(argc);
	putchar(':');
	putchar(' ');
	write(args);
	putchar('\n');
}
inline int ksm(int cs,int md){
	int ans=1,tmp=10;
	while(cs){
		if(cs&1) ans*=tmp,ans%=md;
		tmp*=tmp; tmp%=md;
		cs>>=1;
	}
	return ans;
}
signed main(){
	ios::sync_with_stdio(0);
	while(1){
		if(!(n=read())) break;
		gc=__gcd(8ll,n);
		ml=n*9/gc; lm=ml;
		if(ml%2==0||ml%5==0){
			wrote(++vl,0);
			continue; 
		}
		ph=ml;
		for(int i=2;i<=lm;++i)
			if(lm%i==0){
				ph=ph/i*(i-1);
				while(lm%i==0) lm/=i;
			}
		ans=0x3f3f3f3f3f3f3f3f;
		for(int i=1;i*i<=ph;++i)
			if(ph%i==0){
				if(ksm(i,ml)==1) ans=min(ans,i);
				else if(ksm(ph/i,ml)==1) ans=min(ans,ph/i);
			}
		wrote(++vl,ans);
	}
	return 0;
}