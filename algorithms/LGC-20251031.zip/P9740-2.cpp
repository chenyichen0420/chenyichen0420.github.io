#include<bits/stdc++.h>
using namespace std;
int n, a[8], b[8], tt, rp;
int main() {
	ios::sync_with_stdio(0);
	cin >> n;
	for (int i = 1; i <= n; ++i) cin >> a[i] >> b[i], tt += 100 * b[i] / a[i];
	cin >> rp;
	if (tt >= rp) {
		cout << "Already Au.\n";
		return 0;
	}
	double tmp = rp - tt;
	for (int i = 1; i <= n; ++i) {
		if (tt + 100 * (a[i] - b[i]) / a[i] < rp) {
			cout << "NaN\n"; continue;
		}
		cout << (int)ceil(tmp / (100 / a[i])) << endl;
	}
	return 0;
}