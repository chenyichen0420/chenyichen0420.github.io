#include <bits/stdc++.h>
using namespace std;
#define int long long
inline void tmax(int& a, const int& b) { (b > a) && (a = b); }
int aa[100005][25], ai[100005][25], ana[100005][25], api[100005][25];
int ba[100005][25], bi[100005][25], n, m, q, la, ra, lb, rb, lg[100005];
int ans, sza, szb, aav, aiv, anx, apn, bav, biv, rpa, rpb;
constexpr int maxinf = LLONG_MAX >> 1, mininf = LLONG_MIN >> 1;
inline void gen(const int& sz, int(*v)[25], bool ty = 1) {
	for (int j = 1; j <= lg[sz]; ++j)
		for (int i = 1, lp; i + (1ll << j) - 1 <= sz; ++i)
			if (ty) v[i][j] = max(v[i][j - 1], v[i + (1ll << j - 1)][j - 1]);
			else v[i][j] = min(v[i][j - 1], v[i + (1ll << j - 1)][j - 1]);
}
signed main() {
//	freopen(R"(D:\定时训练\game\game4.in)", "r", stdin);
//	freopen(R"(D:\定时训练\game\game4.out)", "w", stdout);
	ios::sync_with_stdio(0); cin >> n >> m >> q;
	for (int i = 1, x; i <= n; ++i)
		cin >> x, aa[i][0] = ai[i][0] = x,
		ana[i][0] = (x < 0 ? x : mininf),
		api[i][0] = (x >= 0 ? x : maxinf);
	for (int i = 1, x; i <= m; ++i) cin >> x, ba[i][0] = bi[i][0] = x;
	for (int i = 2; i <= max(n, m); ++i) lg[i] = lg[i >> 1] + 1;
	gen(n, aa); gen(n, ana); gen(n, ai, 0); gen(n, api, 0); gen(m, ba); gen(m, bi, 0);
	while (q--) {
		cin >> la >> ra >> lb >> rb; ans = mininf;
		sza = lg[ra - la + 1], szb = lg[rb - lb + 1];
		rpa = ra - (1ll << sza) + 1, rpb = rb - (1ll << szb) + 1;
		aav = max(aa[la][sza], aa[rpa][sza]), aiv = min(ai[la][sza], ai[rpa][sza]);
		anx = max(ana[la][sza], ana[rpa][sza]), apn = min(api[la][sza], api[rpa][sza]);
		bav = max(ba[lb][szb], ba[rpb][szb]), biv = min(bi[lb][szb], bi[rpb][szb]);
		tmax(ans, aav * (aav >= 0 ? biv : bav)), tmax(ans, aiv * (aiv >= 0 ? biv : bav));
		if (anx ^ mininf) tmax(ans, anx * (anx >= 0 ? biv : bav));
		if (apn ^ maxinf) tmax(ans, apn * (apn >= 0 ? biv : bav));
		cout << ans << endl;
	}
	return 0;
}