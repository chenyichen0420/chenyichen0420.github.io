#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr int siz = 2e6 + 5;
long long n, m; char c[siz >> 1]; bool vs[siz];
struct suf_atm {
	int sn[siz][26], lk[siz], ln[siz], cnt = 1, lp = 1, sz[siz], sm[siz];
	inline void add(char c, int pv) {
		int p = lp; sz[lp = ++cnt] = 1; ln[lp] = pv; sm[lp] = 1;
		while (p && !sn[p][c]) sn[p][c] = lp, p = lk[p];
		if (!p) return void(lk[lp] = 1); int np = sn[p][c];
		if (ln[p] + 1 == ln[np]) return void(lk[lp] = np);
		ln[++cnt] = ln[p] + 1; lk[cnt] = lk[np];
		lk[np] = lk[lp] = cnt;
		memcpy(sn[cnt], sn[np], sizeof sn[np]);
		for (int i = p; sn[i][c] == np; i = lk[i]) sn[i][c] = cnt;
	}
	inline int get(int p) {
		if (vs[p]) return sm[p];
		for (int sp : sn[p]) 
			if (sp) sm[p] += get(sp);
		vs[p] = 1; return sm[p];
	}
	inline void solve() {
		for (int i = 2; i <= cnt; ++i) sz[i] = sm[i] = 1; get(1);
	}
	inline void output(int p, int v) {
		if (v > sm[p]) return void(puts("-1"));
		if (v <= sz[p]) return; v -= sz[p];
		for (int i = 0; i != 26; ++i)
			if (v > sm[sn[p][i]]) v -= sm[sn[p][i]];
			else return putchar('a' + i), output(sn[p][i], v);
	}
}sam;
signed main() {
	ios::sync_with_stdio(0); cin >> (c + 1);
	for (int i = 1; c[i]; ++i) sam.add(c[i] - 'a', i);
	sam.solve();
	for (cin >> n; n; n--) cin >> m, sam.output(1, m), putchar('\n');
}