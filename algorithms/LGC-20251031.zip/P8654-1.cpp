#include<bits/stdc++.h>
using namespace std;
int n, m, k, f[1000005], cn;
inline int find(int p) {
	return f[p] != p ? f[p] = find(f[p]) : p;
}
inline void merge(int l, int r) {
	f[find(l)] = find(r);
}
inline char same(int l, int r) {
	return find(l) != find(r) ? 'N' : 'Y';
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m >> k;
	for (int i = 1; i <= n * m; ++i) f[i] = i;
	for (int i = 1, l, r; i <= k; ++i)
		cin >> l >> r, merge(l, r);
	for (int i = 1; i <= n * m; ++i) cn += find(i) == i;
	cout << cn << endl;
	return 0;
}