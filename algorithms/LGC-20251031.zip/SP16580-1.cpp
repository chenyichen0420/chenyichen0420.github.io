#include<bits/stdc++.h>
using namespace std;
#define sipt //signed-input
#define sopt //signed-output
struct IO {
#define mxsz (1 << 21)
	char buf[mxsz], * p1, * p2;
	char pbuf[mxsz], * pp; bool acc[128];
	IO() : p1(buf), p2(buf), pp(pbuf) {}
	~IO() { fwrite(pbuf, 1, pp - pbuf, stdout); }
	inline char gc() {
		if (p1 == p2) p2 = (p1 = buf) + fread(buf, 1, mxsz, stdin);
		return p1 == p2 ? ' ' : *p1++;
	}
	inline void setacc(const char* c) { while (*c) acc[*c++] = 1; }
	inline char getc() { char c; while (!acc[c = gc()]); return c; }
#ifndef sipt
	inline int read() {
		int r = 0; char c = gc(); while (c < '0' || c>'9') c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return r;
	}
#else
	inline int read() {
		int r = 0; char c = gc(); bool rev = 0;
		while (c < '0' || c>'9') rev |= (c == '-'), c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return rev ? ~r + 1 : r;
	}
#endif
	inline void push(const char& c) {
		if (pp - pbuf == mxsz) fwrite(pbuf, 1, mxsz, stdout), pp = pbuf;
		*pp++ = c;
	}
	inline void write(int x) {
		static char sta[22]; int top = 0;
		do sta[top++] = x % 10, x /= 10; while (x);
		while (top) push(sta[--top] ^ 48);
	}
	inline void write(int x, char opc) {
#ifdef sopt
		if (x < 0) push('-'), x = ~x + 1;
#endif
		write(x), push(opc);
	}
	inline void puts(const char* c) { while (*c) push(*c++); }
} io;
constexpr int sz = 1e5 + 5; vector<int>son[sz];
struct delheap {
	priority_queue<int>pq, dq;
	inline void ins(int v) { pq.emplace(v); }
	inline void del(int v) { dq.emplace(v); }
	inline int top() {
		while (dq.size() && pq.size() && pq.top() == dq.top()) pq.pop(), dq.pop();
		return pq.size() ? pq.top() : -1e9;
	}
};
int n, m, f[sz], c[sz];
struct LCT {
	int sn[sz][2], mx[sz], f[sz], a[sz]; delheap v[sz];
	inline bool sd(int p) { return sn[f[p]][0] ^ p; }
	inline bool nrt(int p) { return sn[f[p]][sd(p)] == p; }
	inline void pup(int p) {
		mx[p] = max({ a[p],v[p].top(),mx[sn[p][0]],mx[sn[p][1]] });
	}
	inline void rot(int p) {
		int fp = f[p], pp = f[fp];
		bool t = sd(p); int sp = sn[p][!t];
		if (nrt(fp)) sn[pp][sd(fp)] = p;
		sn[p][!t] = fp; sn[fp][t] = sp;
		if (sp) f[sp] = fp; f[fp] = p; f[p] = pp;
		pup(fp); pup(p);
	}
	inline void splay(int p) {
		for (int fp; fp = f[p], nrt(p); rot(p))
			if (nrt(fp)) rot(sd(p) ^ sd(fp) ? p : fp);
	}
	inline void access(int p) {
		for (int sp = 0; p; p = f[sp = p]) {
			splay(p);
			if (sn[p][1]) v[p].ins(mx[sn[p][1]]);
			if (sn[p][1] = sp) v[p].del(mx[sp]);
			pup(p);
		}
	}
	inline void mkrt(int p) { access(p); splay(p); }
	inline int fnrt(int p) {
		access(p); splay(p);
		while (sn[p][0]) p = sn[p][0];
		splay(p); return p;
	}
	inline void exlnk(int l, int r) { mkrt(l); access(r); splay(r); }
	inline void link(int p) {
		splay(p); int r = f[p] = ::f[p];
		mkrt(r); sn[r][1] = p; pup(r);
	}
	inline void cut(int p) { mkrt(p); sn[p][0] = f[sn[p][0]] = 0; pup(p); }
	inline int que(int p) { return mx[sn[fnrt(p)][1]]; }
	//proved that the root has a different color
	inline void chg(int p, int v) { mkrt(p); a[p] = v; pup(p); }
}lct[2];
inline void dfs(int p) {
	for (int sp : son[p]) if (sp != f[p])
		f[sp] = p, dfs(sp);
	lct[c[p]].link(p);
}
int main() {
	ios::sync_with_stdio(0);
	cin.tie(0); cout.tie(0); n = io.read();
	lct[0].mx[0] = lct[1].mx[0] = -1e9;
	for (int i = 1, l, r; i != n; ++i)
		l = io.read(), r = io.read(),
		son[l].emplace_back(r),
		son[r].emplace_back(l);
	for (int i = 1; i <= n; ++i) c[i] = io.read();
	for (int i = 1, v; i <= n; ++i)
		v = io.read(),
		lct[0].a[i] = lct[0].mx[i] = v,
		lct[1].a[i] = lct[1].mx[i] = v;
	f[1] = sz - 2; dfs(1); m = io.read();
	for (int i = 1, o, p, v; i <= m; ++i)
		if (o = io.read(), p = io.read(), !o) io.write(lct[c[p]].que(p), '\n');
		else if (o == 1) lct[c[p]].cut(p), c[p] ^= 1, lct[c[p]].link(p);
		else v = io.read(), lct[0].chg(p, v), lct[1].chg(p, v);
}