#include<bits/stdc++.h>
using namespace std;
const bool online=0;
int n,ans,t2;
int main(){
	if(online)
		freopen("apple.in","r",stdin),
		freopen("apple.out","w",stdout);
	cin>>n;
	while(n){
		ans++;
		if(n%3==1&&!t2) t2=ans;
		n=n-ceil(n*1.0/3);
	}
	cout<<ans<<" "<<t2<<endl;
	return 0;
}