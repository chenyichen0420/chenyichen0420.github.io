#include<bits/stdc++.h>
using namespace std;
#define Int long long
using cir = const int&;
inline int read() {
	int r = 0; char c = getchar();
	while (c < '0' || c>'9') c = getchar();
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar();
	return r;
}
inline void write(Int x) {
	if (x > 9) write(x / 10);
	putchar(x % 10 ^ 48);
	return;
}
inline void writi(Int args) {
	write(args); putchar(10);
}
inline void tmax(Int& l,const Int& r) {
	(l < r) && (l = r);
}
int vl[200005]; int siz;
inline void ins(cir v) { vl[++siz] = v; }
inline void form() {
	sort(vl + 1, vl + siz + 1);
	siz = unique(vl + 1, vl + siz + 1) - vl - 1;
}
inline int que(cir cv) {
	return lower_bound(vl + 1, vl + siz + 1, cv) - vl;
}
class seg_tree {
	struct node {
		int l, r;Int lz, mv;
		inline void add(const Int& v) {
			lz += v, mv += v;
		}
	}re[200005 << 2];
	inline node& lc(cir p) {
		return re[p << 1];
	}
	inline node& rc(cir p) {
		return re[p << 1 | 1];
	}
	inline void pup(cir p) {
		re[p].mv = max(lc(p).mv, rc(p).mv);
	}
	inline void pud(cir p) {
		lc(p).add(re[p].lz); rc(p).add(re[p].lz);
		re[p].lz = 0;
	}
public:
	inline void build(cir l, cir r, cir id) {
		re[id].l = l; re[id].r = r;
		re[id].lz = re[id].mv = 0;
		if (l == r) return;
		int mid = (l + r >> 1);
		build(l, mid, id << 1);
		build(mid + 1, r, id << 1 | 1);
	}
	inline void ins(cir l, cir r, const Int& v, cir id) {
		if (l <= re[id].l && r >= re[id].r) {
			re[id].add(v); return;
		}
		pud(id);
		if (l <= lc(id).r) ins(l, r, v, id << 1);
		if (r >= rc(id).l) ins(l, r, v, id << 1 | 1);
		pup(id);
	}
	inline Int que(cir l, cir r, cir id) {
		if (l <= re[id].l && r >= re[id].r) return re[id].mv;
		pud(id); Int mav = -0x3f3f3f3f3f3f3f3f;
		if (l <= lc(id).r) tmax(mav, que(l, r, id << 1));
		if (r >= rc(id).l) tmax(mav, que(l, r, id << 1 | 1));
		pup(id); return mav;
	}
}st;
struct mis {
	int l, r, v;
}a[100005];
int c, t, n, m, k, d, l, r, ptr; Int ans;
signed main() {
	read(); t = read();
	while (t--) {
		n = read(); m = read(); k = read(); d = read();
		siz = ans = 0; ptr = 1;
		for (int i = 1; i <= m; ++i)
			l = read(), r = read(), a[i].v = read(),
			a[i].l = l - r, a[i].r = l,
			ins(l - r), ins(l);
		form();
		for (int i = 1; i <= m; ++i)
			a[i].l = que(a[i].l),
			a[i].r = que(a[i].r);
		sort(a + 1, a + m + 1, [&](const mis& l, const mis& r) {
			return l.r < r.r;
			});
		st.build(0, siz - 1, 1);
		for (int i = 1; i <= siz; ++i) {
			st.ins(0, i - 1, -d * (vl[i] - vl[i - 1]), 1);
			while (ptr <= m && a[ptr].r == i)
				st.ins(0, a[ptr].l, a[ptr].v, 1), ptr++;
			tmax(ans, st.que(que(vl[i] - k), i - 1, 1));
			if (i + 1 < siz)st.ins(i + 1, i + 1, ans, 1);
		}
		writi(ans);
	}
	return 0;
}
//Nullptr.jpg
//私は猫です