#include<bits/stdc++.h>
using namespace std;
#define int long long
int n, m, k, rp[500005], mx[500005], dp[500005], md[500005];
struct node {
	int l, r, v;
	node(int l = 0, int r = 0, int v = 0) :l(l), r(r), v(v) {};
	inline bool operator<(const node& r) { return v > r.v; }
}p[500005];
inline int find(int p) {
	return rp[p] != p ? rp[p] = find(rp[p]) : p;
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m >> k; rp[m + 1] = m + 1;
	for (int i = 1; i <= m; ++i) rp[i] = i;
	for (int i = 1, a, b, c; i <= n; ++i)
		cin >> a >> b >> c, p[i] = node(a + k - 1, b, c);
	sort(p + 1, p + n + 1);
	for (int i = 1; i <= n; ++i)
		if (p[i].l <= p[i].r)
			for (int c = find(p[i].l); c <= p[i].r; c = find(c))
				mx[c] = p[i].v, rp[c] = find(c + 1);
	for (int i = k; i <= m; ++i)
		dp[i] = mx[i] + md[i - k],
		md[i] = max(md[i - 1], dp[i]);
	cout << md[m] << endl;
}