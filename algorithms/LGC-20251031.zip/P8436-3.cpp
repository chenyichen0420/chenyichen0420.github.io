#include<bits/stdc++.h>
using namespace std;
#define int long long
inline void tmin(int& l, int r) {
	(l > r) && (l = r);
}
struct node {
	int p, id;
	node(int ip = 0, int ii = 0) :p(ip), id(ii) {};
};
int n, m; vector<node>son[500005];
bool isc[500005]; int ans; vector<int>anv[500005];
int dfn[500005], low[500005], cnt;
int eid, anid[4000005]; bool vis[4000005];
#define sp son[p][i].p
inline void tarjan(const int& p, const int& id) {
	dfn[p] = low[p] = ++cnt;
	for (int i = 0; i ^ son[p].size(); ++i)
		if (!dfn[sp]) {
			tarjan(sp, son[p][i].id), tmin(low[p], low[sp]);
			if (dfn[p] < low[sp])
				vis[son[p][i].id] = vis[anid[son[p][i].id]] = 1;
		}
		else if (son[p][i].id ^ anid[id]) tmin(low[p], dfn[sp]);
}
inline void dfs(const int& p) {
	isc[p] = 1; anv[ans].push_back(p);
	for (int i = 0; i ^ son[p].size(); ++i)
		if (!vis[son[p][i].id] && !isc[sp]) dfs(sp);
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m;
	for (int i = 1, l, r; i <= m; ++i) {
		cin >> l >> r;
		if (l ^ r)
			son[l].emplace_back(node(r, ++eid)),
			son[r].emplace_back(node(l, ++eid)),
			anid[eid] = eid - 1, anid[eid - 1] = eid;
	}
	for (int i = 1; i <= n; ++i) if (!dfn[i]) tarjan(i, 0);
	for (int i = 1; i <= n; ++i) if (!isc[i]) ans++, dfs(i);
	cout << ans << endl;
	for (int i = 1; i <= ans; ++i) {
		cout << anv[i].size() << " ";
		while (!anv[i].empty()) 
			cout << anv[i].back() << " ", 
			anv[i].pop_back();
		cout << endl;
	}
	return 0;
}