#include<bits/stdc++.h>
using namespace std;
struct node{
	int x,y;
}p[505];
int n,k,dp[505][105],ans;
inline bool cmp(node l,node r){
	if(l.x==r.x) return l.y<r.y;
	return l.x<r.x;
}
int main(){
	cin>>n>>k; ans=k+1;
	for(register int i=1;i<=n;++i) cin>>p[i].x>>p[i].y;
	sort(p+1,p+n+1,cmp);
	for(register int i=1;i<=n;++i){
		for(register int j=0;j<=k;++j){
			dp[i][j]=1;
			for(register int _k=0;_k<i;_k++){
				if(p[_k].x>p[i].x||p[_k].y>p[i].y) continue;
				int dis=p[i].x-p[_k].x+p[i].y-p[_k].y-1;
				if(j>=dis) dp[i][j]=max(dp[i][j],dp[_k][j-dis]+1);
			}
			ans=max(ans,dp[i][k]+k);
		}
	}
	cout<<ans<<endl;
	return 0;
}