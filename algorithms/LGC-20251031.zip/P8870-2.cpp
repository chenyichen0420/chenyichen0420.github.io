#include<iostream>
#include<algorithm>
using namespace std;
int a, b, na[200005], nb[200005], ans[200005];
int main() {
	cin >> a >> b;
	for (int i = 1; i <= a; ++i) scanf("%d", &na[a - i + 1]);
	for (int i = 1; i <= b; ++i) scanf("%d", &nb[b - i + 1]);
	int len = max(a, b);
	for (int i = 1; i <= len; ++i) ans[i] = na[i] + nb[i];
	for (int i = 1; i <= len; ++i) {
		ans[i + 1] += ans[i] / (i + 1);
		ans[i] %= (i + 1);
	}
	if (ans[len + 1] > 0) len++;
	for (int i = len; i >= 1; i--) printf("%d ", ans[i]);
	return 0;
}