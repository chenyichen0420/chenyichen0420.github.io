#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,k,q,num,x,y,qzh[500005];
map<pair<int,int>,int>rans;
signed main(){
	scanf("%lld%lld%lld",&n,&k,&q);
	for(int i=1;i<=k;++i)
		for(int j=1;j<=n;++j)
			scanf("%lld",&num),qzh[n*(i-1)+j]=qzh[n*(i-1)+j-1]+num;
	for(int i=1;i<=q;++i){
		cin>>x>>y; int ans=0;
		if(rans[make_pair(x,y)]) cout<<rans[make_pair(x,y)]<<endl;
		else{
			for(int j=1;j<=k;++j)
				ans=max(ans,qzh[n*(j-1)+y]-qzh[n*(j-1)+x-1]);
			printf("%lld\n",ans); rans[make_pair(x,y)]=ans;
		}
	}
	return 0;
}