#include<bits/stdc++.h>
using namespace std;
char c; int a,b,d;
int main(){
	while(cin>>c){
		if(c>='0'&&c<='9') a++;
		else if(c>='a'&&c<='z') b++;
		else d++;
	}
	cout<<a<<" "<<b<<" "<<d<<endl;
	return 0;
}