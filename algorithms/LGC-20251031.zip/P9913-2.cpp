#include<bits/stdc++.h>
using namespace std;
int n, t; bool can[26];
int main() {
	ios::sync_with_stdio(0);
	cin >> t; can[1] = can[4] = 1; can[2] = can[3] = can[5] = 0;
	while (t--) {
		cin >> n;
		if (n > 5)cout << "Yes\n";
		else if (can[n]) cout << "Yes\n";
		else cout << "No\n";
	}
	return 0;
}