#include<bits/stdc++.h>
using namespace std;
vector<int>son[1065];
int t, n, m, pid[10005], pc, d[1065][1065];
inline constexpr bool isp(int p) {
	for (int i = 2; i * i <= p; ++i)
		if (p % i == 0) return 0;
	return 1;
}
inline int diff(int a, int b) {
	return ((a % 10) != (b % 10)) +
		((a / 1000) != (b / 1000)) +
		((a / 10 % 10) != (b / 10 % 10)) +
		((a / 100 % 10) != (b / 100 % 10));
}
queue<int>q; int tp;
signed main() {
	ios::sync_with_stdio(0);
	for (int i = 1000; i <= 9999; ++i)
		if (isp(i)) {
			pid[i] = ++pc;
			for (int j = 1000; j != i; ++j)
				if (pid[j] && diff(i, j) == 1)
					son[pid[i]].emplace_back(pid[j]),
					son[pid[j]].emplace_back(pid[i]);
		}
	for (int i = 1; i <= pc; ++i) {
		q.emplace(i); d[i][i] = 1;
		while (q.size()) {
			tp = q.front(); q.pop();
			for (int sp : son[tp])
				if (!d[i][sp])
					d[i][sp] = d[i][tp] + 1,
					q.emplace(sp);
		}
	}
	for (cin >> t; t; t--)
		if (cin >> n >> m, d[pid[n]][pid[m]]) cout << d[pid[n]][pid[m]] - 1 << endl;
		else cout << "Impossible\n";
}