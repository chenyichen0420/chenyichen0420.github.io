#include<bits/stdc++.h>
using namespace std;
struct node {
	int l, r, id;
}q[50005];
int n, m, v[50005], sz, cnt, b[50005], bcn, ans[50005];
unordered_map<int, int>id; vector<int>cls; int la[50005], fa[50005];
int lp[50005], tmp;
inline int solve(const int& l, const int& r) {
	tmp = 0;
	for (int i = l; i <= r; ++i)lp[v[i]] = 0;
	for (int i = l; i <= r; ++i)
		if (!lp[v[i]]) lp[v[i]] = i;
		else tmp = max(tmp, i - lp[v[i]]);
	return tmp;
}
signed main() {
	ios::sync_with_stdio(0); 
	cin >> n >> m; sz = ceil(sqrt(++n));
	for (int i = 2; i <= n; ++i) cin >> v[i], v[i] += v[i - 1];
	for (int i = 1; i <= n; ++i) {
		b[i] = (i - 1) / sz + 1;
		if (!id.count(v[i])) id[v[i]] = ++cnt;
		v[i] = id[v[i]]; bcn = b[i];
	}
	for (int i = 1; i <= m; ++i) cin >> q[i].l >> q[i].r, q[i].r++, q[i].id = i;
	sort(q + 1, q + m + 1, [](node l, node r) {
		return b[l.l] != b[r.l] ? l.l < r.l : l.r < r.r;
		});
	for (int i = 1, j = 1; j <= bcn; ++j) {
		int rb = min(n, j * sz), lp = rb + 1, rp = rb, ant = 0;
		for (; b[q[i].r] == j; i++) ans[q[i].id] = solve(q[i].l, q[i].r);
		for (; b[q[i].l] == j; i++) {
			while (rp < q[i].r) {
				rp++; la[v[rp]] = rp;
				if (!fa[v[rp]]) fa[v[rp]] = rp, cls.emplace_back(v[rp]);
				else ant = max(ant, rp - fa[v[rp]]);
			}
			int rew = ant;
			while (lp > q[i].l) {
				lp--;
				if (!la[v[lp]]) la[v[lp]] = lp;
				else ant = max(ant, la[v[lp]] - lp);
			}
			ans[q[i].id] = ant;
			while (lp <= rb) {
				if (la[v[lp]] == lp) la[v[lp]] = 0; lp++;
			}
			ant = rew;
		}
		while (cls.size()) fa[cls.back()] = la[cls.back()] = 0, cls.pop_back();
	}
	for (int i = 1; i <= m; ++i) cout << ans[i] << endl;
}
//无语了，我本来写的有一份的，SPOJ 跑的实在太慢了，死卡卡不过去，只有调别的题的代码。