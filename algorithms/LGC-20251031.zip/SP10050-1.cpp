#include<bits/stdc++.h>
using namespace std;
#define int long long
int t, a, b; unordered_map<int, int>fv;
inline int qpow(__int128 a, int b, int p) {
	__int128 ret = 1;
	for (; b; b >>= 1, (a *= a) >= p && (a = a % p + p))
		(b & 1) && ((ret *= a) >= p) && (ret = ret % p + p);
	return ret;
}
inline int gfv(int v) {
	if (fv.count(v)) return fv[v];
	int r = v, t = v;
	for (int i = 2; i * i <= v; ++i)
		if (v % i == 0) {
			r = r / i * (i - 1);
			while (v % i == 0) v /= i;
		}
	if (v != 1) r = r / v * (v - 1);
	return fv[t] = r;
}
inline int get(int c, int p) {
	if (c == b || p == 1) return 1;
	return qpow(a, get(c + 1, gfv(p)), p);
}
signed main() {
	for (cin >> t; t; t--) {
		cin >> a >> b;
		if (a == 1 || b == 0) {
			fprintf(stdout, "%d\n", 1);
			continue;
		}
		if (a == 0) {
			fprintf(stdout, "%d\n", ((b & 1) ? 0 : 1));
			continue;
		}
		if (b == 1) {
			if (a < 1000000000) fprintf(stdout, "%d\n", (signed)a);
			else fprintf(stdout, "...%09d\n", (signed)a % 1000000000);
			continue;
		}
		bool ful = 0;
		if (a == 2 && b >= 5) ful = 1;
		else if (a >= 3 && a <= 9 && b >= 3) ful = 1;
		else if (a >= 10) ful = 1;
		signed tmp = get(0, 1000000000) % 1000000000; bool ex = 0;
		if (ful) fprintf(stdout, "...%09d\n", (signed)tmp);
		else fprintf(stdout, "%d\n", (signed)tmp);
	}
}