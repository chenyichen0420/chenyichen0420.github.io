v1=int(input())
v2=int(input())
# read in
l=0
r=1
while(r**v1<=v2):
    r=r*2
    l=r//2
# binary serch base
while(l+1<r):
    mid=(l+r)//2
    if (mid**v1<=v2): l=mid
    else: r=mid
# binary serching
print(l)
#c++ pyer