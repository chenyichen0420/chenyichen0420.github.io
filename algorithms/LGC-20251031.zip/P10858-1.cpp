#include <bits/stdc++.h>
using namespace std;
#define int long long
int t,n,m,v; 
signed main() {
	ios::sync_with_stdio(0);
	cin>>t;
	while(t--){
		cin>>n>>m;
		v=n*m/__gcd(n,m)/__gcd(n,m);
		cout<<"1 "<<v<<endl;
	}
	return 0;
}