#include<bits/stdc++.h>
using namespace std;
struct node {
	int p, id;
	node(int pi = 0, int vi = 0) :p(pi), id(vi) {};
};
int n, m, dp[50005][2], cnt, dfn[50005], low[50005]; vector<node>son[50005];
int f[50005], v[50005], fe[50005];
inline void tmin(int& l, int r) { (l > r) && (l = r); }
inline void mkdp(int fp, int p) {
	int v0 = 0, v1 = 0, t0, t1;
	for (int i = p;i != fp;i = f[i])
		t0 = v0 + dp[i][0], t1 = v1 + dp[i][1],
		v0 = max(t0, t1), v1 = t0;
	dp[fp][0] += v0; v0 = 0; v1 = -1e9;
	for (int i = p;i != fp;i = f[i])
		t0 = v0 + dp[i][0], t1 = v1 + dp[i][1],
		v0 = max(t0, t1), v1 = t0;
	dp[fp][1] += v1;
}
inline void tarjan(int p, int id) {
	dfn[p] = low[p] = ++cnt; dp[p][1] = 1;
	for (const node& sp : son[p])
		if (!dfn[sp.p]) {
			f[sp.p] = p; fe[sp.p] = sp.id;
			tarjan(sp.p, sp.id), tmin(low[p], low[sp.p]);
			if (low[sp.p] > dfn[p])
				dp[p][0] += max(dp[sp.p][0], dp[sp.p][1]),
				dp[p][1] += dp[sp.p][0];
		}
		else if (id != sp.id) tmin(low[p], dfn[sp.p]);
	for (const node& sp : son[p])
		if (dfn[p] < dfn[sp.p] && fe[sp.p] != sp.id)
			mkdp(p, sp.p);
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m;
	for (int i = 1, l, r;i <= m;++i)
		cin >> l >> r,
		son[l].emplace_back(r, i),
		son[r].emplace_back(l, i);
	tarjan(1, 0); cout << max(dp[1][0], dp[1][1]) << endl;
}