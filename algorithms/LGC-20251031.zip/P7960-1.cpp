#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr int mod = 1e9 + 7;
#define sopt
struct IO {
#define mxsz (1 << 21)
	char buf[mxsz], * p1, * p2;
	char pbuf[mxsz], * pp;
	IO() : p1(buf), p2(buf), pp(pbuf) {}
	~IO() { fwrite(pbuf, 1, pp - pbuf, stdout); }
	inline char gc() {
		if (p1 == p2) p2 = (p1 = buf) + fread(buf, 1, mxsz, stdin);
		return p1 == p2 ? ' ' : *p1++;
	}
#ifndef sipt
	inline int read() {
		int r = 0; char c = gc(); while (c < '0' || c>'9') c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return r;
	}
#else
	inline int read() {
		int r = 0; char c = gc(); bool rev = 0;
		while (c < '0' || c>'9') rev |= (c == '-'), c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return rev ? ~r + 1 : r;
	}
#endif
	inline void push(const char& c) {
		if (pp - pbuf == mxsz) fwrite(pbuf, 1, mxsz, stdout), pp = pbuf;
		*pp++ = c;
	}
	inline void write(long long x) {
		static char sta[22]; int top = 0;
		do sta[top++] = x % 10, x /= 10; while (x);
		while (top) push(sta[--top] ^ 48);
	}
	inline void write(long long x, char opc) {
#ifdef sopt
		if (x < 0) push('-'), x = ~x + 1;
#endif
		write(x), push(opc);
	}
} io;
int t, n, np[20000005]; bool cn[20000005];
inline bool is7(int v) {
	while (v)
		if (v % 10 == 7) return 1;
		else v /= 10;
	return 0;
}
signed main() {
	ios::sync_with_stdio(0);
	for (int i = 1; i <= 2e7; ++i) {
		if (cn[i]) continue;
		if (cn[i] |= is7(i))
			for (int j = 1; i * j <= 2e7; ++j) cn[i * j] = 1;
	}
	for (int i = 2e7, j = 1e9; i; i--)
		np[i] = j, (!cn[i]) && (j = i);
	for (t = io.read(); t; t--)
		if (cn[n = io.read()]) io.write(-1, '\n');
		else io.write(np[n], '\n');
}