#include<bits/stdc++.h>
using namespace std;
#define int long long
int k, n, dp[31][16][11][8][7], a[6];
signed main() {
	ios::sync_with_stdio(0);
	while (cin >> n, n) {
		memset(a, 0, sizeof a);
		for (int i = 1; i <= n; ++i) cin >> a[i];
		memset(dp, 0, sizeof dp);
		dp[0][0][0][0][0] = 1;
		for (int p1 = 1; p1 <= a[1]; ++p1)
			for (int p2 = 0; p2 <= a[2] && p2 <= p1; ++p2)
				for (int p3 = 0; p3 <= a[3] && p3 <= p2; ++p3)
					for (int p4 = 0; p4 <= a[4] && p4 <= p3; ++p4)
						for (int p5 = 0; p5 <= a[5] && p5 <= p4; ++p5) {
							if (p1) dp[p1][p2][p3][p4][p5] += dp[p1 - 1][p2][p3][p4][p5];
							if (p2) dp[p1][p2][p3][p4][p5] += dp[p1][p2 - 1][p3][p4][p5];
							if (p3) dp[p1][p2][p3][p4][p5] += dp[p1][p2][p3 - 1][p4][p5];
							if (p4) dp[p1][p2][p3][p4][p5] += dp[p1][p2][p3][p4 - 1][p5];
							if (p5) dp[p1][p2][p3][p4][p5] += dp[p1][p2][p3][p4][p5 - 1];
						}
		cout << dp[a[1]][a[2]][a[3]][a[4]][a[5]] << endl;
	}
}