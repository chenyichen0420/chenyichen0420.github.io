#include<bits/stdc++.h>
using namespace std;
#define pb push_back
int t,n,a,b,dep[100005],siz[100005];vector<int>son[100005];
inline void dfs(int pos,int fa){
	dep[pos]=dep[fa]+1,siz[pos]=1;
	for(int i=0;i<son[pos].size();++i)
		if(son[pos][i]!=fa)
			dfs(son[pos][i],pos),
			siz[pos]+=siz[son[pos][i]];
} 
int main(){
	ios::sync_with_stdio(0);
	cin>>t;
	while(t--){
		cin>>n; 
		for(int i=1;i<=n;++i) son[i].clear();
		for(int i=1;i<n;++i)
			cin>>a>>b,
			son[a].pb(b),
			son[b].pb(a);
		dfs(1,0);
		for(int i=1;i<=n;++i)
			cout<<dep[i]<<" "<<n-siz[i]+1<<endl;
	} 
} 