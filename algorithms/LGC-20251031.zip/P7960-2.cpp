#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr int siz=1e7+20;
int t,n,cnt,tn[siz];
bitset<siz>ans;
inline bool check(int l){
	bool cn=0;
	while(l)
		cn|=(l%10==7),
		l/=10;
	return cn;
}
signed main() {
	ios::sync_with_stdio(0);
	for(int i=1;i<siz;++i)
		if(!ans[i]&&check(i))
			for(int j=1;i*j<siz;++j)
				ans[i*j]=1;
	for(int i=siz-1,ap=1e9;i>0;i--){
		tn[i]=ap;
		if(!ans[i]) ap=i;
	}
	for(cin>>t;t;t--){
		cin>>n;
		if(!ans[n])cout<<tn[n]<<endl;
		else cout<<"-1\n";
	}
	return 0;
}