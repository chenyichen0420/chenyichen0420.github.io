#include<bits/stdc++.h>
using namespace std;
#define int long long
int n, x, mx, mi, xt = 2147483647, it = -2147483647;
signed main() {
	cin >> n >> x; mi = mx = x;
	for (int i = 1; i < n; ++i) {
		cin >> x;
		if (x < mi)
			mi = x,
			it = max(it, x + mx);
		else if (x > mx)
			mx = x,
			xt = min(xt, x + mi);
		else
			xt = min(xt, x + mi),
			it = max(it, x + mx);
		//cerr << mi << " " << mx << " " << xt << " " << it << endl;
	}
	if (xt <= it) cout << "pigeon\n";
	else {
		cout << "lovely\n";
		double tmp = xt + it; tmp /= 4;
		printf("%.1lf", tmp);
	}
	return 0;
}