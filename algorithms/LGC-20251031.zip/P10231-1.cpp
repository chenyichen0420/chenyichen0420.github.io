#include<bits/stdc++.h>
using namespace std;
#define int long long
struct node{
    int p,v; node(int p=0,int v=0):p(p),v(v){}
    friend bool operator<(const node&l,const node&r){
        return l.v<r.v;
    }
}tmp; priority_queue<node>pq; vector<int>ans;
vector<int>son[50005]; int n,m,d[50005],cnt;
bitset<50008>acc[50002]; bool vis[50005];
signed main(){
    ios::sync_with_stdio(0);
    cin>>n>>m;
    for(int i=1,l,r;i<=m;++i)
        cin>>l>>r,
        son[l].emplace_back(r),
        son[r].emplace_back(l);
    for(int i=1;i<=n;++i) 
        if(cin>>d[i],~d[i])
            acc[i][i]=1,pq.emplace(i,d[i]),cnt++;
    while(pq.size()){
        tmp=pq.top(); pq.pop();
        if(!tmp.v||vis[tmp.p]) continue;
        vis[tmp.p]=1;
        for(const int&sp:son[tmp.p])
            if(vis[sp]||d[sp]>tmp.v-1) continue;
            else if(~d[sp]&&d[sp]!=tmp.v-1) vis[sp]=1;
            else acc[sp]|=acc[tmp.p],pq.emplace(sp,d[sp]=tmp.v-1);
    }
    for(int i=1;i<=n;++i) if(d[i]<=0&&acc[i].count()==cnt) ans.emplace_back(i);
    cout<<ans.size()<<endl; for(int i:ans) cout<<i<<" ";
	return 0;
}
