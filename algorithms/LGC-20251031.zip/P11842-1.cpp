#include<bits/stdc++.h>
using namespace std;
#define int long long
vector<int>son[200005]; bool vis[200005],ris[200005];
int n,ans,dp[200005][2],a[200005],v[200005],fp,sp;
int ms1p;
inline void dps(int p,bool bypa){
	vis[p]=1; dp[p][0]=dp[p][1]=0;
	for(int sp:son[p]){
		if(vis[sp]) continue;
		dps(sp,bypa), dp[p][0]+=dp[sp][1],
		dp[p][1]+=min(dp[sp][0],dp[sp][1]);
	}
	if(p==ms1p) dp[p][0]=1e15;
	if(a[p]!=p)dp[p][1]+=v[p]; if(bypa) vis[p]=0;
}
inline void fring(int p){
	ris[p]=1;
	int sp=a[p];
		if(ris[sp]){
			fp=p,::sp=sp;
		}
		else fring(sp);
}
signed main(){
	ios::sync_with_stdio(0); cin>>n;
	for(int i=1;i<=n;++i) cin>>a[i];
	for(int i=1;i<=n;++i) cin>>v[i];
	for(int i=1;i<=n;++i)
		if(a[i]!=i) son[a[i]].emplace_back(i);
	for(int i=1;i<=n;++i)
		if(!vis[i]){
			fring(i);
			if(fp==sp){
				dps(fp,0); ans+=min(dp[fp][0],dp[fp][1]);
			}
			else{
				int ret=1e15;
				ms1p=sp; dps(fp,1);
				ret=min({ret,dp[fp][0],dp[fp][1]});
				ms1p=0; dps(fp,0);
				ret=min(ret,dp[fp][1]);
				ans+=ret;
			}
		}
	cout<<ans<<endl;
}