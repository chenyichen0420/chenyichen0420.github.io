#include<bits/stdc++.h>
using namespace std;
inline int as(int x) {
	return x > 0 ? x : (~x + 1);
}
struct node {
	int v, p;
	node(int vi = 0, int pi = 0) {
		v = vi, p = pi;
	}
	friend bool operator<(const node& l, const node& r) {
		return as(l.v) > as(r.v);
	}
}; priority_queue<node>pq;
int n, m, a[100005], l[100005], r[100005], cnt, tmp, ans, tl; bool vis[100005];
inline void del(int x) {
	vis[x] = 1;
	l[r[x]] = l[x];
	r[l[x]] = r[x];
}
signed main() {
	ios::sync_with_stdio(false);
	cin >> n >> m;
	for (int i = 1; i <= n; ++i) {
		cin >> a[i];
		if ((a[i - 1] > 0) == (a[i] > 0) && i > 1)
			a[i - 1] += a[i], i--, n--;
	}
	for (int i = 1; i <= n; ++i)
		l[i] = i - 1, r[i] = i + 1, pq.push(node(a[i], i)),
		cnt += (a[i] > 0), ans += (a[i] > 0) * a[i];
	while (cnt-- > m) {
		while (vis[pq.top().p]) pq.pop();
		tmp = pq.top().p; pq.pop();
		if (l[tmp] > 0 && r[tmp] <= n) ans -= as(a[tmp]);
		else if (a[tmp] > 0) ans -= a[tmp];
		else { cnt++; continue; }
		a[tmp] += a[l[tmp]] + a[r[tmp]];
		del(l[tmp]); del(r[tmp]);
		pq.push(node(a[tmp], tmp));
	}
	cout << ans << endl;
	return 0;
}