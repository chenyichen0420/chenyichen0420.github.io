#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online = 0;
constexpr int mod = 998244353;
int t, n, m, c, f, id, r[1005][1005], d[1005][1005];
char ty[1005][1005];
int ac, af, sr[1005][1005], pr[1005][1005];
signed main() {
	if (online)
		freopen("plant.in", "r", stdin),
		freopen("plant.out", "w", stdout);
	ios::sync_with_stdio(0);
	for (cin >> t >> id; t; t--) {
		cin >> n >> m >> c >> f;
		memset(r, 0, sizeof r);
		memset(d, 0, sizeof d);
		memset(sr, 0, sizeof sr);
		memset(pr, 0, sizeof pr);
		ac = af = 0;
		for (int i = 1; i <= n; ++i)
			for (int j = 1; j <= m; ++j)
				cin >> ty[i][j];
		for (int i = 1; i <= n; ++i)
			for (int j = m; j > 0; j--)
				if (ty[i][j] ^ 48) r[i][j] = 0;
				else r[i][j] = r[i][j + 1] + 1;
		for (int j = 1; j <= m; ++j)
			for (int i = n; i > 0; --i) {
				if (ty[i][j] ^ 48) {
					d[i][j] = 0; continue;
				}
				d[i][j] = d[i + 1][j] + 1;
				if (d[i + 1][j])
					ac = (ac + (r[i][j] - 1) * sr[i + 2][j]) % mod,
					af = (af + (r[i][j] - 1) * pr[i + 2][j]) % mod;
				sr[i][j] = (sr[i + 1][j] + (r[i][j] - 1)) % mod;
				pr[i][j] = (pr[i + 1][j] + (r[i][j] - 1) * (d[i][j] - 1)) % mod;
			}
		cout << ac * c << " " << af * f << endl;
	}
}