#include<iostream>
#include<cstring>
#include<bitset>
using namespace std;
int t, n, a, sly[16];
inline int read() {
	register int r = 0; register char c = getchar();
	while (c<'0' || c>'9') c = getchar();
	while (c >= '0' && c <= '9') r = (r << 3) + (r << 1) + (c ^ 48), c = getchar();
	return r;
}
inline void write(int x) {
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
	return;
}
inline void slyp() {
	for (int i = 1; i <= 15; ++i)
		sly[i] += a % 10, a /= 10;
}
inline int cntt() {
	int tmp = 0;
	for (int i = 1; i <= 15; ++i)
		tmp += sly[i] / 10, sly[i + 1] += sly[i] / 10;
	return tmp;
}
int main() {
	t = read();
	while (t--) {
		n = read(); memset(sly, 0, sizeof sly);
		for (int i = 1; i <= n; ++i) a = read(), slyp();
		cout << cntt() << endl;
	}
}