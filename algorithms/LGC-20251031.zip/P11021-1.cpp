#include<bits/stdc++.h>
using namespace std;
struct node {
	int l, r, p;
}a[100005];
int n, m, mx[100005], l, r, ps[100005], fmx[100005], bmx[100005], lp, rp, mid;
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m;
	for (int i = 1; i <= n; ++i)
		cin >> a[i].l >> a[i].r, a[i].p = i;
	sort(a + 1, a + n + 1, [](node l, node r) { return l.r < r.r; });
	for (int i = 1; i < n; ++i)
		mx[i] = abs(a[i + 1].l - a[i].l) / abs(a[i + 1].r - a[i].r), ps[a[i].p]=i;
	for (int i = 1; i <= n; ++i) fmx[i] = max(fmx[i - 1], mx[i]);
	for (int i = n; i >= 1; --i) bmx[i] = max(bmx[i + 1], mx[i]);
	mx[1] = bmx[2]; mx[n] = fmx[n - 2]; ps[a[n].p] = n;
	for (int i = 2; i < n; ++i) mx[i] = max(fmx[i - 2], bmx[i + 1]);
	for (int i = 2; i < n; ++i)
		mx[i] = max(mx[i], abs(a[i + 1].l - a[i - 1].l) / abs(a[i + 1].r - a[i - 1].r));
	for (int i = 1; i <= m; ++i) {
		cin >> l >> r; l = ps[l];
		int ans = mx[l]; lp = 0; rp = n;
		while (lp != rp)
			if (a[mid = lp + rp + 1 >> 1].r > r) rp = mid - 1;
			else lp = mid;
		ans = max(ans, abs(a[lp + 1].l - a[l].l) / abs(a[lp + 1].r - r));
		if (lp > 0 && a[lp].r - r != 0)ans = max(ans, abs(a[lp].l - a[l].l) / abs(a[lp].r - r));
		else if (lp > 0) ans = max(ans, abs(a[lp - 1].l - a[l].l) / abs(a[lp - 1].r - r));
		cout << ans << endl;
	}
}