#include<bits/stdc++.h>
using namespace std;
int t, n; bool cn;
struct node {
	int p, v;
	node(int pi = 0, int vi = 0) :p(pi), v(vi) {};
	inline bool operator<(const node& r) {
		return v != r.v ? v > r.v:p < r.p;
	}
}a[200005]; vector<node>ps;
int main() {
	ios::sync_with_stdio(0);
	for (cin >> t; t; t--) {
		cin >> n; ps.clear();
		for (int i = 1; i <= n; ++i)
			cin >> a[i].v, a[i].p = i;
		sort(a + 1, a + n + 1); 
		ps.emplace_back(a[1]); cn = 1;
		for (int i = 2; i <= n; ++i)
			if (a[i].p < ps.back().p) {
				if (cn && (ps.size() < 2 || a[i].p > ps[ps.size() - 2].p))
					cn = 0, ps.emplace_back(a[i]);
			}
			else ps.emplace_back(a[i]);
		for (int i = 0; i != ps.size(); ++i)
			cout << ps[i].v << " \n"[i == ps.size() - 1];
	}
}