#include<iostream>
#include<cmath>
#include<algorithm>
using namespace std;
int main() {
	int a, b, c, d, e, f;
	cin >> a >> b >> c >> d >> e;
	f = a + b + c + d + e;
	if (f < 100) cout << "Gray";
	else if (f < 120) cout << "Blue";
	else if (f < 170) cout << "Green";
	else if (f < 230) cout << "Orange";
	else cout << "Red";
}