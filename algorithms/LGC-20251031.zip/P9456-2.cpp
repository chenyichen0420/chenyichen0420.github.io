#include<bits/stdc++.h>
using namespace std;
int n,m,h,v; bool fw[201][201],lf[201][201],dw[201][201];
int main(){
	ios::sync_with_stdio(false);
	cin>>n>>m>>h;
	for(int i=1;i<=h;++i){
		for(int j=1;j<=n;++j){
			for(int k=1;k<=m;++k){
				cin>>v;
				if(v){
					fw[i][j]=1;
					lf[i][k]=1;
					dw[j][k]=1;
				}
			}
		}
	}
	for(int i=h;i>=1;--i){
		for(int j=1;j<=n;++j){
			cout<<fw[i][j]<<" ";
		}
		cout<<endl;
	}
	for(int i=h;i>=1;--i){
		for(int j=m;j>=1;--j){
			cout<<lf[i][j]<<" ";
		}
		cout<<endl;
	}
	for(int i=m;i>=1;--i){
		for(int j=1;j<=n;++j){
			cout<<dw[j][i]<<" ";
		}
		cout<<endl;
	}
	return 0;
} 