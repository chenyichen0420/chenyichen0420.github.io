#include<bits/stdc++.h>
using namespace std;
constexpr int md = 1e9;
int t, n, a[500005], ans; stack<int>sx, si;
inline int inc(int l, const int r) { return (l += r) >= md && (l -= md), l; }
inline int dec(int l, const int r) { return (l -= r) < 0 && (l += md), l; }
inline void sinc(int& l, const int r) { (l += r) >= md && (l -= md); }
inline void tmin(int& l, const int r) { (l > r) && (l = r); }
inline void tmax(int& l, const int r) { (l < r) && (l = r); }
struct seg_tree {
	struct node {
		int l1, l2, v1, v2, mx1, mx2, mi1, mi2, mi, mx, l, r;
	}re[500005 << 2];
	inline void pup(int p) {
		re[p].v1 = inc(re[p << 1].v1, re[p << 1 | 1].v1); 
		re[p].mx1 = inc(re[p << 1].mx1, re[p << 1 | 1].mx1);
		re[p].mi1 = inc(re[p << 1].mi1, re[p << 1 | 1].mi1);
		re[p].v2 = inc(re[p << 1].v2, re[p << 1 | 1].v2); 
		re[p].mx2 = inc(re[p << 1].mx2, re[p << 1 | 1].mx2); 
		re[p].mi2 = inc(re[p << 1].mi2, re[p << 1 | 1].mi2);
	}
	inline void nmi(int p, int v) {
		tmin(re[p].mi, v);
		re[p].v1 = re[p].mx1 * 1ll * v % md;
		re[p].v2 = re[p].mx2 * 1ll * v % md;
		re[p].mi1 = re[p].l1 * 1ll * v % md;
		re[p].mi2 = re[p].l2 * 1ll * v % md;
	}
	inline void nmx(int p, int v) {
		tmax(re[p].mx, v);
		re[p].v1 = re[p].mi1 * 1ll * v % md;
		re[p].v2 = re[p].mi2 * 1ll * v % md;
		re[p].mx1 = re[p].l1 * 1ll * v % md;
		re[p].mx2 = re[p].l2 * 1ll * v % md;
	}
	inline void pud(int p) {
		if (re[p].mi != 1e9)
			nmi(p << 1 | 1, re[p].mi),
			nmi(p << 1, re[p].mi), re[p].mi = 1e9;
		if (re[p].mx)
			nmx(p << 1 | 1, re[p].mx),
			nmx(p << 1, re[p].mx), re[p].mx = 0;
	}
	void build(int l, int r, int p = 1) {
		re[p].l = l; re[p].r = r; re[p].l1 = r - l + 1;
		re[p].l2 = (l + r) * 1ll * re[p].l1 / 2 % md; re[p].mi = 1e9;
		if (l == r) return;
		build(l, (l + r >> 1), p << 1);
		build((l + r >> 1) + 1, r, p << 1 | 1);
	}
	void cmi(int l, int r, int v, int p = 1) {
		if (l <= re[p].l && re[p].r <= r) return nmi(p, v); pud(p);
		if (l <= re[p << 1].r) cmi(l, r, v, p << 1);
		if (re[p << 1].r < r) cmi(l, r, v, p << 1 | 1); pup(p);
	}
	void cmx(int l, int r, int v, int p = 1) {
		if (l <= re[p].l && re[p].r <= r) return nmx(p, v); pud(p);
		if (l <= re[p << 1].r) cmx(l, r, v, p << 1);
		if (re[p << 1].r < r) cmx(l, r, v, p << 1 | 1); pup(p);
	}
	int que(int l, int r, int p = 1) {
		if (l <= re[p].l && re[p].r <= r) return dec(t * 1ll * re[p].v1 % md, re[p].v2);
		pud(p); int ret = 0;
		if (l <= re[p << 1].r) sinc(ret, que(l, r, p << 1));
		if (re[p << 1].r < r) sinc(ret, que(l, r, p << 1 | 1));
		return ret;
	}
}sgt;
signed main() {
	ios::sync_with_stdio(0);
	cin >> n; sgt.build(1, n); t = 2;
	for (int i = 1; i <= n; i++) cin >> a[i];
	sx.emplace(0); si.emplace(0);
	for (int i = 1; i <= n; i++, t++) {
		while (sx.top() && a[sx.top()] <= a[i]) sx.pop();
		sgt.cmx(sx.top() + 1, i, a[i]); sx.emplace(i);
		while (si.top() && a[si.top()] >= a[i]) si.pop();
		sgt.cmi(si.top() + 1, i, a[i]); si.emplace(i);
		sinc(ans, sgt.que(1, i));
	}
	cout << ans << endl;
}