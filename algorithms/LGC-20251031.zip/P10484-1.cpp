#include<bits/stdc++.h>
using namespace std;
unsigned int w,n,a[16000005],b[16000005],v[50],tmp,tl,tr,ans;
void dfs1(int nnum){
	if(nnum>n){
		a[tl++]=tmp;
		return;
	}
	dfs1(nnum+1); tmp+=v[nnum];
	if(tmp<=w) dfs1(nnum+1); tmp-=v[nnum];
}
void dfs2(int nnum){
	if(nnum>n/2){
		b[tr++]=tmp;
		return;
	}
	dfs2(nnum+1); tmp+=v[nnum];
	if(tmp<=w) dfs2(nnum+1); tmp-=v[nnum];
}
inline unsigned int max_(unsigned int l,unsigned int r){
	return l<r?r:l;
}
int main(){
	ios::sync_with_stdio(false);
	cin>>w>>n;
	for(register int i=1;i<=n;++i) cin>>v[i];
	dfs1(n/2+1); dfs2(1); 
	sort(b+1,b+tr+1); sort(a+1,a+tl+1);
	for(register int i=1;i<=tr;++i)
		ans=max_(ans,b[i]+a[lower_bound(a+1,a+tl+1,w-b[i])-a-1]);
	cout<<ans<<endl;
} 