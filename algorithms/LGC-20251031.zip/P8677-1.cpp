#include<bits/stdc++.h>
using namespace std;
struct sut {
	int b, s;
	inline bool operator<(const sut& r) {
		return s - b < r.s - r.b;
	}
	inline sut operator+(const sut& r) {
		sut ret = { 0 };
		ret.s = s + r.s;
		ret.b = max(b, s + r.b);
		return ret;
	}
}v[100005]; vector<int>son[100005]; int n, ans, rt;
inline sut dfs(int p, int fa) {
	vector<sut>s(1, v[p]);
	for (int sp : son[p]) if (sp != fa)
		s.emplace_back(dfs(sp, p));
	sut ret = {0}; sort(s.begin(), s.end());
	for (const auto& v : s) ret = ret + v;
	return ret;
}
signed main() {
	ios::sync_with_stdio(0); cin >> n; rt = 1;
	for (int i = 1; i <= n; ++i) cin >> v[i].b;
	for (int i = 1; i <= n; ++i)
		cin >> v[i].s, v[i].b = max(v[i].b, v[i].s),
		(v[i] < v[rt]) && (rt = i);
	for (int i = 2, l, r; i <= n; ++i)
		cin >> l >> r, ans += r << 1,
		son[l].emplace_back(i),
		son[i].emplace_back(l);
	cout << ans << ' '; ans = 2e9;
	cout << dfs(rt, 0).b << endl;
}