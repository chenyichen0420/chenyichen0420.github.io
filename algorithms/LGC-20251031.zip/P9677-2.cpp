#include<iostream>
#include<cstring>
#include<bitset>
using namespace std;
int n, ans, t, a; bitset<500005>ins;
inline int read() {
	register int r = 0; register char c = getchar();
	while (c<'0' || c>'9') c = getchar();
	while (c >= '0' && c <= '9') r = (r << 3) + (r << 1) + (c ^ 48), c = getchar();
	return r;
}
inline void write(int x) {
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
	return;
}
int main() {
	t = read();
	while (t--) {
		n = read(); ans = n; ins.reset();
		for (int i = 1; i <= n; ++i) a = read() , ins[a] = 1, ans -= ins[a + 1];
		write(ans); putchar('\n');
	}
}