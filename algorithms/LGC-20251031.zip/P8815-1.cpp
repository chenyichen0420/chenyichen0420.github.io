#include<bits/stdc++.h>
using namespace std;
struct token{
	short int type,val,prio; char op;
	token(short int it,short int iv,short int ip,char io){
		type=it,val=iv,prio=ip,op=io;
	}
}; string s;
struct dat{
	int val,co,ca;
};
vector<token>a,b;
void toke(){
	int len=s.size();
	for(int i=0;i<s.size();++i){
		if(s[i]=='0'||s[i]=='1') a.push_back(token(1,s[i]^48,-1,'0'));
		else{
			if(s[i]=='(') a.push_back(token(0,-1,0,s[i]));
			else if(s[i]=='|') a.push_back(token(0,-1,1,s[i]));
			else if(s[i]=='&') a.push_back(token(0,-1,2,s[i]));
			else a.push_back(token(0,-1,3,s[i]));
		}
	}
}
void back(){
	stack<token>st;
	for(int i=0;i<a.size();++i){
		if(a[i].type==1) b.push_back(a[i]);
		else if(a[i].op==')'){
			while(st.top().op!='(') b.push_back(st.top()),st.pop();
			st.pop();
		}
		else if(a[i].op=='(') st.push(a[i]);
		else{
			while(!st.empty()&&st.top().prio>=a[i].prio) b.push_back(st.top()),st.pop();
			st.push(a[i]);
		}
	}
	while(!st.empty()) b.push_back(st.top()),st.pop();
}
dat getans(){
	stack<dat>st;
	for(int i=0;i<b.size();++i){
		if(b[i].type==1) st.push((dat){b[i].val,0,0});
		else{
			dat y=st.top(); st.pop(); dat x=st.top(),z; st.pop();
			if(b[i].op=='|'){
				z.val=x.val|y.val;
				if(x.val==1) z.ca=x.ca,z.co=x.co+1;
				else z.ca=x.ca+y.ca,z.co=x.co+y.co;
			}
			else if(b[i].op=='&'){
				z.val=x.val&y.val;
				if(x.val==0) z.ca=x.ca+1,z.co=x.co;
				else z.ca=x.ca+y.ca,z.co=x.co+y.co;
			}
			st.push(z);
		}
	}
	return st.top();
}
int main(){
	ios::sync_with_stdio(false);
	cin>>s; toke(); back();
	dat ans=getans();
	cout<<ans.val<<endl<<ans.ca<<" "<<ans.co<<endl;
	return 0;
}