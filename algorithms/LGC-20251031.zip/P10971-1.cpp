#include<bits/stdc++.h>
using namespace std;
#define int long long
struct cf { int x, y; }cc[32][5005], tmp;
int n, m, t[32], ans, ap[32], dp[32][5005], s[32]; pair<int, int>a[32];
inline void go(const cf& l, const cf& r) {
	if (l.x == r.x) s[1]++, s[r.x + 1]--;
	else s[l.x + 1]++, s[r.x + 1]--;
	if (l.y) go(cc[l.x][l.y], l);
}
signed main() {
	ios::sync_with_stdio(0); cin >> n >> m;
	for (int i = 1; i <= n; ++i) cin >> a[i].first, a[i].second = i;
	sort(a + 1, a + n + 1, greater<pair<int, int>>());
	for (int i = 1; i <= n; ++i) s[i] = s[i - 1] + a[i].first;
	memset(dp, 0x3f, sizeof dp); dp[0][0] = 0;
	for (int i = 1; i <= n; ++i)
		for (int j = i; j <= m; ++j) {
			int ret = dp[i][j - i]; cc[i][j] = { i, j - i };
			for (int k = 0, val; k != i; ++k)
				if ((val = dp[k][j - (i - k)] + k * (s[i] - s[k])) < ret)
					ret = val, cc[i][j] = { k, j - (i - k) };
			dp[i][j] = min(dp[i][j], ret);
		}
	cout << dp[n][m] << endl;
	memset(s, 0, sizeof s);
	go(cc[n][m], cf{ n,m });
	for (int i = 1; i <= n; ++i) s[i] += s[i - 1];
	for (int i = 1; i <= n; ++i) ap[a[i].second] = i;
	for (int i = 1; i <= n; ++i) cout << s[ap[i]] << " ";
}