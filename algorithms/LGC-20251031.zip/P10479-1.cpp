#include<bits/stdc++.h>
using namespace std;
int n, m, t, a[100005], tn[100005], v, nt[100005]; string s1, s2;
inline void solve() {
	s1 = ' ' + s1; s2 = ' ' + s2;
	for (int i = 2, j = 0; i < s2.size(); ++i) {
		while (j && s2[j + 1] != s2[i]) j = nt[j];
		if (s2[j + 1] == s2[i]) j++;
		nt[i] = j;
	}
	for (int i = 1, j = 0; i < s1.size(); ++i) {
		while (j && s2[j + 1] != s1[i]) j = nt[j];
		if (s2[j + 1] == s1[i]) j++;
		tn[j]++;
	}
	for (int i = s2.size(); i; --i)
		tn[nt[i]] += tn[i];
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m >> t >> s1 >> s2; solve();
	while (t--) cin >> v, cout << tn[v] - tn[v + 1] << endl;
	return 0;
}