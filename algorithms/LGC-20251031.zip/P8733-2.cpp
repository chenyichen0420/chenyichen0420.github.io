#include<bits/stdc++.h>
using namespace std;
#define int long long
struct pos { int x, y; }p[25];
int n, m, l2[1 << 20 | 2]; vector<int>v[20];
double dp[1 << 20 | 2][20], dis[20][20];
inline int sqr(int x) { return x * x; }
inline double gdis(pos l, pos r) {
	return sqrt(sqr(l.x - r.x) + sqr(l.y - r.y));
}
inline int lb(int x) {
	return x & ~x + 1;
}
inline void tmin(double& l, const double& r) {
	(l > r) && (l = r);
}
signed main() {
	ios::sync_with_stdio(0); cin >> n >> m;
	for (int i = 0; i < n; ++i) cin >> p[i].x >> p[i].y;
	for (int i = 0; i < n; ++i)
		for (int j = 0; j < n; ++j)
			if ((dis[i][j] = gdis(p[i], p[j])) > m)
				dis[i][j] = 1e12;
	for (int k = 0; k < n; ++k)
		for (int i = 0; i < n; ++i)
			for (int j = 0; j < n; ++j)
				tmin(dis[i][j], dis[i][k] + dis[k][j]);
	for (int i = 0; i < 1ll << n; ++i)
		for (int j = 0; j < n; ++j) dp[i][j] = 1e12;
	dp[1][0] = 0;
	for (int i = 0; i < n; ++i) l2[1ll << i] = i;
	for (int i = 1; i < 1ll << n; ++i)
		for (int ti = i; ti;) {
			int tp = lb(ti); ti -= tp; tp = l2[tp];
			for (int ps = 0; ps < n; ++ps)
				tmin(dp[i | (1ll << ps)][ps], dp[i][tp] + dis[tp][ps]);
		}
	printf("%.2lf\n", dp[(1ll << n) - 1][0]);
	return 0;
}