#include<bits/stdc++.h>
using namespace std;
#define int long long
mt19937 mt(time(0) + clock()); int rt, lc, rc, tc;
class tree_fhq {
	struct node { int v, r, s, ls, rs; }re[200005]; int cc;
	inline int newn(int v) { return re[++cc].v = v, re[cc].r = mt(), re[cc].s = 1, cc; }
	inline void pup(int p) { re[p].s = re[re[p].ls].s + re[re[p].rs].s + 1; }
	inline void split(int p, int v, int& l, int& r) {
		if (!p) return void(l = r = 0);
		if (re[p].v > v) r = p, split(re[p].ls, v, l, re[r].ls);
		else l = p, split(re[p].rs, v, re[l].rs, r); pup(p);
	}
	inline int merge(int l, int r) {
		if (!l || !r) return l | r;
		if (re[l].r < re[r].r) return re[l].rs = merge(re[l].rs, r), pup(l), l;
		else return re[r].ls = merge(l, re[r].ls), pup(r), r;
	}
	inline int getrk(int p, int v) {
		if (re[re[p].ls].s + 1 == v) return re[p].v;
		if (re[re[p].ls].s >= v) return getrk(re[p].ls, v);
		else return getrk(re[p].rs, v - re[re[p].ls].s - 1);
	}
public:
	inline void ins(int v) { split(rt, v, lc, rc), rt = merge(merge(lc, newn(v)), rc); }
	inline void del(int v) {
		split(rt, v - 1, lc, tc), split(tc, v, tc, rc);
		rt = merge(merge(lc, merge(re[tc].ls, re[tc].rs)), rc);
	}
	inline int getrk(int v) { return getrk(rt, v); }
	inline int genrk(int v) {
		split(rt, v - 1, lc, rc); tc = re[lc].s;  rt = merge(lc, rc); return tc;
	}
	inline void pre(int v) {
		split(rt, v - 1, lc, rc); cout << getrk(lc, re[lc].s) << endl; rt = merge(lc, rc);
	}
	inline void nxt(int v) {
		split(rt, v, lc, rc); cout << getrk(rc, 1) << endl; rt = merge(lc, rc);
	}
}fq;
int n, m, a[200005], s[200005], ans;
signed main() {
	ios::sync_with_stdio(0); cin >> n >> m; fq.ins(0);
	for (int i = 1; i <= n; ++i) cin >> a[i], s[i] = s[i - 1] + a[i] - m;
	for (int i = 1; i <= n; ++i)
		ans += fq.genrk(s[i] + 1), fq.ins(s[i]);
	cout << ans << endl;
}