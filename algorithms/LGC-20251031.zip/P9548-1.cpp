#include<bits/stdc++.h>
using  namespace std;
#define int long long
int n,m,x,y,k;
signed main(){
	cin>>n>>m>>x>>y>>k;
	int ans=(n/x)*(m/y);
	cout<<(int)(ceil(double(ans-1 + (n%x?1:0)+(m%y?1:0))/k))<<" "<<ans-1 + (n%x?1:0)+(m%y?1:0)<<endl;
	return 0;
}