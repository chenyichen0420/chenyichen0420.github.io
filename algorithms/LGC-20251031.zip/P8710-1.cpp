#include<bits/stdc++.h>
using namespace std;
int n, m, f[10005], v[10005], sz[10005], ans[10005]; vector<int>son[10005];
inline int find(int p) {
	return f[p] ? find(f[p]) : p;
}
inline void merge(int l, int r) {
	l = find(l); r = find(r);
	if (l == r) return;
	if (sz[l] < sz[r]) swap(l, r);
	sz[l] += sz[r]; sz[r] = 0;
	f[r] = l; v[r] -= v[l];
}
inline void dfs(int p, int d) {
	ans[p] = d + v[p];
	for (int sp : son[p]) dfs(sp, ans[p]);
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m;
	for (int i = 1; i <= n; ++i) sz[i] = 1;
	for (int i = 1, t, l, r; i <= m; ++i)
		if (cin >> t >> l >> r, t & 1)
			merge(l, r);
		else v[find(l)] += r;
	for (int i = 1; i <= n; ++i)
		son[f[i]].emplace_back(i);
	dfs(0, 0);
	for (int i = 1; i <= n; ++i) cout << ans[i] << " ";
}