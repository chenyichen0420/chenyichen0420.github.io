#include<bits/stdc++.h>
using namespace std;
int n, m; vector<int>son[500005]; stack<int>s;
int dfn[500005], low[500005], cnt; bool vis[2000005];
vector<vector<int>>ans;
inline void tmin(int& l, const int r) { (l > r) && (l = r); }
inline void tarjan(int p, int f) {
	dfn[p] = low[p] = ++cnt; int cn = 0; s.emplace(p);
	for (int sp : son[p])
		if (!dfn[sp]) {
			tarjan(sp, p); tmin(low[p], low[sp]); cn++;
			if (low[sp] >= dfn[p]) {
				ans.emplace_back(vector<int>(1, p));
				while (s.top() != sp)
					ans.back().emplace_back(s.top()), s.pop();
				ans.back().emplace_back(s.top()), s.pop();
			}
		}
		else if (sp != f) tmin(low[p], dfn[sp]);
	if (!cn && !f) ans.emplace_back(vector<int>(1, p));
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m;
	for (int i = 1, l, r; i <= m; ++i)
		cin >> l >> r,
		son[l].emplace_back(r),
		son[r].emplace_back(l);
	for (int i = 1; i <= n; ++i)
		if (!dfn[i]) tarjan(i, 0);
	cout << ans.size() << endl;
	for (const vector<int>& v : ans) {
		cout << v.size() << " ";
		for (int i : v) cout << i << " ";
		cout << endl;
	}
}