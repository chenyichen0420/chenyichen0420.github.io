#include<iostream>
#include<cmath>
#include<vector>
using namespace std;
int main() {
	long long int a, b, tsum = 0;
	cin >> a >> b;
	vector<long int>num(a + 1, 1);
	vector<long int>sum(a + 1, 0);
	for (long long int i = 1; i <= a; i++) {
		cin >> num[i];
		sum[i] = sum[i - 1] + num[i];
	}
	for (long long int j = b; j <= a; j++) {
		tsum += sum[j] - sum[j - b];
	}
	cout << tsum << endl;
	return 0;
}