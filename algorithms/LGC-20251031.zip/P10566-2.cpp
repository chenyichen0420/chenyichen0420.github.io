#include<bits/stdc++.h>
using namespace std;
#define int long long
string s; int ans;
signed main() {
	ios::sync_with_stdio(0);
	cin >> s;
	for (int i = 0; i < s.size(); ++i)
		if (s[i] < 'A' || s[i]>'Z')
			ans += min(abs(s[i] - 'A'), abs(s[i] - 'Z'));
	cout << ans << endl;
	return 0;
}