from decimal import *
getcontext().prec=10000000
a=Decimal(input())
print((a+1)*(a+2)*(a+3)*(a+4)//24)