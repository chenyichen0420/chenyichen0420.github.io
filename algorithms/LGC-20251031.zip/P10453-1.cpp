#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m,t,col[100001],row[100001],x,y,xavg,yavg,cc[100001],cr[100001],cmiv,rmiv,cans,rans;
inline void read(int &x){
	register int f=1;x=0;register char c=getchar();
	for(;c>'9'||c<'0';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=x*10+(c^48);
	x*=f;
}
signed main(){
	read(n); read(m); read(t); xavg=yavg=t; xavg/=n; yavg/=m;
	if(t%m&&t%n) cout<<"impossible\n",exit(0);
	for(int i=1;i<=t;++i) read(x),read(y),col[x]++,row[y]++;
	for(int i=1;i<=n;++i) cc[i]=cc[i-1]-xavg+col[i-1];sort(cc+1,cc+n+1);
	for(int i=1;i<=m;++i) cr[i]=cr[i-1]-yavg+row[i-1];sort(cr+1,cr+m+1);
	cmiv=cc[(n+1)/2]; rmiv=cr[(m+1)/2];
	for(int i=1;i<=n;++i) cans+=abs(cc[i]-cmiv);
	for(int i=1;i<=m;++i) rans+=abs(cr[i]-rmiv);
	if(t%n==0){
		if(t%m==0) cout<<"both "<<cans+rans<<endl;
		else cout<<"row "<<cans<<endl;
	}
	else if(t%m==0) cout<<"column "<<rans<<endl;
	return 0;
}