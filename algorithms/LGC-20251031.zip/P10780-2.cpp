#include <bits/stdc++.h>
using namespace std;
constexpr int p=1e4+7;
int n;char nt;
inline int qpow(int a){
	int tmp=1,b=p-2;
	while(b){
		if(b&1) tmp*=a,tmp%=p;
		a*=a; a%=p; b>>=1;
	}
	return tmp;
}
int main() {
	while(cin>>nt)
		n=((n<<1)+(n<<3)+(nt^48))%p;
	cout<<n*(n+1)%p*(n+2)%p*qpow(6)%p<<endl;
	return 0;
}