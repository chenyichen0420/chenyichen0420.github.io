#include<bits/stdc++.h>
using namespace std;
vector<int>son[200005], q[200005], cz[2000005];
int n, m, c[200005], t[200005], lp[200005], rp[200005], ap, p[2000005];
struct seg_tree {
	struct node { int ls, rs, v; }re[2000005 * 32]; int sc;
	inline void ins(int cp, int l, int r, int& p) {
		re[++sc] = re[p]; p = sc; if (re[p].v++, l == r) return;
		int mid = l + r >> 1;
		if (cp <= mid) ins(cp, l, mid, re[p].ls);
		else ins(cp, mid + 1, r, re[p].rs);
	}
	inline int que(int k, int l, int r, int lp, int rp) {
		if (l == r) return l;
		int lk = re[re[rp].ls].v - re[re[lp].ls].v, mid = l + r >> 1;
		if (k <= lk) return que(k, l, mid, re[lp].ls, re[rp].ls);
		return que(k - lk, mid + 1, r, re[lp].rs, re[rp].rs);
	}
}sgt;
int id[200005], rt[200005], cp[200005], fr[200005], fl[200005];
inline void dft(int p, int f) {
	lp[p] = ++ap; id[ap] = p; rt[p] = rt[id[ap - 1]];
	for (int j : q[p]) sgt.ins(j, 1, m, rt[p]);
	for (int sp : son[p]) if (sp != f) dft(sp, p);
	rp[p] = ap;
}
inline void get(int p, int f) {
	if (!c[p]) fr[p] = 0;
	else fr[p] = sgt.que(c[p], 1, m, rt[id[lp[p] - 1]], rt[id[rp[p]]]);
	fl[p] = max(fl[cp[t[p]]], fr[cp[t[p]]] + 1);
	if (fl[p] <= fr[p])
		cz[fl[p]].emplace_back(p),
		cz[fr[p] + 1].emplace_back(-p);
	int np = p; swap(np, cp[t[p]]);
	for (int sp : son[p]) if (sp != f) get(sp, p);
	swap(np, cp[t[p]]);
}
struct tree_array {
	int v[200005];
	inline static constexpr int lb(const int& p) { return p & ~p + 1; }
	inline void ins(int p, int t) {
		do v[p] += t; while ((p += lb(p)) <= n);
	}
	inline int que(int p) {
		int t = 0; do t += v[p]; while (p -= lb(p)); return t;
	}
}ta;
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m;
	for (int i = 1; i <= n; ++i) cin >> c[i];
	for (int i = 1; i <= n; ++i) cin >> t[i];
	for (int i = 1; i <= m; ++i)
		cin >> p[i], q[p[i]].emplace_back(i);
	for (int i = 1, l, r; i != n; ++i)
		cin >> l >> r,
		son[l].emplace_back(r),
		son[r].emplace_back(l);
	dft(1, 0); get(1, 0);
	for (int i = 1; i <= m; ++i) {
		for (int j : cz[i])
			if (j > 0) ta.ins(lp[j], 1), ta.ins(rp[j] + 1, -1);
			else ta.ins(lp[-j], -1), ta.ins(rp[-j] + 1, 1);
		cout << ta.que(lp[p[i]]) << ' ';
	}
}