#include<bits/stdc++.h>
using namespace std;
#define int long long
#define sipt
#define sopt
struct IO {
#define mxsz (1 << 20)
	char buf[mxsz], * p1, * p2;
	char pbuf[mxsz], * pp;
	IO() : p1(buf), p2(buf), pp(pbuf) {}
	~IO() { fwrite(pbuf, 1, pp - pbuf, stdout); }
	inline char gc() {
		if (p1 == p2) p2 = (p1 = buf) + fread(buf, 1, mxsz, stdin);
		return p1 == p2 ? ' ' : *p1++;
	}
#ifndef sipt
	inline int read() {
		int r = 0; char c = gc(); while (c < '0' || c>'9') c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return r;
	}
#else
	inline int read() {
		int r = 0; char c = gc(); bool rev = 0;
		while (c < '0' || c>'9') rev |= (c == '-'), c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return rev ? ~r + 1 : r;
	}
#endif
	inline void push(const char& c) {
		if (pp - pbuf == mxsz) fwrite(pbuf, 1, mxsz, stdout), pp = pbuf;
		*pp++ = c;
	}
	inline void write(int x) {
		static char sta[22]; int top = 0;
		do sta[top++] = x % 10, x /= 10; while (x);
		while (top) push(sta[--top] ^ 48);
	}
	inline void write(int x, char opc) {
#ifdef sopt
		if (x < 0) push('-'), x = ~x + 1;
#endif
		write(x), push(opc);
	}
} io;
int n, a[200005], sz, b[200005], ad[200005];
#define blk(i) (i / sz)
#define lb(i) (i * sz)
inline int rb(int p) {
	if (p == blk(n)) return n + 1;
	return (p + 1) * sz;
}
inline void pia(int p) {
	memcpy(b + lb(p), a + lb(p), sizeof(int) * (rb(p) - lb(p)));
	sort(b + lb(p), b + rb(p));
}
inline void ins(int l, int r, int v) {
	int bl = blk(l), br = blk(r);
	if (bl == br) {
		for (int i = l; i <= r; ++i) a[i] += v;
		pia(bl); return;
	}
	for (int i = l; i != sz * (bl + 1); ++i) a[i] += v;
	for (int i = br * sz; i <= r; ++i) a[i] += v;
	pia(bl); pia(br);
	for (int j = bl + 1; j != br; ++j) ad[j] += v;
	return;
}
inline int tmax(int& l, const int r) { return (l < r) && (l = r), 1; }
inline int que(int l, int r, int v) {
	int bl = blk(l), br = blk(r), ret = -1000000000000;
	if (bl == br) {
		for (int i = l; i <= r; ++i)
			(a[i] + ad[bl] < v) && tmax(ret, a[i] + ad[bl]);
		if (ret == -1000000000000) ret = -1;
		return ret;
	}
	for (int i = l; i != sz * (bl + 1); ++i)
		(a[i] + ad[bl] < v) && tmax(ret, a[i] + ad[bl]);
	for (int i = br * sz; i <= r; ++i)
		(a[i] + ad[br] < v) && tmax(ret, a[i] + ad[br]);
	for (int j = bl + 1; j != br; ++j) {
		int ps = lower_bound(b + lb(j), b + rb(j), v - ad[j]) - b - 1;
		if (ps >= lb(j)) tmax(ret, b[ps] + ad[j]);
	}
	if (ret == -1000000000000) ret = -1;
	return ret;
}
signed main() {
	ios::sync_with_stdio(0); sz = sqrt(n = io.read());
	for (int i = 0; i != n; ++i) a[i] = io.read(); memcpy(b, a, sizeof a);
	for (int i = 0; i <= blk(n); ++i) sort(b + lb(i), b + rb(i));
	for (int i = 1, o, l, r, v; i <= n; ++i)
		if (o = io.read(), l = io.read() - 1, r = io.read() - 1, v = io.read(), o)
			io.write(que(l, r, v), '\n');
		else ins(l, r, v);
}