#include<bits/stdc++.h>
using namespace std;
#define int long long
int a,b,p,ans;
signed main(){
	cin>>a>>b>>p; a%=p;
	while(b){
		if(b&1) ans+=a,ans%=p;
		a<<=1; a%=p; b>>=1;
	}
	cout<<ans<<endl;
	return 0;
} 