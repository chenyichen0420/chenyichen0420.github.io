#include<bits/stdc++.h>
using namespace std;
string s;
int p = 13331, siz,t[300001]; unsigned long long hsh[300001], pv[300001] = { 1 };
inline int maxcls(int lp, int rp) {
	register int l = 0, r = min(siz - lp + 1, siz - rp + 1), mid;
	while (l < r) {
		 mid = l + r + 1 >> 1;
		if (hsh[lp + mid - 1] - hsh[lp - 1] * pv[mid] == hsh[rp + mid - 1] - hsh[rp - 1] * pv[mid]) l = mid;
		else r = mid - 1;
	}
	return l;
}
inline bool cmp(int l, int r) {
	int lent = maxcls(l, r);
	int la = l + lent > siz ? -1 : s[l + lent];
	int lb = r + lent > siz ? -1 : s[r + lent];
	return la < lb;
}
int main() {
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	cin >> s; siz = s.size(); s = ' ' + s;
	for (register int i = 1;i <= siz;++i) {
		hsh[i] = hsh[i - 1] * p + s[i];
		pv[i] = pv[i - 1] * p;
		t[i] = i;
	}
	sort(t + 1, t + siz + 1, cmp);
	for (register int i = 1;i <= siz;++i)
		cout << t[i] - 1 << " ";
	cout << "\n0 ";
	for (register int i = 2;i <= siz;++i)
		cout << maxcls(t[i - 1], t[i]) << " ";
	cout << endl;
	return 0;
}