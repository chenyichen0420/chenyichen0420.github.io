#include<bits/stdc++.h>
using namespace std;
#define int long long
struct node {
	int p, id;
	node(int pi = 0, int ii = 0) :p(pi), id(ii) {};
}; vector<node>son[500005];
int n, m; vector<int>nsn[500005];
int vcn[500005], ecn[500005];
struct {
	int dfn[500005], low[500005], scc[500005];
	int sct, cnt; stack<int>s;
	inline void tmin(int& l, const int r) { (l > r) && (l = r); }
	inline void tarjan(int p, int cd) {
		dfn[p] = low[p] = ++cnt; s.emplace(p);
		for (node sp : son[p]) if (sp.id != cd)
			if (!dfn[sp.p]) tarjan(sp.p, sp.id), tmin(low[p], low[sp.p]);
			else tmin(low[p], dfn[sp.p]);
		if (low[p] == dfn[p]) {
			int np; ++sct; 
			do scc[np = s.top()] = sct, s.pop();
			while (np != p);
		}
	}
	inline void gowork() {
		for (int i = 1;i <= n;++i)
			if (!dfn[i]) tarjan(i, 0);
		for (int i = 1;i <= n;++i) {
			for (const node& sp : son[i])
				if (scc[sp.p] != scc[i])
					nsn[scc[i]].emplace_back(scc[sp.p]);
				else ecn[scc[i]]++;
			vcn[scc[i]]++;
		}
		for (int i = 1;i <= sct;++i)
			sort(nsn[i].begin(), nsn[i].end()),
			nsn[i].erase(unique(nsn[i].begin(), nsn[i].end()), nsn[i].end());
	}
}restruct;
constexpr int mod = 1e9 + 7;
struct {
	int dp[500005][2], ans;
	inline int qpow(int l, int r) {
		int ret = 1;
		for (;r;r >>= 1, l = l * l % mod)
			(r & 1) && (ret = ret * l % mod);
		return ret;
	}
	inline void init(int p, int f) {
		ecn[p] >>= 1; dp[p][0] = qpow(2, ecn[p]);
		dp[p][1] = (qpow(2, ecn[p] + vcn[p]) - dp[p][0] + mod) % mod;
		for (int sp : nsn[p]) if (sp != f)
			init(sp, p), ecn[p] += ecn[sp] + 1;
	}
	inline void dfs(int p, int f) {
		for (int sp : nsn[p]) if (sp != f)
			dfs(sp, p),
			dp[p][1] = (dp[p][1] * dp[sp][0] * 2 + (dp[p][0] + dp[p][1]) * dp[sp][1]) % mod,
			//对于 dp[p][1] 且已经选过：
			//	1.下面选了就必须选这条边
			//	2.下面没选就考虑选不选这条边
			//对于 dp[p][1] 且第一次选：
			//	只能从下面选了转移，从没选过，必选边转移
			dp[p][0] = (dp[p][0] * dp[sp][0] * 2) % mod;
			//对于 dp[p][0]：是否守护 sp 上来的这条边
		//PS: dp[p][0/1] 表示的是在 p 为根的子树内且选/不选自己的情况数
		if (f) ans = (ans + dp[p][1] * qpow(2, ecn[1] - ecn[p] - 1)) % mod;
		//对于不是根节点的点，选了自己，子树外的点都不能选，边随便选
		else ans = (ans + dp[p][1]) % mod;
	}
	inline int solve() {
		init(1, 0); dfs(1, 0); return ans;
	}
}dp;
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m;
	for (int i = 1, l, r;i <= m;++i)
		cin >> l >> r,
		son[l].emplace_back(r, i),
		son[r].emplace_back(l, i);
	restruct.gowork();
	cout << dp.solve() << endl;
}