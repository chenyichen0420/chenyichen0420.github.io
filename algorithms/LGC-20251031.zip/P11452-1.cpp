#include<bits/stdc++.h>
using namespace std;
#define int long long
int t, n, a[500005], ans;
signed main() {
	ios::sync_with_stdio(0);
	for (cin >> t; t; t--) {
		cin >> n; ans = 1e18;
		for (int i = 1; i <= n; ++i)
			cin >> a[i], a[i] += a[i - 1];
		int ln = n / 2;
		for (int i = 1; i + ln <= n; ++i)
			ans = min(ans, a[i + ln] - a[i - 1]);
		cout << ans << " " << a[n] - ans << endl;
	}
}