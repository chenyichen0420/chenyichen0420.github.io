#include<bits/stdc++.h>
using namespace std;
#define int long long
int t,n,ans; char c;
struct node{
	int cn; char ty;
}cp[200005]; int cpn;
inline int gmor(int v){
	return v*(v-1)/2;
}
signed main(){
	ios::sync_with_stdio(0);
	for(cin>>t;t;t--){
		cin>>n; cp[cpn=1].cn=1;
		for(int i=1;i<n;++i){
			cin>>c;
			if(c=='=') cp[cpn].cn++;
			else{
				cp[cpn].ty=c;
				cpn++;
				cp[cpn].cn=1;
			}
		}
		cp[cpn].ty=-1; ans=0;
		/*
		for(int i=1;i<=cpn;++i){
			cout<<cp[i].cn<<" "<<cp[i].ty<<" ";
		}
		cout<<endl;
		*/// check if target right,pass
		for(int p=1;p<cpn;){
			int tp=cp[p].ty,ct=0,mt=0;
			while(cp[p].ty==tp){
				mt+=gmor(cp[p].cn);
				ct+=cp[p].cn; p++;
			}
			mt+=gmor(cp[p].cn);
			ct+=cp[p].cn;
			ans+=ct*(ct-1)/2; ans-=mt;
		}
		cout<<ans<<endl;
	}
	return 0;
}