#include<bits/stdc++.h>
using namespace std;
struct node { int l, r; }np[100005]; int npc;
int t, n, m, l, vm, d[100005], v[100005], a[100005], p[100005], lp, rp, mid, vms;
inline int getv(int v, int a, int d) {
	return v * v + 2 * a * d;
}
inline void getan(int lt, int rt) {
	lp = 1, rp = m;
	while (lp < rp) {
		mid = lp + rp >> 1;
		if (p[mid] < lt) lp = mid + 1;
		else rp = mid;
	}
	if (p[lp]<lt || p[lp]>rt) return;
	npc++; np[npc].l = lp; lp = 1, rp = m;
	while (lp < rp) {
		mid = lp + rp + 1 >> 1;
		if (p[mid] > rt) rp = mid - 1;
		else lp = mid;
	}
	np[npc].r = lp;
}
inline void get(int d, int v, int a) {
	if (a == 0) {
		if (v <= vm || d > p[m]) return;
		npc++; np[npc].r = m;
		np[npc].l = lower_bound(p + 1, p + m + 1, d) - p;
	}
	else if (a > 0) {
		lp = d; rp = l;
		if (getv(v, a, rp - d) <= vms) return;
		while (lp != rp) {
			mid = lp + rp >> 1;
			if (getv(v, a, mid - d) <= vms) lp = mid + 1;
			else rp = mid;
		}
		getan(lp, l);
	}
	else {
		if (v <= vm) return;
		lp = d; rp = l; int lt, rt;
		while (lp != rp) {
			mid = lp + rp + 1 >> 1;
			if (getv(v, a, mid - d) <= vms) rp = mid - 1;
			else lp = mid;
		}
		getan(d, lp);
	}
}
int main() {
	ios::sync_with_stdio(0);
	for (cin >> t; t; t--) {
		cin >> n >> m >> l >> vm; vms = vm * vm; npc = 0;
		for (int i = 1; i <= n; ++i) cin >> d[i] >> v[i] >> a[i];
		for (int i = 1; i <= m; ++i) cin >> p[i];
		for (int i = 1; i <= n; ++i) get(d[i], v[i], a[i]);
		sort(np + 1, np + npc + 1, [&](const node& l, const node& r) {
			return l.r != r.r ? l.r < r.r : l.l < r.l;
		});
		if (!npc) {
			cout << "0 " << m << endl;
			continue;
		}
		int lp = -1, ans = 0;
		for (int i = 1; i <= npc;++i)
			if (np[i].l > lp) lp = np[i].r, ans++;
		cout << npc << " " << m - ans << endl;
	}
}