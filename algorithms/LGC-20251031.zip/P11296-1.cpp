#include<bits/stdc++.h>
using namespace std;
#define int long long
int h, n, a[10005], sum, mp[20005];
signed main() {
	ios::sync_with_stdio(0); cin >> h >> n;
	for (int i = 0; i != n; i++) cin >> a[i], sum += a[i];
	for (int i = 0; i != 2 * n; i++) {
		mp[i + 1] = max(mp[i] + a[i % n], 0ll);
		if (mp[i + 1] >= h) {
			cout << i / n << ' ' << i % n << endl;
			return 0;
		}
	}
	if (sum <= 0) return cout << "-1 -1\n", 0;
	int ans = 1e18, ps = 0;
	for (int i = n; i != n * 2; i++) {
		int nd = 1 + (h - mp[i + 1] + sum - 1) / sum;
		if (ans > nd) ans = nd, ps = i - n;
	}
	cout << ans << ' ' << ps << endl;
}