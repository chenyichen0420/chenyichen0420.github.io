#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr int mod = 998244353;
struct node {
	signed v; bool bl;
}v[10005]; int n, dp[10005][5005];
unordered_map<int, int>cnt[2];
inline int qpow(int a, int b = mod - 2) {
	if (b == 0) return 1;
	int tmp = 1;
	while (b) {
		if (b & 1) tmp *= a, tmp %= mod;
		a *= a; a %= mod; b >>= 1;
	}
	return tmp;
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n;
	for (int i = 1; i <= n; ++i) 
		cin >> v[i].v, v[i].bl = 0;
	for (int i = 1 + n; i <= n << 1; ++i) 
		cin >> v[i].v, v[i].bl = 1;
	sort(v + 1, v + n * 2 + 1, [&](const node& l, const node& r) {
		return l.v > r.v;
		});
	dp[0][0] = 1;
	for (int i = 1; i <= n << 1; ++i) {
		cnt[0][i] = cnt[0][i - 1];
		cnt[1][i] = cnt[1][i - 1];
		cnt[v[i].bl][i]++;
		int tcn = cnt[!v[i].bl][i];
		dp[i][0] = 1;
		for (int j = 1; j <= min(n, i); ++j) {
			if (j <= tcn)
				dp[i][j] = dp[i - 1][j - 1] * v[i].v % mod * (tcn - j + 1) % mod;
			dp[i][j] = (dp[i][j] + dp[i - 1][j]) % mod;
		}
	}
	int tmp = 1;
	for (int i = 2; i <= n; ++i) tmp = tmp * i % mod;
	cout << qpow(tmp) * dp[n << 1][n] % mod << endl;
	return 0;
}