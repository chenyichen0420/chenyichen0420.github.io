#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online=0;
int n,ncn; string s,t,tmp; queue<int>q; bool vis[1000005];
struct node{ char t; int s,l,r; }a[1000005]; int ac;
inline bool chk(const string& s){
    a[ac=0]={char(s[0]^6),0,0,0};
    for(int i=1;i<=s.size();++i)
        if(a[ac].t==s[i-1]) a[ac].s++;
        else a[++ac]={s[i-1],1,0,0};
    a[ac+1]={'+',0,ac+1,ac+1};
    vis[0]=vis[ac+1]=1; ncn=0;
    for(int i=1;i<=ac;++i) 
        ncn+=a[i].t=='-',a[i].l=a[i].r=i, vis[i]=0;
    for(int i=1;i<=ac;++i)
        if(a[i].t=='-' && a[i].s<max(a[i+1].s,a[i-1].s))
            q.emplace(i), vis[i]=1;
    while(q.size()){
        int p=q.front(); q.pop(); ncn--;
//        cerr<<ac<<" "<<p<<endl;
        int lp=a[p-1].l,rp=a[p+1].r;
        lp=max(lp,1ll); rp=min(rp,ac);
        if(lp!=p) a[p].s+=a[lp].s;
        if(rp!=p) a[p].s+=a[rp].s;
        a[lp].s=a[rp].s=a[p].s;
        a[lp].r=rp; a[rp].l=lp;
        if(a[lp].s>a[lp-1].s&&!vis[lp-1])
            q.emplace(lp-1),vis[lp-1]=1;
        if(a[rp].s>a[rp+1].s&&!vis[rp+1])
            q.emplace(rp+1),vis[rp+1]=1;
    }
//    cerr<<s<<" "<<ncn<<endl;
    return ncn?0:1;
}
signed main(){
    if(online)
        freopen("wire.in","r",stdin),
        freopen("wire.out","w",stdout);
    ios::sync_with_stdio(0);
    for(cin>>n;n;n--){
        cin>>s>>t;
        if(s.size()!=t.size()){
            puts("No"); continue;
        }
        if(t.find('-')==string::npos){
            a[ac=0]={char(s[0]^6),0,0,0};
            for(int i=1;i<=s.size();++i)
                if(a[ac].t==s[i-1]) a[ac].s++;
                else a[++ac]={s[i-1],1,0,0};
            a[ac+1]={'+',0,ac+1,ac+1};
            vis[0]=vis[ac+1]=1; ncn=0;
            for(int i=1;i<=ac;++i) 
                ncn+=a[i].t=='-',a[i].l=a[i].r=i, vis[i]=0;
            for(int i=1;i<=ac;++i)
                if(a[i].t=='-' && a[i].s<max(a[i+1].s,a[i-1].s))
                    q.emplace(i), vis[i]=1;
            while(q.size()){
                int p=q.front(); q.pop(); ncn--;
    //            cerr<<ac<<" "<<p<<endl;
                int lp=a[p-1].l,rp=a[p+1].r;
                lp=max(lp,1ll); rp=min(rp,ac);
                if(lp!=p) a[p].s+=a[lp].s;
                if(rp!=p) a[p].s+=a[rp].s;
                a[lp].s=a[rp].s=a[p].s;
                a[lp].r=rp; a[rp].l=lp;
                if(a[lp].s>a[lp-1].s&&!vis[lp-1])
                    q.emplace(lp-1),vis[lp-1]=1;
                if(a[rp].s>a[rp+1].s&&!vis[rp+1])
                    q.emplace(rp+1),vis[rp+1]=1;
            }
            puts(ncn?"No":"Yes");
        }
        else{
            bool cn=1; tmp=s[0];
            for(int i=1;i!=t.size();++i)
                if(t[i]!=t[i-1]&&(s[i]!=t[i]||s[i-1]!=t[i-1]))
                    cn=0;
            for(int i=1;cn&&i!=t.size();++i)
                if(t[i]!=t[i-1]){
                    if(t[i-1]=='-') for(char&c:tmp) c^=6;
                    cn&=chk(tmp); tmp=s[i];
                }
                else tmp+=s[i];
            if(t.back()=='-') for(char&c:tmp) c^=6;
            cn&=chk(tmp);
            puts(cn?"Yes":"No");
        }
    }
    return 0;
}