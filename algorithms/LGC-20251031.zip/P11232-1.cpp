#include<bits/stdc++.h>
using namespace std;
#define int long long
int t,n,m,l,v,p[100005];
struct car{int d,v,a;}c[100005];
vector<pair<int,int>>det;
signed main(){
    ios::sync_with_stdio(0); p[0]=-1;
    for(cin>>t;t;t--){
        cin>>n>>m>>l>>v; det.clear();
        for(int i=1;i<=n;++i)
            cin>>c[i].d>>c[i].v>>c[i].a;
        for(int i=1;i<=m;++i) cin>>p[i];
        for(int i=1;i<=n;++i){
            int s=det.size();
            if(c[i].a==0){
                if(c[i].v<=v||c[i].d>p[m]) continue;
                int ps=lower_bound(p+1,p+m+1,c[i].d)-p;
                det.emplace_back(ps,m);
            }
            else if(c[i].a<0){
                if(c[i].v<=v||c[i].d>p[m]) continue;
                c[i].a=-c[i].a;
                double ep=c[i].v*c[i].v*0.5/c[i].a+c[i].d;
                int l=lower_bound(p+1,p+m+1,c[i].d)-p-1,fp=l+1;
                int r=upper_bound(p+1,p+m+1,ep)-p-1,mid;
                while(l!=r){
                    mid=l+r+1>>1;
                    double vm=sqrt(c[i].v*c[i].v-2*c[i].a*(p[mid]-c[i].d));
                    if(vm>v) l=mid;
                    else r=mid-1;
                }
                if(l>=fp) det.emplace_back(fp,l);
            }
            else{
                if(c[i].d>p[m]) continue;
                int l=lower_bound(p+1,p+m+1,c[i].d)-p,r=m+1,mid;
                while(l!=r){
                    mid=l+r>>1;
                    double vm=sqrt(c[i].v*c[i].v+2*c[i].a*(p[mid]-c[i].d));
                    if(vm>v) r=mid;
                    else l=mid+1;
                }
                if(r<=m) det.emplace_back(r,m);
            }
//            if(det.size()!=s) cerr<<i<<' '<<det.back().first<<" "<<det.back().second<<endl;
        }
        sort(det.begin(),det.end(),[](const pair<int,int>&l,const pair<int,int>&r){
            return l.second<r.second;
        });
        if(!det.size()){
            cout<<"0 "<<m<<endl; continue;
        }
        int lp=det[0].second,cp=0,ans=1;
        while(++cp!=det.size())
            if(det[cp].first>lp) lp=det[cp].second,ans++;
        cout<<cp<<" "<<m-ans<<endl;
    }
    return 0;
}
/*
log.txt
1535 new passed 2023T2 using 35min
*/