#include<bits/stdc++.h>
using namespace std;
#define int long long
#define sipt //signed-input
#define sopt //signed-output
struct IO {
#define mxsz (1 << 20)
	char buf[mxsz], * p1, * p2;
	char pbuf[mxsz], * pp;
	IO() : p1(buf), p2(buf), pp(pbuf) {}
	~IO() { fwrite(pbuf, 1, pp - pbuf, stdout); }
	inline char gc() {
		if (p1 == p2) p2 = (p1 = buf) + fread(buf, 1, mxsz, stdin);
		return p1 == p2 ? ' ' : *p1++;
	}
#ifndef sipt
	inline int read() {
		int r = 0; char c = gc(); while (c < '0' || c>'9') c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return r;
	}
#else
	inline int read() {
		int r = 0; char c = gc(); bool rev = 0;
		while (c < '0' || c>'9') rev |= (c == '-'), c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return rev ? ~r + 1 : r;
	}
#endif
	inline void push(const char& c) {
		if (pp - pbuf == mxsz) fwrite(pbuf, 1, mxsz, stdout), pp = pbuf;
		*pp++ = c;
	}
	inline void write(int x) {
		static char sta[22]; int top = 0;
		do sta[top++] = x % 10, x /= 10; while (x);
		while (top) push(sta[--top] ^ 48);
	}
	inline void write(int x, char opc) {
#ifdef sopt
		if (x < 0) push('-'), x = ~x + 1;
#endif
		write(x), push(opc);
	}
} io;
int n, m, a[500005];
inline void tmax(int& l, const int r) {
	(l < r) && (l = r);
}
struct seg_tree {
	struct node {
		int ml, mr, mv, l, r, sm;
		friend node operator+(const node& l, const node& r) {
			node ret; memset(&ret, 0, sizeof ret);
			ret.mv = max(l.mv, r.mv);
			tmax(ret.mv, l.mr + r.ml);
			ret.ml = max(l.ml, l.sm + r.ml);
			ret.mr = max(r.mr, r.sm + l.mr);
			ret.sm = l.sm + r.sm;
			return ret;
		}
	}re[500005 << 2];
	inline void pup(int p) {
		re[p].mv = max(re[p << 1].mv,re[p << 1 | 1].mv);
		tmax(re[p].mv, re[p << 1].mr + re[p << 1 | 1].ml);
		re[p].ml = max(re[p << 1].ml, re[p << 1].sm + re[p << 1 | 1].ml);
		re[p].mr = max(re[p << 1 | 1].mr, re[p << 1 | 1].sm + re[p << 1].mr);
		re[p].sm = re[p << 1].sm + re[p << 1 | 1].sm;
	}
	inline void build(int l, int r, int p) {
		re[p].l = l;re[p].r = r;
		if (l == r) {
			re[p].ml = re[p].mr = re[p].mv = a[l];
			re[p].sm = a[l]; return;
		}
		build((l + r >> 1) + 1, r, p << 1 | 1);
		build(l, (l + r >> 1), p << 1); pup(p);
	}
	inline void ins(int cp, int v, int p) {
		if (re[p].l == re[p].r) {
			re[p].ml = re[p].mr = re[p].mv = v;
			re[p].sm = v; return;
		}
		if (cp > re[p << 1].r) ins(cp, v, p << 1 | 1);
		else ins(cp, v, p << 1); pup(p);
	}
	inline node que(int l, int r, int p) {
		if (re[p].l >= l && re[p].r <= r) return re[p];
		if (re[p << 1].r < l) return que(l, r, p << 1 | 1);
		if (re[p << 1].r >= r) return que(l, r, p << 1);
		return que(l, r, p << 1) + que(l, r, p << 1 | 1);
	}
}sgt;
signed main() {
	ios::sync_with_stdio(0);
	n = io.read(); 
	for (int i = 1;i <= n;++i) a[i] = io.read();
	sgt.build(1, n, 1); m = io.read();
	for (int i = 1, o, l, r;i <= m;++i)
		if (o = io.read(), l = io.read(), r = io.read(), o & 1) {
			if (l > r) swap(l, r);
			io.write(sgt.que(l, r, 1).mv, '\n');
		}
		else sgt.ins(l, r, 1);
	return 0;
}