#include<bits/stdc++.h>
using namespace std;
char c;
int main() {
	ios::sync_with_stdio(0);
	cin>>c; putchar('/');
	while(cin>>c,c!=']')
	    if(c>='A'&&c<='Z') putchar(c-'A'+'a');
}