a = 0
b = 1
c = 0
n = int(input())
if n == 1:
    print(0)
else:
    for i in range(3, n + 1):
            c = b
            b = (a + b) * (i - 1)
            a = c
    print(b)
