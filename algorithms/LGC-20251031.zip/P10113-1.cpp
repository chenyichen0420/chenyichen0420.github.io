#include<bits/stdc++.h>
using namespace std;
#define int long long
struct IO {
#define mxsz (1 << 21)
	char buf[mxsz], * p1, * p2;
	char pbuf[mxsz], * pp; bool acc[128];
	IO() : p1(buf), p2(buf), pp(pbuf) {}
	~IO() { fwrite(pbuf, 1, pp - pbuf, stdout); }
	inline void setacc(const char* c) {
		while (*c) acc[*c++] = 1;
	}
	inline char gc() {
		if (p1 == p2) p2 = (p1 = buf) + fread(buf, 1, mxsz, stdin);
		return p1 == p2 ? ' ' : *p1++;
	}
	inline char getc() {
		char c; while (!acc[c = gc()]); return c;
	}
#ifndef sipt
	inline int read() {
		int r = 0; char c = gc(); while (c < '0' || c>'9') c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return r;
	}
#else
	inline int read() {
		int r = 0; char c = gc(); bool rev = 0;
		while (c < '0' || c>'9') rev |= (c == '-'), c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return rev ? ~r + 1 : r;
	}
#endif
	inline void push(const char& c) {
		if (pp - pbuf == mxsz) fwrite(pbuf, 1, mxsz, stdout), pp = pbuf;
		*pp++ = c;
	}
	inline void write(int x) {
		static char sta[22]; int top = 0;
		do sta[top++] = x % 10, x /= 10; while (x);
		while (top) push(sta[--top] ^ 48);
	}
	inline void write(int x, char opc) {
#ifdef sopt
		if (x < 0) push('-'), x = ~x + 1;
#endif
		write(x), push(opc);
	}
} io;
int n, lp[100005], rp[100005], idx, m, k, f[100005], ans, tmx[100005];
vector<int>son[100005];
inline void dfs(int p) {
	lp[p] = ++idx; tmx[p] = max(tmx[f[p]], p);
	for (int sp : son[p]) dfs(sp);
	rp[p] = ++idx;
}
inline void lca(int& l, int r) {
	while (lp[l] > lp[r] || rp[l] < rp[r]) l = f[l];
}
signed main() {
	ios::sync_with_stdio(0); n = io.read();
	for (int i = 1; i != n; ++i)
		son[f[i] = io.read()].emplace_back(i);
	dfs(0); m = io.read();
	while (m--) {
		k = io.read(); ans = io.read();
		while (--k) lca(ans, io.read());
		io.write(tmx[ans], '\n');
	}
	return 0;
}