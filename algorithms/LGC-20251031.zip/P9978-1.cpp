#include<bits/stdc++.h>
using namespace std;
#define int long long
int n, m, a[1000005], pb[500005], vl[500005], b[500005], ans;
signed main() {
	ios::sync_with_stdio(0); cin >> n >> m;
	for (int i = 1; i <= m; ++i)
		cin >> a[i], a[m + i] = a[i];
	for (int i = 1; i <= m; ++i)
		cin >> b[i], pb[b[i]] = i;
	for (int i = 1; i <= m * 2; ++i)
		if (pb[a[i]] && i >= pb[a[i]]) vl[i - pb[a[i]]]++;
	for (int i = 0; i != m; ++i) ans = max(ans, vl[i]);
	memset(vl, 0, sizeof vl);
	memset(pb, 0, sizeof pb);
	reverse(b + 1, b + m + 1);
	for (int i = 1; i <= m; ++i) pb[b[i]] = i;
	for (int i = 1; i <= m * 2; ++i)
		if (pb[a[i]] && i >= pb[a[i]]) vl[i - pb[a[i]]]++;
	for (int i = 0; i != m; ++i) ans = max(ans, vl[i]);
	memset(pb, 0, sizeof pb);
	for (int i = 1; i <= m; ++i) pb[a[i]] = pb[b[i]] = 1;
	for (int i = 1; i <= n; ++i) if (!pb[i]) ans++;
	cout << ans << endl;
}