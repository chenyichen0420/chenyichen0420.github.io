#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr int mod=1e9+7;
int n,l,r,s[100005],a[100005],f[100005],b[100005];
signed main(){
	ios::sync_with_stdio(0);
	a[0]=s[0]=f[0]=b[0]=1; cin>>n;
	for(int i=1;i<=n;++i){
		cin>>l>>r;
		a[i]=a[l]+a[r]+f[l]*s[r]-1+b[r]*s[l]-1+1;
		a[i]%=mod;
		cout<<a[i]<<endl;
		s[i]=s[l]+s[r];
		f[i]=f[l]+f[r]+s[l]-1;
		b[i]=b[l]+b[r]+s[r]-1;
		s[i]%=mod;
		f[i]%=mod;
		b[i]%=mod;
	}
}
/*
思路：
统计每一棵树的大小，前缀区间和，后缀区间和，答案。
Ans = Ans_l + Ans_r + (Pre_l - 1) * Siz_r + (Suf_r - 1) * Siz_l + 1
大小，答案是容易合并的。
Pre = Pre_l + Pre_r + Siz_r * Pre_l
Suf = Suf_r + Suf_l + Siz_l * Suf_r
不保证对，大方向应该没错。
*/