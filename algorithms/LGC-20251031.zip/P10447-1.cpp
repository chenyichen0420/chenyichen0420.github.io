#include<bits/stdc++.h>
using namespace std;
int dp[20][1<<20];
int main(){
	register int mp[20][20],n;
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);cin>>n;
	memset(dp,0x3f,sizeof dp);
	for(register int i=0;i<n;++i)
		for(register int j=0;j<n;++j)
			cin>>mp[i][j];
	dp[0][1]=0;
	for(register int i=1;i<1<<n;++i)
		for(register int j=0;j<n;++j)
			if((i>>j)&1)
				for(register int k=0;k<n;++k)
					if(((i-(1<<j))>>k)&1)
						dp[j][i]=min(dp[j][i],dp[k][(i-(1<<j))]+mp[k][j]);
	cout<<dp[n-1][(1<<n)-1]; return 0;
}