#include<bits/stdc++.h>
using namespace std;
int n,m;
int main(){
	ios::sync_with_stdio(0);
	cin>>n>>m;
	if(m==0){
		cout<<"-1\n";
		return 0;
	}
	cout<<m<<" ";
	for(int i=2;i<=m;++i) cout<<i-1<<" ";
	for(int i=m+1;i<=n;++i) cout<<i<<" ";
	return 0;
}