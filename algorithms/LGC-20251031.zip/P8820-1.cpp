#include<bits/stdc++.h>
using namespace std;
#define int long long
vector<int>son[200005];
int n, m, s, a[200005], b[200005];
inline void tmin(int& l, const int r) { (l > r) && (l = r); }
struct mat {
	int v[3][3];
	inline mat(int s = 1e18) {
		memset(v, 0x0f, sizeof v);
		for (int i = 0; i != 3; ++i) v[i][i] = s;
	}
	inline mat operator*(const mat& r) {
		static mat ret; ret = mat();
		for (int i = 0; i != s; ++i)
			for (int j = 0; j != s; ++j)
				for (int k = 0; k != s; ++k)
					tmin(ret.v[i][k], v[i][j] + r.v[j][k]);
		return ret;
	}
}vu[200005][18], vd[200005][18], flg;
int d[200005], f[200005][18];
inline void dfs(int p, int fp) {
	f[p][0] = fp; d[p] = d[fp] + 1;
	if (s == 1) vu[p][0].v[0][0] = a[p];
	else if (s == 2)
		vu[p][0].v[0][0] = vu[p][0].v[1][0] = a[p], vu[p][0].v[0][1] = 0;
	else
		vu[p][0].v[0][0] = vu[p][0].v[1][0] = a[p], vu[p][0].v[1][1] = b[p],
		vu[p][0].v[0][1] = vu[p][0].v[1][2] = 0, vu[p][0].v[2][0] = a[p];
	vd[p][0] = vu[p][0];
	for (int i = 1; i <= 17; ++i)
		f[p][i] = f[f[p][i - 1]][i - 1],
		vu[p][i] = vu[p][i - 1] * vu[f[p][i - 1]][i - 1],
		vd[p][i] = vd[f[p][i - 1]][i - 1] * vd[p][i - 1];
	for (int sp : son[p]) if (sp != fp) dfs(sp, p);
}
inline int lca(int l, int r) {
	if (d[l] < d[r]) swap(l, r);
	for (int i = 17; i >= 0; i--)
		(d[f[l][i]] >= d[r]) && (l = f[l][i]);
	if (l == r) return l;
	for (int i = 17; i >= 0; i--)
		(f[l][i] ^ f[r][i]) && (l = f[l][i], r = f[r][i]);
	return f[l][0];
}
inline mat opu(int p, int t) {
	mat ret(0);
	for (int i = 17; i >= 0; i--)
		if (d[f[p][i]] >= t)
			ret = ret * vu[p][i],
			p = f[p][i];
	return ret;
}
inline mat opd(int p, int t) {
	mat ret(0);
	for (int i = 17; i >= 0; i--)
		if (d[f[p][i]] >= t)
			ret = vd[p][i] * ret,
			p = f[p][i];
	return ret;
}
signed main() {
	ios::sync_with_stdio(0); cin >> n >> m >> s;
	for (int i = 1; i <= n; ++i) cin >> a[i], b[i] = a[i];
	for (int i = 1, l, r; i != n; ++i)
		cin >> l >> r,
		son[l].emplace_back(r),
		son[r].emplace_back(l);
	for (int i = 1; i <= n; ++i)
		for (int j : son[i]) b[i] = min(b[i], a[j]);
	dfs(1, 0); flg.v[0][s - 1] = 0;
	for (int i = 1, l, r, lc; i <= m; ++i) {
		cin >> l >> r; lc = lca(l, r);
		mat md = vu[lc][0]; md = flg * opu(l, d[lc]) * md * opd(r, d[lc]);
		cout << min({ md.v[0][0] ,md.v[0][1] + a[r],md.v[0][2] + a[r] }) << endl;
	}
}