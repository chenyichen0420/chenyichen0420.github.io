#include<bits/stdc++.h>
#define int long long
using namespace std;
constexpr int mod = 10007, inv = (mod + 1) / 6;
char c; int n;
signed main() {
	ios::sync_with_stdio(0);
	while (cin >> c) n = (n * 10 + c - '0') % mod;
	cout << n * (n + 1) * (n + 2) * inv % mod;
	return 0;
};