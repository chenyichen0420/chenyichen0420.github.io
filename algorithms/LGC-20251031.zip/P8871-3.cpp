#include<iostream>
#include<string>
#include<vector>
#include<cstring>
using namespace std;
vector<string> s; 
int cnt, kcnt; string str;
int main() {
	ios::sync_with_stdio(false);
	while (getline(cin, str) || 1) {
		s.push_back(str), cnt++;
		if (str.size() == 0) kcnt++;
		else kcnt = 0;
		if (kcnt > 400000) break;
	}
	cnt -= 400001;
	for (int i = 1; i <= cnt; ++i) {
		for (int j = 1; j <= to_string(cnt).size() - to_string(i).size(); ++j) cout << " ";
		cout << i << " " << s[i - 1] << endl;
	}
	return 0;
}