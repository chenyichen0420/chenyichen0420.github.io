#include<bits/stdc++.h>
using namespace std;
#define int long long
int t, n, m, mu[10000005], p[10000005], cnt, sm[10000005], ans;
bool isp[10000005];
signed main() {
	ios::sync_with_stdio(0); mu[1] = 1;
	for (int i = 2; i <= 1e7; ++i) {
		if (!isp[i]) p[++cnt] = i, mu[i] = -1;
		for (int j = 1; j <= cnt && i * p[j] <= 1e7; ++j) {
			isp[i * p[j]] = 1; mu[i * p[j]] = -mu[i];
			if (i % p[j] == 0) { mu[i * p[j]] = 0; break; }
		}
	}
	for (int i = 1; i <= cnt; ++i)
		for (int j = 1; p[i] * j <= 1e7; ++j)
			sm[p[i] * j] += mu[j];
	for (int i = 1; i <= 1e7; ++i) sm[i] += sm[i - 1];
	for (cin >> t; t; t--) {
		cin >> n >> m; ans = 0;
		/*

		gcd(x,y) is prime:
		let p = gcd(x,y)
		x = p * a, y = p * b
		a <= n/p b<= m/p
		gcd(a, b) = 1

		note that [gcd(i,j)=1]=\Sum_{d|gcd(i,j)}\mu(d)

		= \Sum_{p is prime}\Sum_{i\in[1,n/p]}\Sum_{j\in[1,m/p]}[gcd(i,j)=1]
		= \Sum_{p is prime}\Sum_{i\in[1,n/p]}\Sum_{j\in[1,m/p]}\Sum_{d|gcd(i,j)}\mu(d)
		= \Sum_{p is prime}\Sum_{d=1}\mu(d)(n/(pd))(m/(pd))
		let A = pd
		= \Sum_{A=1}(n/A)(m/A)\Sum_{p|A,p is prime}\mu(A/p)

		*/
		for (int l = 1, r = 0; l <= n && l <= m; l = r + 1) {
			r = min(n / (n / l), m / (m / l));
			ans += (n / l) * (m / l) * (sm[r] - sm[l - 1]);
		}
		cout << ans << endl;
	}
}