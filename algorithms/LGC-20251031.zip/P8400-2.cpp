#include<bits/stdc++.h>
using namespace std;
int main(){
	int n,m;
	cin>>n>>m;
	cout<<n*8+m*3-28;
	return 0;
}