#include<bits/stdc++.h>
using namespace std;
int t, n, m, x[100005], dis[100005];
struct node {
    int p, v;
    node(int pi = 0, int vi = 0) :p(pi), v(vi) {};
}; vector<node>son[100005];
queue<int>q; bool vis[100005];
signed main() {
	ios::sync_with_stdio(0);
	for (cin >> t; t; t--) {
		cin >> n >> m;
        for (int i = 0; i <= n; ++i) son[i].clear();
		for (int i = 1; i <= n; ++i) cin >> x[i];
		sort(x + 1, x + n + 1);
        for (int i = 1, l, r, v; i <= m; ++i)
            cin >> l >> r >> v,
            l = lower_bound(x + 1, x + n + 1, l) - x,
            r = upper_bound(x + 1, x + n + 1, r) - x - 1,
            son[l - 1].emplace_back(r, v);
        for (int i = 0; i <= n; ++i) {
            if (i != 0) son[i - 1].emplace_back(i, 0), dis[i] = -1e9;
            if (i != n) son[i].emplace_back(i - 1, -1);
        }
        q.push(0);
        while (!q.empty()) {
            int u = q.front(); vis[u] = 0; q.pop();
            for (node sp : son[u])
                if (dis[sp.p] < dis[u] + sp.v) {
                    dis[sp.p] = dis[u] + sp.v;
                    if (!vis[sp.p])q.push(sp.p), vis[sp.p] = 1;
                }
        }
        cout << n - dis[n] << endl;
	}
}