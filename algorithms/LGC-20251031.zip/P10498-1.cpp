#include<bits/stdc++.h>
using namespace std;
#define int long long
#define gc cin.get()
#define vc vector<int>
#define mat vector<vc>
#define sw(i,j) (i-1)*m+j
int n,m,t,act,c[12][12],x,y,ans,w;
char a[12][12],op[12][12];
mat anv,tiv[65],qpv;
inline void ul(mat &anv,const mat &tiv){
	mat ans(anv.size(),vc(tiv[0].size()));
	for(int i=0;i<anv.size();++i)
		for(int j=0;j<tiv[0].size();++j)
			for(int k=0;k<tiv.size();++k)
				ans[i][j]=ans[i][j]+anv[i][k]*tiv[k][j];
	anv=ans;
}
signed main(){
	ios::sync_with_stdio(0);
	cin>>n>>m>>t>>act; gc;
	for(int i=1;i<=n;++i){
		for(int j=1;j<=m;++j) 
			a[i][j]=gc^48;
		gc;
	}
	for(int i=0;i<act;++i) cin>>op[i];
	for(int i=1;i<=60;++i) tiv[i].resize(n*m+1,vc(n*m+1)),tiv[i][0][0]=1;
	for(int k=1;k<=60;++k)
		for(int i=1;i<=n;++i)
			for(int j=1;j<=m;++j){
				x=a[i][j],y=c[i][j];
				if(isdigit(op[x][y])) tiv[k][0][sw(i,j)]=op[x][y]^48,tiv[k][sw(i,j)][sw(i,j)]=1;
				else if(op[x][y]=='N'&&i>1) tiv[k][sw(i,j)][sw(i-1,j)]=1;
				else if(op[x][y]=='S'&&i<n) tiv[k][sw(i,j)][sw(i+1,j)]=1;
				else if(op[x][y]=='W'&&j>1) tiv[k][sw(i,j)][sw(i,j-1)]=1;
				else if(op[x][y]=='E'&&j<m) tiv[k][sw(i,j)][sw(i,j+1)]=1;
				c[i][j]=(y+1)%strlen(op[x]);
			}
	qpv=tiv[1]; w=t/60;
	for(int i=2;i<=60;++i)ul(qpv,tiv[i]);
	anv.resize(1,vc(n*m+1)); anv[0][0]=1;
	while(w){
		if(w&1)ul(anv,qpv);
		ul(qpv,qpv),w>>=1;
	}
	for(int i=1;i<=t%60;++i) ul(anv,tiv[i]);
	for(int i=0;i<=n*m;++i) ans=max(ans,anv[0][i]);
	cout<<ans<<endl;
	return 0;
}