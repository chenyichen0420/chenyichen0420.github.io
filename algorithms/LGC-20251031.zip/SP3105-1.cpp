#include <bits/stdc++.h>
using namespace std;
#define int long long
#ifdef _WIN32
#define getchar_unlocked getchar
#define putchar_unlocked putchar
#endif
inline int read() {
	int r = 0; char c = getchar_unlocked();
	while (c < '0' || c>'9') c = getchar_unlocked();
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar_unlocked();
	return r;
}
inline void write(int x) {
	if (x > 9) write(x / 10);
	putchar_unlocked(x % 10 ^ 48);
	return;
}
inline void writi(int args) {
	write(args); putchar_unlocked(10);
}
int p, a, b, m, qa, k, akd; map<int, int>mv;
inline int qpow(int a, int b) {
	int ret = 1;
	for (; b; b >>= 1, a = a * a % p)
		(b & 1) && (ret = ret * a % p);
	return ret;
}
inline int gcd(int a, int b) {
	return b ? gcd(b, a % b) : a;
}
inline int bsgs() {
	mv.clear(); m = ceil(sqrt(p)); qa = 1;
	for (int i = 0; i != m; i++, qa = qa * a % p) mv[qa * b % p] = i;
	a = qa; qa = 1; if (!a) return b ? -1 : 1;
	for (int i = 0; i <= m; ++i) {
		if (mv.count(qa) && i * m - mv[qa] >= 0)
			return i * m - mv[qa];
		qa = qa * a % p;
	}
	return -1;
}
inline void exgcd(int a, int b, int& x, int& y) {
	if (!b) return x = 1, y = 0, void();
	int tx, ty; exgcd(b, a % b, tx, ty);
	x = ty; y = tx - (a / b) * ty;
}
inline int exbsgs() {
	a %= p; b %= p;
	if (b == 1 || p == 1) return 0;
	akd = 1; k = 0;
	for (int vt; (vt = gcd(a, p)) != 1;) {
		if (b % vt) return -1;
		p /= vt; b /= vt; k++;
		akd = akd * (a / vt) % p; 
		if (akd == b) return k;
	}
	//b *= qpow(akd, p - 2);
	int l, r;
	exgcd(akd, p, l, r);
	l = (l % p + p) % p;
	b = b * l % p;
	int vl = bsgs();
	if (vl == -1) return -1;
	else return vl + k;
}
signed main() {
	ios::sync_with_stdio(0);
	/*

	a^x+py=b
	let d1=gcd(a,p)
	a^(x-1)*(a/d1)+(p/d1)y=b/d1
	if b/d1 isn't an integer then:
		no solution
	let d2=gcd(a,(p/d1))
	a^(x-2)*(a/d1)*(a/d2)+(p/d1/d2)y=b/d1/d2
	if b/d1/d2 isn't an integer then:
		no solution
	......(until)
	let d(k+1)=gcd(a,p/d1/d2/d3/.../dk) == 1
	break
	let D = d1*d2*d3*...*dk
	a^(x-k)*(a^k/D)+(p/D)y=b/D
	a^(x-k)*(a^k/D) = b/D mod (p/D)
	let z = x-k
	a^z = b/D*(a^k/D)^(-1) mod (p/D)
	ans = z+k
	normal bsgs

	*/
	while (a = read(), p = read(), b = read(), a || b || p) {
		int vt = exbsgs();
		if (~vt) writi(vt);
		else puts("No Solution");
	}
}
/*
561469026 633190584 456886080
-- 799197
//- 561469026 26065755 26382941
//+ 
*/