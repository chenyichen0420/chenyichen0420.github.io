#include<bits/stdc++.h>
using namespace std;
vector<int>son[100005];
int n, m, ty[100005], cnt[2], mi, ma;
inline void dfs(const int& p) {
	cnt[ty[p]]++;
	for (int sp : son[p])
		if (ty[sp] == -1)
			ty[sp] = 1 - ty[p],
			dfs(sp);
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m;
	memset(ty, -1, sizeof ty);
	for (int i = 1, l, r; i <= m; ++i)
		cin >> l >> r,
		son[l].emplace_back(r),
		son[r].emplace_back(l);
	for (int i = 1; i <= n; ++i)
		if (ty[i] == -1) {
			ty[i] = cnt[0] = cnt[1] = 0;
			dfs(i);
			mi += min(cnt[0], cnt[1]);
			ma += max(cnt[0], cnt[1]);
		}
	cout << mi << " " << ma << endl;
	return 0;
}