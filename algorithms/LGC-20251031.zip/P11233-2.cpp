#include<bits/stdc++.h>
using namespace std;
#define int long long
int t, n, a[200005], sm[200005], dp[200005], lp[1000005];
inline void tmax(int& l, const int& r) { (l < r) && (l = r); }
signed main() {
	ios::sync_with_stdio(0);
	for (cin >> t; t; t--) {
		cin >> n; memset(lp, 0, sizeof lp);
		for (int i = 1; i <= n; ++i) cin >> a[i], sm[i] = sm[i - 1] + (a[i] == a[i - 1] ? a[i] : 0);
		for (int i = 1; i <= n; ++i) {
			// 最大只出现在上一个 a[i]==a[j-1] 或者前一个位置。
			dp[i] = dp[i - 1];
			if (lp[a[i]]) tmax(dp[i], dp[lp[a[i]] + 1] + a[i] + sm[i] - sm[lp[a[i]] + 1]);
			lp[a[i]] = i;
		}
		cout << dp[n] << endl;
	}
}