#include<iostream>
using namespace std;
int n, x, y, ups, dos, les, ris;
int main() {
	ios::sync_with_stdio(0);
	cin >> n >> x >> y;
	ups = dos = x, les = ris = y;
	cout << "Yes\n" << n - 1 << endl;
	for (register int cnt = 1; cnt < n; ++cnt) {
		if (ups > 1 && les > 1)
			ups--, les--,
			cout << ups << " " << les << " " << dos - ups << " " << ris - les << endl;
		else if (ups > 1 && ris < n)
			ups--, ris++,
			cout << ups << " " << ris << " " << dos - ups << " " << les - ris << endl;
		else if (dos < n && les > 1)
			dos++, les--,
			cout << dos << " " << les << " " << ups - dos << " " << ris - les << endl;
		else
			dos++, ris++,
			cout << dos << " " << ris << " " << ups - dos << " " << les - ris << endl;
	}
	cerr << "这题真牛逼\n";
	return 0;
}