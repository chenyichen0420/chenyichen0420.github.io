#include<bits/stdc++.h>
using namespace std;
int n, m, c[100005], cn[4], an[4]; vector<int>son[100005];
inline void dfs(int p, int t) {
	c[p] = t; cn[t]++;
	for (int sp : son[p])
		if (!c[sp]) dfs(sp, t ^ 1);
		else if (c[sp] == c[p]) throw "Impossible";
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m;
	for (int i = 1, l, r; i <= m; ++i)
		cin >> l >> r,
		son[l].emplace_back(r),
		son[r].emplace_back(l);
	try {
		for (int i = 1; i <= n; ++i) {
			if (c[i]) continue;
			cn[2] = cn[3] = 0;
			dfs(i, 2);
			an[2] += min(cn[2], cn[3]);
			an[3] += max(cn[2], cn[3]);
		}
		cout << an[2] << " " << an[3] << endl;
	}
	catch (const char* s) {
		cout << s << endl;
	}
	return 0;
}