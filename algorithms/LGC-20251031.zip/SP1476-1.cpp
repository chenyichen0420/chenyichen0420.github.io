#include<bits/stdc++.h>
using namespace std;
//#define int long long
#pragma GCC optimize(2)
int n, m, s, t, ans, mxf;
#define common_match
#ifdef common_match
struct dinic {
	struct edge { int p, v; }tmp;
	vector<edge>e; vector<int>h[60005];
	inline void ins(int l, int r, int v) {
		h[l].push_back(e.size());
		tmp.p = r; tmp.v = v;
		e.push_back(tmp);
		h[r].push_back(e.size());
		tmp.p = l; tmp.v = 0;
		e.push_back(tmp);
	}
	int d[60005]; bool vis[60005];
	inline bool bfs() {
		memset(vis, 0, sizeof vis);
		vis[s] = d[s] = 1;
		queue<int>q; q.push(s);
		while (q.size()) {
			int tp = q.front(); q.pop();
			for (int i = 0; i != h[tp].size(); ++i) {
				edge& sp = e[h[tp][i]];
				if (!vis[sp.p] && sp.v)
					d[sp.p] = d[tp] + 1,
					vis[sp.p] = 1, q.push(sp.p);
			}
		}
		return vis[t];
	}
	int cur[60005];
	inline int dfs(int p, int a) {
		if (p == t || a == 0)  return a; int ret = 0, f;
		for (int& i = cur[p]; i != h[p].size(); ++i) {
			edge& sp = e[h[p][i]];
			if (d[sp.p] == d[p] + 1 && (f = dfs(sp.p, min(a, sp.v))) > 0) {
				sp.v -= f; e[h[p][i] ^ 1].v += f;
				ret += f; if ((a -= f) == 0) break;
			}
		}
		return ret;
	}
	inline int maxflow() {
		int ret = 0;
		while (bfs())
			memset(cur, 0, sizeof cur),
			ret += dfs(s, 0x3f3f3f3f);
		return ret;
	}
	inline void reset() {
		e.clear(); for (int i = 0; i <= t; ++i) h[i].clear();
	}
}din;
#else
struct SSP {
	struct node { int p, f, v; }tmp;
	vector<node>e; vector<int>h[5005];
	inline void ins(int l, int r, int f, int v) {
		tmp.p = r; tmp.f = f; tmp.v = v;
		h[l].emplace_back(e.size());
		e.emplace_back(tmp);
		tmp.p = l; tmp.f = 0; tmp.v = -v;
		h[r].emplace_back(e.size());
		e.emplace_back(tmp);
	}
	int d[5005]; bitset<5005>vis;
	inline bool spfa() {
		vis.reset(); fill(d + 1, d + t + 1, 0x3f3f3f3f3f3f3f3f);
		queue<int>q; q.emplace(s); d[s] = 0;
		while (q.size()) {
			int tp = q.front(); q.pop(); vis[tp] = 0;
			for (int i : h[tp])
				if (e[i].f && d[e[i].p] > d[tp] + e[i].v)
					if (d[e[i].p] = d[tp] + e[i].v, !vis[e[i].p])
						q.emplace(e[i].p), vis[e[i].p] = 1;
		}
		return d[t] != 0x3f3f3f3f3f3f3f3f;
	}
	int pr[5005];
	inline int dfs(int p, int f) {
		if (p == t || !f) return f;
		int ret = 0, v; vis[p] = 1;
		for (int& i = pr[p]; i != h[p].size(); ++i) {
			node& sp = e[h[p][i]];
			if (!vis[sp.p] && sp.f && d[sp.p] == d[p] + sp.v) {
				v = dfs(sp.p, min(f, sp.f));
				if (!v) d[sp.p] = 0x3f3f3f3f3f3f3f3f;
				sp.f -= v; e[h[p][i] ^ 1].f += v;
				ret += v; f -= v; ans += v * sp.v;
				if (!f) return ret;
			}
		}
		vis[p] = 0; return ret;
	}
	inline int que() {
		while (spfa()) {
			fill(pr + 1, pr + t + 1, 0);
			for (int v; v = dfs(s, 0x3f3f3f3f3f3f3f3f);) mxf += v;
		}
		return ans;
	}
	inline void clear() {
		e.clear();
		for (int i = 1; i <= t; ++i) h[i].clear();
	}
}ssp;
#endif
signed main() {
	ios::sync_with_stdio(0); cin >> n;
	while (cin >> n >> m) {
		s = n + m + 1; t = s + 1; din.reset(); mxf = 0;
		for (int i = 1, v; i <= n; ++i)
			cin >> v, din.ins(i, t, v);
		for (int i = 1, l, r, v; i <= m; ++i)
			cin >> l >> r >> v, mxf += v,
			din.ins(s, i + n, v),
			din.ins(i + n, l, v),
			din.ins(i + n, r, v);
		cout << mxf - din.maxflow() << endl;
	}
	return 0;
}