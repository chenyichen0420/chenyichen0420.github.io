#include<bits/stdc++.h>
using namespace std;
namespace indata {
	int n, m, v[100005], tot, l2g[40005], ans[100005];
	unordered_map<int, int>um;
	inline void lsh() {
		for (int i = 1; i <= n; ++i) {
			if (!um[v[i]]) um[v[i]] = ++tot;
			v[i] = um[v[i]];
		}
	}
	inline void getlog2() {
		for (int i = 1; i <= n; ++i)
			l2g[i] = l2g[i - 1] + (1 << l2g[i - 1] == i);
	}
}
using indata::n; using indata::m; using indata::v; using indata::l2g; using indata::ans;
namespace tree { inline int getlca(int, int); };
namespace mque {
	int olq[80005], tot, fp[40005], lp[40005], sz;
	bool st[40005];;int cnt[40005], res;
	struct node {
		int l, r, p, id;
	}q[100005];
	inline void inque() {
		for (int i = 1; i <= m; ++i) {
			int a, b, lcp; cin >> a >> b;
			if (fp[a] > fp[b]) swap(a, b);
			lcp = tree::getlca(a, b);
			if (a == lcp) q[i].id = i, q[i].l = fp[a], q[i].r = fp[b];
			else q[i].id = i, q[i].l = lp[a], q[i].r = fp[b], q[i].p = lcp;
			//cerr << i << " query " << q[i].l << " to " << q[i].r 
			//	<< " special " << q[i].p << endl;
		}
	}
	inline int blk(int x) {
		return x / sz;
	}
	inline bool cmp(const node& l, const node& r) {
		if (blk(l.l) ^ blk(r.l)) return blk(l.l) < blk(r.l);
		return l.r < r.r;
	}
	inline void add(int p) {
		//cerr << "add " << p << " val " << v[p] << endl;
		st[p] ^= 1;
		if (!st[p]) {
			cnt[v[p]]--;
			if (!cnt[v[p]]) res--;
		}
		else {
			if (!cnt[v[p]]) res++;
			cnt[v[p]]++;
		}
	}
	inline void solve() {
		for (int k = 1, l = 1, r = 0; k <= m; ++k) {
			int id = q[k].id, lp = q[k].l, rp = q[k].r, np = q[k].p;
			while (r < rp) add(olq[++r]);
			while (r > rp) add(olq[r--]);
			while (l < lp) add(olq[l++]);
			while (l > lp) add(olq[--l]);
			if (np) add(np); ans[id] = res;
			if (np) add(np);
		}
	}
}
using mque::olq; using mque::q; using mque::lp; using mque::fp;
namespace tree {
	vector<int>son[40005]; int a, b;
	int dep[40005], fa[40005][16];
	inline void in_tree() {
		for (int i = 1; i ^ n; ++i)
			cin >> a >> b,
			son[a].emplace_back(b),
			son[b].emplace_back(a);
	}
	inline void dfs(int pos, int fap) {
		fa[pos][0] = fap; dep[pos] = dep[fap] + 1;
		for (int i = 1; i <= l2g[dep[pos]]; ++i)
			fa[pos][i] = fa[fa[pos][i - 1]][i - 1];
		olq[++mque::tot] = pos; fp[pos] = mque::tot;
		for (int i = 0; i < son[pos].size(); ++i)
			if (son[pos][i] != fap) dfs(son[pos][i], pos);
		olq[++mque::tot] = pos; lp[pos] = mque::tot;
	}
	inline int getlca(int lp, int rp) {
		if (lp == rp) return lp;
		if (dep[lp] < dep[rp]) swap(lp, rp);
		while (dep[lp] > dep[rp]) lp = fa[lp][l2g[dep[lp] - dep[rp]] - 1];
		if (lp == rp) return lp;
		for (int k = l2g[dep[lp]] - 1; k >= 0; k--)
			if (fa[lp][k] != fa[rp][k]) lp = fa[lp][k], rp = fa[rp][k];
		return fa[lp][0];
	}
}
int main() {
	ios::sync_with_stdio(0); 
	cin.tie(0); cout.tie(0);
	cin >> n >> m; indata::getlog2();
	for (int i = 1; i <= n; ++i) cin >> v[i];
	indata::lsh(); tree::in_tree(); tree::dfs(1, 0);
	//for (int i = 1; i <= mque::tot; ++i) cerr << olq[i] << " "; cerr << endl;
	mque::inque(); mque::sz = ceil(sqrt(2 * n));
	sort(q + 1, q + m + 1, mque::cmp);
	mque::solve(); for (int i = 1; i <= m; ++i) cout << ans[i] << endl;
	return 0;
}