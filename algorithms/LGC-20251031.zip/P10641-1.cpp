#include<bits/stdc++.h>
using namespace std;
#define int long long
vector<int>son[200005], at; bool ast[200005];
int n, m, a[200005], hs[200005], sm[200005], ans;
inline void spl_lnk(int p, int f) {
	sm[p] = a[p];
	for (int sp : son[p])
		if (sp != f)
			if (spl_lnk(sp, p), sm[sp] > sm[hs[p]])
				sm[p] += sm[sp] - sm[hs[p]], hs[p] = sp;
}
signed main() {
	ios::sync_with_stdio(0); cin >> n >> m;
	for (int i = 1; i <= n; ++i) cin >> a[i];
	for (int i = 1, l, r; i != n; ++i)
		cin >> l >> r,
		son[l].emplace_back(r),
		son[r].emplace_back(l);
	spl_lnk(1, 0);
	for (int i = 1; i <= n; ++i) ast[hs[i]] = 1;
	for (int i = 1; i <= n; ++i)
		if (!ast[i]) at.emplace_back(sm[i]);
	sort(at.begin(), at.end());
	for (int i = 1; i <= m; ++i)
		ans += at.back(), at.pop_back();
	cout << ans << endl;
}