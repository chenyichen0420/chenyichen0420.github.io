#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,sv,tree[3000005],op,v1,v2,v3;
inline int lowbit(int val){
	return val & -val;
}
inline void add(int pos,int val){
	while(pos<=n){
		tree[pos]+=val;
		pos+=lowbit(pos);
	}
}
inline int getval(int x) {
    int ans=0;
    while (x) {
        ans+=tree[x];
        x-=lowbit(x);
    }
    return ans;
}
signed main(){
	ios::sync_with_stdio(false);
	scanf("%lld",&n);
	int lst=0ll;
	for(int i=1;i<=n;++i)
		scanf("%lld", &sv),add(i,sv-lst),lst=sv;
	for(int i=1;i<=n;++i){
		scanf("%lld",&op);
		if(!op){
			scanf("%lld%lld%lld",&v1,&v2,&v3);
			add(v1,v3); add(v2+1,-v3);
		} 
		else{
			scanf("%lld%lld%lld",&v2,&v1,&v3);
			printf("%lld\n",getval(v1));
		}
	}
	return 0;
}