#include<bits/stdc++.h>
using namespace std;
#define int long long
int k, n, t[200005], ans, px, py; char o;
struct line {
	int l, r, h, t;
	line(int l = 0, int r = 0, int h = 0, int t = 0) :l(l), r(r), h(h), t(t) {}
	inline bool operator<(const line& r) { return h < r.h; }
}v[200005];
struct seg_tree {
	struct node {
		int l, r, t, v;
	}re[200005 << 3];
	inline void pup(int p) {
		if (re[p].t) re[p].v = t[re[p].r + 1] - t[re[p].l];
		else re[p].v = re[p << 1].v + re[p << 1 | 1].v;
	}
	inline void build(int l, int r, int p) {
		re[p].l = l; re[p].r = r;
		if (l == r) return;
		build((l + r >> 1) + 1, r, p << 1 | 1);
		build(l, (l + r >> 1), p << 1);
	}
	inline void ins(int l, int r, int v, int p) {
		if (l >= t[re[p].r + 1] || r <= t[re[p].l]) return;
		if (t[re[p].l] >= l && t[re[p].r + 1] <= r)
			return re[p].t += v, pup(p);
		ins(l, r, v, p << 1 | 1);
		ins(l, r, v, p << 1); pup(p);
	}
}sgt;
signed main() {
	ios::sync_with_stdio(0);
	cin >> k >> n;
	for (int i = 1, a, b, c, d, p; i <= n; ++i) {
		cin >> o >> p;
		if (o == 'E') {
			int x[4] = { px,px + k,px + p,px + p + k };
			sort(x, x + 4);
			a = x[0]; b = py;
			c = x[3]; d = py + k;
			px += p;
		}
		else if (o == 'W') {
			int x[4] = { px,px + k,px - p,px - p + k };
			sort(x, x + 4);
			a = x[0]; b = py;
			c = x[3]; d = py + k;
			px -= p;
		}
		else if (o == 'N') {
			int y[4] = { py,py + k,py + p,py + p + k };
			sort(y, y + 4);
			a = px; b = y[0];
			c = px + k; d = y[3];
			py += p;
		}
		else {
			int y[4] = { py,py + k,py - p,py - p + k };
			sort(y, y + 4);
			a = px; b = y[0];
			c = px + k; d = y[3];
			py -= p;
		}
		t[i * 2] = a, t[i * 2 - 1] = c;
		v[i * 2 - 1] = line(a, c, b, 1);
		v[i * 2] = line(a, c, d, -1);
	}
	n <<= 1;
	sort(v + 1, v + n + 1);
	sort(t + 1, t + n + 1);
	int m = unique(t + 1, t + n + 1) - t - 1;
	sgt.build(1, m - 1, 1);
	for (int i = 1; i != n; ++i)
		sgt.ins(v[i].l, v[i].r, v[i].t, 1),
		ans += sgt.re[1].v * (v[i + 1].h - v[i].h);
	cout << ans << endl;
}