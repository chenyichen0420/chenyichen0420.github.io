#include<bits/stdc++.h>
using namespace std;
constexpr int siz = 2e5 + 5, mxv = 2e5 + 2;
int n, m, v[5][siz], ta[siz << 1]; long long ans;
inline void inc(int p) {
	do ta[p]++; while ((p += p & ~p + 1) < mxv << 1);
}
inline int que(int p) {
	int re = 0; do re += ta[p]; while ((p -= p & ~p + 1) > 0); return re;
}
struct node {
	int t, x, y, v;
	node(int ti = 0, int xi = 0, int yi = 0, int vi = 0) :
		x(xi), y(yi), v(vi), t(ti) {};
	inline bool operator<(const node& r) {
		return x ^ r.x ? x < r.x : t < r.t;
	}
}q[siz << 1];
inline long long sol(const int& a, const int& b, const int& c) {
	long long ret = 0; memset(ta, 0, sizeof ta);
	for (int i = 1; i <= m; ++i)
		q[i - 1 << 1] = node(0, v[a][i] - v[b][i] + (a > b), v[b][i] - v[c][i] + (b > c), 0),
		q[i - 1 << 1 | 1] = node(1, v[b][i] - v[a][i], v[c][i] - v[b][i], v[b][i]);
	sort(q, q + m * 2);
	for (int i = 0; i < m << 1; ++i)
		if (!q[i].t) inc(q[i].y + mxv);
		else ret += que(q[i].y + mxv) * 1ll * q[i].v;
	return ret;
}
signed main() {
	ios::sync_with_stdio(0); 
	cin >> n >> m;
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j)
			cin >> v[i][j];
	for (int i = n + 1; i <= 4; ++i)
		memcpy(v[i], v[i - n], sizeof v[i]);
	for (int i = 1; i <= 4; ++i)
		for (int j = 1; j <= m; ++j)
			ans += 2ll * m * v[i][j];
	for (int i = 1; i <= 4; ++i)
		for (int j = 1; j <= 4; ++j)
			for (int k = 1; k <= 4; ++k)
				if (i ^ j && j ^ k && k ^ i) 
					ans -= sol(i, j, k);
	cout << ans << endl;
}