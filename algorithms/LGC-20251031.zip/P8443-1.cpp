#include<bits/stdc++.h>
using namespace std;
int main(){
	long long t,l,r,x;
	cin>>t;
	while(t--){
		scanf("%lld%lld%lld",&l,&r,&x);
		if(l/x!=r/x) cout<<1<<endl;
		else cout<<l/x<<endl;
	}
	return 0;
}