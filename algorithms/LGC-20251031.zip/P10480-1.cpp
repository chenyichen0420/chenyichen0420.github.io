#include<bits/stdc++.h>
using namespace std;
int n,m,l,r; vector<int>son[30001],fat[30001]; int rd[30001]; queue<int>q; bitset<30001>ans[30001]; queue<int>txl;
inline void dfs(int pos,int fa){
	if(ans[pos][fa]) return; ans[pos][fa]=1;
	for(register int i=0;i<son[pos].size();++i)
		dfs(son[pos][i],fa);
}
int main(){
	ios::sync_with_stdio(false);
	cin>>n>>m;
	for(register int i=1;i<=m;++i){
		cin>>l>>r; ++rd[l];
		son[r].push_back(l);
		fat[l].push_back(r);
	}
	for(register int i=1;i<=n;++i)
		if(!rd[i]) q.push(i);
	while(q.size()){
		int tms=q.front(); int ps; txl.push(tms); q.pop();
		for(int i=0;i<son[tms].size();++i){
			ps=son[tms][i];if(--rd[ps]==0) q.push(ps);
		}
	}
	while(txl.size()){
		int tms=txl.front(),ps; txl.pop();ans[tms][tms]=1;
		for(int i=0;i<fat[tms].size();++i)
			ans[tms]|=ans[fat[tms][i]];
	}
	for(register int i=1;i<=n;++i)
		cout<<ans[i].count()<<endl;
}