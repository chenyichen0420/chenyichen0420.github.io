#include <bits/stdc++.h>
using namespace std;
#define int unsigned long long
int t, n, pp[50000005], ans; signed p[5000005], pc; bool isp[50000005]; unordered_map<int, int>pv;
inline int cal(int v) { return (v & 1) ? (v + 1) / 2 * v : v / 2 * (v + 1); }
inline int php(int v) {
	if (v <= 5e7) return pp[v];
	if (pv.count(v)) return pv[v];
	int& rt = pv[v]; rt = cal(v);
	for (int l = 2, r = 0; l <= v; l = r + 1)
		r = v / (v / l), rt -= (r - l + 1) * php(v / r);
	return rt;
}
signed main() {
	ios::sync_with_stdio(0); pp[1] = 1;
	for (int i = 2; i <= 5e7; ++i) {
		if (!isp[i]) p[++pc] = i, pp[i] = i - 1;
		for (int j = 1; j <= pc && i * p[j] <= 5e7; ++j) {
			isp[i * p[j]] = 1; pp[i * p[j]] = pp[i] * (p[j] - 1);
			if (i % p[j] == 0) { pp[i * p[j]] += pp[i]; break; } 
		}
		pp[i] += pp[i - 1];
	}
	for (cin >> t; t; t--) {
		cin >> n;
		for (int l = 1, r = 0; l <= n; l = r + 1)
			r = n / (n / l), ans += (n / l != 1) ? cal(n / l - 1) * (php(r) - php(l - 1)) : 0;
		cout << ans << endl; ans = 0;
	}
}