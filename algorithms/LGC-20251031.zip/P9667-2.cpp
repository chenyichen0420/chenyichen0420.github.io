#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
#define int long long
int n, m, t, a[505], ct[505], ans, tmp, a_[505], ttl;
inline int read() {
	register int r = 0; register char c = getchar();
	while (c<'0' || c>'9') c = getchar();
	while (c >= '0' && c <= '9') r = (r << 3) + (r << 1) + (c ^ 48), c = getchar();
	return r;
}
inline void write(int x) {
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
	return;
}
inline void sol(int val) {
	memset(ct, 0, sizeof ct); memcpy(a_, a, sizeof a_);
	for (int i = 1; i <= n; ++i) {
		if (a_[i] < val)  ct[i] = val - a_[i];
		else {
			while (a_[i] / 2 >= val)
				a_[i] /= 2, ct[i]++;
			if (a_[i] > 1) ct[i] += min(a_[i] - val, val - a_[i] / 2 + 1);
			else ct[i] += a_[i] - val;
		}
	}
}
signed main() {
	t = read();
	while (t--) {
		n = read(); m = read(); ans = 0x3f3f3f3f3f3f3f3f;
		for (int i = 1; i <= n; ++i) cin >> a[i];
		for (int i = 1; i <= n; ++i) {
			ttl = a[i];
			while (ttl) {
				sol(ttl); sort(ct + 1, ct + n + 1); tmp = 0;
				for (int j = 1; j <= n - m; ++j) tmp += ct[j];
				ans = min(ans, tmp); ttl /= 2;
			}
		}
		cout << ans << endl;
	}
}