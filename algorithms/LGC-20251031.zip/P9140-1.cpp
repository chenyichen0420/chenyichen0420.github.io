#include<bits/stdc++.h>
using namespace std;
#define int long long
struct node {
	int p, v;
	node(int pi = 0, int vi = 0) :p(pi), v(vi) {};
}; vector<node>son[1000005]; bitset<1000008>vis; int tp;
int n, t, ms, mv, s[55], v[55], d[1000005], cv; queue<int>q;
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> t; ms = 1e10;
	for (int i = 1; i <= n; ++i)
		if (cin >> s[i] >> v[i], v[i] * ms > s[i] * mv)
			mv = v[i], ms = s[i];
	for (int i = 0; i < ms; ++i)
		for (int j = 1; j <= n; ++j)
			son[i].emplace_back(node((i + s[j]) % ms, v[j] - (i + s[j]) / ms * mv));
	memset(d, 0xcf, sizeof d); d[0] = 0; q.emplace(0); vis[0] = 1;
	while (q.size()) {
		tp = q.front(); q.pop(); vis[tp] = 0;
		for (node sp : son[tp])
			if (d[sp.p] < d[tp] + sp.v) {
				d[sp.p] = d[tp] + sp.v;
				if (!vis[sp.p]) q.push(sp.p), vis[sp.p] = 1;
			}
	}
	for (int i = 1; i <= t; ++i)
		if (cin >> cv, d[cv % ms] < -1e12) cout << "-1\n";
		else cout << cv / ms * mv + d[cv % ms] << endl;
}