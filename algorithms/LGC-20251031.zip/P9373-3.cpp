#include<bits/stdc++.h>
using namespace std;
int main(){
	ios::sync_with_stdio(false);
	long long n,t,m,tmp;
	cin>>t;
	while(t--){
		cin>>n>>m; tmp=n-m;
		if(tmp<=m){
			cout<<"-1\n";
			continue;
		}
		cout<<m<<" "<<n-m<<endl;
	}
	return 0;
} 