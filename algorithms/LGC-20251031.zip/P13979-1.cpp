#include<bits/stdc++.h>
using namespace std;
#define int long long
int n, m, a[300005]; char c;
struct seg_tree {
	struct node {
		int l, r, mv, av, tg;
	}re[300005 << 2];
	inline int sz(int p) {
		return re[p].r - re[p].l + 1;
	}
	inline void pup(int p) {
		re[p].av = re[p << 1].av + re[p << 1 | 1].av;
		re[p].mv = min(re[p << 1].mv, re[p << 1 | 1].mv);
	}
	inline void pud(int p) {
		int& t = re[p].tg;
		re[p << 1].mv += t, re[p << 1 | 1].mv += t;
		re[p << 1].av += t * sz(p << 1);
		re[p << 1 | 1].av += t * sz(p << 1 | 1);
		re[p << 1].tg += t; re[p << 1 | 1].tg += t;
		t = 0;
	}
	inline void build(int l, int r, int p) {
		re[p].l = l; re[p].r = r;
		if (l == r) return void(re[p].mv = re[p].av = a[l]);
		build((l + r >> 1) + 1, r, p << 1 | 1);
		build(l, (l + r >> 1), p << 1); pup(p);
	}
	inline void ins(int cl, int cr, int cv, int p) {
		if (re[p].l >= cl && re[p].r <= cr) {
			re[p].av += sz(p) * cv;
			re[p].tg += cv; re[p].mv += cv;
			return;
		}
		pud(p);
		if (cr > re[p << 1].r) ins(cl, cr, cv, p << 1 | 1);
		if (cl <= re[p << 1].r) ins(cl, cr, cv, p << 1);
		pup(p);
	}
	inline int qus(int l, int r, int p) {
		if (re[p].l >= l && re[p].r <= r) return re[p].av;
		int ret = 0; pud(p);
		if (l <= re[p << 1].r) ret += qus(l, r, p << 1);
		if (r > re[p << 1].r) ret += qus(l, r, p << 1 | 1);
		return ret;
	}
	inline int qum(int l, int r, int p) {
		if (re[p].l >= l && re[p].r <= r) return re[p].mv;
		int ret = 1e9; pud(p);
		if (l <= re[p << 1].r) ret = min(ret, qum(l, r, p << 1));
		if (r > re[p << 1].r) ret = min(ret, qum(l, r, p << 1 | 1));
		return ret;
	}
}sgt;
signed main() {
	ios::sync_with_stdio(0); cin >> n; m = n;
	for (int i = 1; i <= n; ++i) cin >> a[i];
	sgt.build(1, n, 1);
	for (int i = 1, o, l, r, v; i <= m; ++i)
		if (cin >> o >> l >> r >> v, o + 1 & 1) sgt.ins(l, r, v, 1);
		else cout << (sgt.qus(l, r, 1) % (v + 1) + v + 1) % (v + 1) << endl;
}