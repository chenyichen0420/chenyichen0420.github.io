#include<bits/stdc++.h>
using namespace std;
const bool online=0;
int n,a[9][6],chk[6]={0,1,1,1,1,5},ans,tmp[6],tk,er1,er2;
inline bool check(int v[6]){
	for(int i=1;i<=n;++i){
		tk=0;
		for(int j=1;j<=5;++j) 
			tmp[j]=(a[i][j]-chk[j]+10)%10,
			tk+=(tmp[j]!=0);
		if(tk==0||tk>2) return 0;
		if(tk==1) {
			er1++;
			continue;
		}
		for(int j=1;j<5;++j)
			if(tmp[j]){
				if(tmp[j]==tmp[j+1]) break;
				return 0;
			} 
		er2++;
	}
	return 1;
}
int main(){
	if(online)
		freopen("lock.in","r",stdin),
		freopen("lock.out","w",stdout);
	ios::sync_with_stdio(0);
	cin>>n; 
	for(int i=1;i<=n;++i)
		cin>>a[i][1]>>a[i][2]>>a[i][3]>>a[i][4]>>a[i][5];
	for(int i1=0;i1<=9;++i1)
		for(int i2=0;i2<=9;++i2)
			for(int i3=0;i3<=9;++i3)
				for(int i4=0;i4<=9;++i4)
					for(int i5=0;i5<=9;++i5)
						chk[1]=i1,chk[2]=i2,
						chk[3]=i3,chk[4]=i4,
						chk[5]=i5,ans+=check(chk);
	cout<<ans<<endl;
	return 0;
} 