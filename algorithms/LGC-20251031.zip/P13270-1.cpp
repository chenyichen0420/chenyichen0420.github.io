#include<bits/stdc++.h>
using namespace std;
int n; char a[60000005];
inline int mins() {
	int i = 1, j = 2, k = 0;
	while (i <= n && j <= n) {
		while (a[i + k] == a[j + k]) k++;
		if (a[i + k] > a[j + k]) i += k + 1;
		else j += k + 1;
		j += (i == j);
		k = 0;
	}
	return min(i, j);
}
signed main() {
	ios::sync_with_stdio(false);
	cin >> n;
	for (int i = 1; i <= n; ++i) cin >> a[i], a[i + n] = a[i];
	for (int i = mins(), j = 0; j < n; j++) cout << a[i + j];
	cout << endl;
	return 0;
}