#include<bits/stdc++.h>
using namespace std;
long long sum,num,n,k,ans,a[100005];
int main(){
	cin>>n>>k;
	for(int i=1;i<=n;++i)
		cin>>num,sum+=num,a[sum%k]++;
	for(int i=0;i<k;++i)
		ans+=a[i]*(a[i]-1)/2;
	ans+=a[0];
	cout<<ans<<endl;
	return 0;
}