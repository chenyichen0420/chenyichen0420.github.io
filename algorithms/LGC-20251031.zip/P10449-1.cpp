#include<bits/stdc++.h>
using namespace std;
int main(){
	ios::sync_with_stdio(0);
	int t; cin>>t; bool mp[7][7],pp[7][7]; char c;
	while(t--){
		for(int i=1;i<=5;++i){
			cin>>c; mp[i][1]=(c^48);
			cin>>c; mp[i][2]=(c^48);
			cin>>c; mp[i][3]=(c^48);
			cin>>c; mp[i][4]=(c^48);
			cin>>c; mp[i][5]=(c^48);
		} int minv=0x3f3f3f3f;
		for(int i=0;i<1<<5;++i){
			memcpy(pp,mp,sizeof pp); bool can=1; int dp=0;
			for(int j=0;j<5;++j) if(i>>j&1) pp[1][j+1]^=1,pp[1][j+2]^=1,pp[1][j]^=1,pp[2][j+1]^=1,dp++;
			for(int j=2;j<=5;++j)
				for(int k=1;k<=5;++k)
					if(!pp[j-1][k]) pp[j][k]^=1,pp[j][k+1]^=1,pp[j][k-1]^=1,pp[j+1][k]^=1,pp[j-1][k]^=1,dp++;
			for(int j=1;j<=5;++j) can=can&pp[5][j];
			if(can) minv=min(minv,dp);
		}
		cout<<(minv>6?-1:minv)<<endl;
	}
	return 0;
}