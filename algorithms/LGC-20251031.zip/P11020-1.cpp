#include<bits/stdc++.h>
using namespace std;
int t, n, m, k, px, py; vector<pair<int, int>>p;
char ac[2005][2005]; bool np[2005][2005];
int main() {
	ios::sync_with_stdio(0);
	cin >> t;
	while (t--) {
		cin >> n >> m >> k;
		for (int i = 1; i <= n && i <= m && i <= k; ++i)
			p.emplace_back(make_pair(i, i)), np[i][i] = 1;
		k -= min(n, m); px = py = 1;
		while (k > 0) {
			while (np[px][py]) if (++px > n) px = 1, py++;
			p.emplace_back(make_pair(px, py));
			np[px][py] = 1; k--;
		}
		for (int i = 1; i <= n; ++i)
			for (int j = 1; j <= m; ++j)
				ac[i][j] = '.';
		for(;p.size();p.pop_back()) 
			ac[p.back().first][p.back().second] = 'S', 
			np[p.back().first][p.back().second] = 0;
		for (int i = 1; i <= n; ++i, cout << "\n")
			for (int j = 1; j <= m; ++j) cout << ac[i][j];
	}
}