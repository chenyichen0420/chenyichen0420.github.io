#include<bits/stdc++.h>
using namespace std;
int t, n, a[10005], s;
inline int read() {
	int r = 0; char c = getchar();
	while (c < '0' || c>'9') c = getchar();
	while (c >= '0' && c <= '9') r = (r << 3) + (r << 1) + (c ^ 48), c = getchar();
	return r;
}
int main() {
	ios::sync_with_stdio(0);
	t = read();
	while (t--) {
		n = read(); s = 0;
		for (int i = 1; i <= n; ++i) a[i] = read();
		sort(a + 1, a + n + 1);
		for (int i = n; i > 0; i--) a[i] -= a[i - 1] + 1;
		for (int i = 1 + (n + 1) % 2; i <= n; i += 2) s ^= a[i];
		cout << (s ? "Georgia will win\n" : "Bob will win\n");
	}
	return 0;
}