#include<bits/stdc++.h>
using namespace std;
char out[730][730]; int scf[6]={1},val;
int main(){
	ios::sync_with_stdio(false);
	for(register int i=1;i<=729;++i)
		for(register int j=1;j<=729;++j)
			out[i][j]=' ';
	for(register int i=1;i<=6;++i) scf[i]=scf[i-1]*3;
	out[1][1]='X';
	for(register int k=2;k<=7;++k){
		register int pv=scf[k-2];
		register int xpls=2*pv,ypls=0;
		for(register int i=1;i<=scf[k-2];++i)
			for(register int j=1;j<=scf[k-2];++j)
				out[i+xpls][j+ypls]=out[i][j];
		xpls=pv,ypls=pv;
		for(register int i=1;i<=scf[k-2];++i)
			for(register int j=1;j<=scf[k-2];++j)
				out[i+xpls][j+ypls]=out[i][j];
		xpls=0,ypls=pv*2;
		for(register int i=1;i<=scf[k-2];++i)
			for(register int j=1;j<=scf[k-2];++j)
				out[i+xpls][j+ypls]=out[i][j];
		xpls=pv*2,ypls=pv*2;
		for(register int i=1;i<=scf[k-2];++i)
			for(register int j=1;j<=scf[k-2];++j)
				out[i+xpls][j+ypls]=out[i][j];
	}
	while(cin>>val){
		if(val==-1) return 0; register int size=scf[val-1];
		for(register int i=1;i<=size;++i){
			for(register int j=1;j<=size;++j)
				putchar(out[i][j]);
			putchar('\n');
		}
		putchar('-'); putchar('\n');
	}
}