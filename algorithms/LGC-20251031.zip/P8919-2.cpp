#include<iostream>
using namespace std;
int m, n, cnt, mine[100005];char f[1000005];
int main() {
	cin >> m >> n;
	for (int i = 1; i <= n; ++i) cin >> f[i];
	for (int i = 1; i <= m; ++i) {
		cin >> mine[i]; mine[i] -= cnt;
		if (f[mine[i]] == '1') cnt++;
	}
	cout << cnt << endl;
	return 0;
}