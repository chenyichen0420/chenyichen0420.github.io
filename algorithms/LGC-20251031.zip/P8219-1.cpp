#include<bits/stdc++.h>
using namespace std;
int main(){
	long long l,r,ans=0; 
	cin>>l>>r;
	cout<<r/2<<endl;
	return 0;
} 