#include<bits/stdc++.h>
using namespace std;
int main(){
	register long long t,n,m;
	cin>>t;
	while(t--){
		cin>>n>>m;
		cout<<(n-1)*m+(m-1)*n<<endl;
	}
	return 0;
}