#include<bits/stdc++.h>
using namespace std;
constexpr int mod=1e9+7;
int t,n,m,a[505][50005],ans;
inline void mad(int&l, const int &r){(l+=r)>=mod&&(l-=mod);}
signed main(){
	ios::sync_with_stdio(0); a[0][0]=1;
	for(int i=1;i<=450;++i){
		memcpy(a[i],a[i-1],sizeof a[0]);
		for(int j=i;j<=50000;++j) mad(a[i][j],a[i-1][j-i]);
	}
	for(int i=1;i<=450;++i)
		for(int j=1;j<=50000;++j)
			mad(a[i][j],a[i][j-1]);
	for(cin>>t;t;t--){
		cin>>n>>m; ans=0;
		for(int i=1;i<=450;++i){
			if(i*(i+1)/2>n+m) break;
			mad(ans,a[i][n]);
			if(i*(i+1)/2>m) mad(ans,mod-a[i][i*(i+1)/2-m-1]);
		}
		cout<<ans<<endl;
	}
} 