#include<bits/stdc++.h>
using namespace std;
#define int long long
int p, a[300005], n, m, op, x, y, k;
struct nde {
    int v, mul, add;
}st[300005<<2];
inline void build(int rt, int l, int r) {
    st[rt].mul = 1; st[rt].add = 0;
    if (l == r) {
        st[rt].v = a[l];
        return;
    }
    int m = (l + r) / 2;
    build(rt * 2, l, m); build(rt * 2 + 1, m + 1, r);
    st[rt].v = (st[rt * 2].v + st[rt * 2 + 1].v) % p;
    return;
}
inline void down(int id, int l, int r) {
    int m = (l + r) / 2;
    st[id * 2].v = (st[id * 2].v * st[id].mul + st[id].add * (m - l + 1)) % p;
    st[id * 2 + 1].v = (st[id * 2 + 1].v * st[id].mul + st[id].add * (r - m)) % p;
    st[id * 2].mul = (st[id * 2].mul * st[id].mul) % p;
    st[id * 2 + 1].mul = (st[id * 2 + 1].mul * st[id].mul) % p;
    st[id * 2].add = (st[id * 2].add * st[id].mul + st[id].add) % p;
    st[id * 2 + 1].add = (st[id * 2 + 1].add * st[id].mul + st[id].add) % p;
    st[id].mul = 1; st[id].add = 0;
    return;
}
inline void mult(int id, int sl, int sr, int l, int r, int k) {
    if (r < sl || sr < l) return;
    if (l <= sl && sr <= r) {
        st[id].v = (st[id].v * k) % p;
        st[id].mul = (st[id].mul * k) % p;
        st[id].add = (st[id].add * k) % p;
        return;
    }
    down(id, sl, sr);
    int m = (sl + sr) / 2;
    mult(id * 2, sl, m, l, r, k);
    mult(id * 2 + 1, m + 1, sr, l, r, k);
    st[id].v = (st[id * 2].v + st[id * 2 + 1].v) % p;
    return;
}
inline void addu(int id, int sl, int sr, int l, int r, int k) {
    if (r < sl || sr < l) return;
    if (l <= sl && sr <= r) {
        st[id].add = (st[id].add + k) % p;
        st[id].v = (st[id].v + k * (sr - sl + 1)) % p;
        return;
    }
    down(id, sl, sr);
    int m = (sl + sr) / 2;
    addu(id * 2, sl, m, l, r, k);
    addu(id * 2 + 1, m + 1, sr, l, r, k);
    st[id].v = (st[id * 2].v + st[id * 2 + 1].v) % p;
    return;
}
inline int query(int root, int sl, int sr, int l, int r) {
    if (r < sl || sr < l) return 0;
    if (l <= sl && sr <= r) return st[root].v % p;
    down(root, sl, sr);
    int m = (sl + sr) / 2;
    return(query(root * 2, sl, m, l, r) + query(root * 2 + 1, m + 1, sr, l, r)) % p;
}
signed main() {
    ios::sync_with_stdio(0);
    cin >> n; m = n; p = 10007;
    for (int i = 1; i <= n; i++) cin >> a[i];
    build(1, 1, n);
    while (m--) {
        cin >> op;
        if (op == 1) cin >> x >> y >> k, mult(1, 1, n, x, y, k);
        else if (!op) cin >> x >> y >> k, addu(1, 1, n, x, y, k);
        else cin >> x >> y >> k, cout << (query(1, 1, n, y, y) + p) % p << endl;
    }
    return 0;
}