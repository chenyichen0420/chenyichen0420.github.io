#include<bits/stdc++.h>
using namespace std;
#define int long long
int n, l[200005], r[200005], mt, lp, dp[200005];
vector<pair<int, int>>ans;
signed main() {
	ios::sync_with_stdio(0); cin >> n;
	for (int i = 1; i <= n; ++i) cin >> l[i] >> r[i];
	memset(dp, -1, sizeof dp); mt = 3 * l[1];
	for (int i = 1; i <= n; ++i)
		if (r[i] <= mt) {
			dp[i] = lp; int tt;
			tt = l[i + 1] - r[i];
			tt *= 3; tt += r[i];
			if (tt > mt) mt = tt, lp = i;
		}
	if (!(~dp[n])) return cout << "impossible\n", 0;
	for (int np = n; np; np = dp[np])
		lp = dp[np], mt = r[np] - r[lp],
		ans.emplace_back(r[lp], r[lp] + (mt + 2) / 3);
	cout << ans.size() << endl; reverse(ans.begin(), ans.end());
	for (const auto& v : ans) cout << v.first << " " << v.second << endl;
}