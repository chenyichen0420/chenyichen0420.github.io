#include<bits/stdc++.h>
using namespace std;
int n, a[500005], t, p[500005], re[500005], ps; map<int, int>um; long long ans;
inline void add(int p) {
	for (int i = p; i <= n; i += (i & ~i + 1))
		re[i]++;
}
inline int que(int p) {
	int sum = 0;
	for (int i = p; i; i -= (i & ~i + 1))
		sum += re[i];
	return sum;
}
int main() {
	ios::sync_with_stdio(0);
	cin >> t;
	while (t--) {
		cin >> n; ans = 0; um.clear(); memset(re, 0, sizeof re);
		for (int i = 1; i <= n; ++i) cin >> a[i], p[i] = a[i];
		sort(a + 1, a + n + 1); ps = unique(a + 1, a + n + 1) - a;
		for (int i = 1; i < ps; ++i) um[a[i]] = i;
		for (int i = n; i; i--) ans += que(um[p[i]] - 1), add(um[p[i]]);
		cout << ans << endl;
	}//second judge
	return 0;
}