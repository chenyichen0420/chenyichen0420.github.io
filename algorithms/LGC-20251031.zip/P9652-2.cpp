#include<iostream>
using namespace std;
#define int long long
int t, k, a, b;
signed main() {
	ios::sync_with_stdio(0);
	cin >> t;
	while (t--) {
		cin >> k >> a >> b; k--;
		if (k) {
			if (a > b + 1) {
				cout << "-1\n";
				continue;
			}
			for (int i = 1; i <= a - 1; ++i)
				cout << "1 ";
			b -= (a - 2); cout << b << endl;
		}
		else {
			if (a > b + 1) {
				cout << "-1\n";
				continue;
			}
			for (int i = 1; i <= a - 2; ++i)
				cout << "1 ";
			b -= (a - 2);
			cout << b << " " << b << endl;
		}
	}
	return 0;
}