#include<bits/stdc++.h>
using namespace std;
#define int long long
int n, v[100005], cnt[60], lib[60], ans;
inline void add(const int& v) {
	for (int i = 0; i < 60; ++i)
		if (v & (1ll << i)) cnt[i]++;
}
inline void ins(int v) {
	for (int i = 59; i >= 0; i--)
		if (v & (1ll << i))
			if (lib[i]) v ^= lib[i];
			else return void(lib[i] = v);
}
inline int que(int v) {
	for (int i = 59; i >= 0; i--)
		if ((v ^ lib[i]) > v)
			v ^= lib[i];
	return v;
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n;
	for (int i = 1; i <= n; ++i)
		cin >> v[i], add(v[i]);
	for (int i = 0; i < 60; ++i)
		if (cnt[i] & 1) {
			for (int j = 1; j <= n; ++j)
				if (v[j] & (1ll << i)) v[j] ^= (1ll << i);
			ans |= (1ll << i);
		}
	for (int i = 1; i <= n; ++i) ins(v[i]);
	cout << (ans + que(0) * 2) << endl;
	return 0;
}