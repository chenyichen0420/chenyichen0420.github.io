#include<bits/stdc++.h>
using namespace std;
#define int long long
struct node { int t, p, v, c, ans; }q[1000005];
int n, h[200005], a[200005], hc, ans[1000005], qc, m, t;
struct tree_array {
	int v[200005];
	inline void ins(int p, int t) {
		do v[p] += t; while ((p += p & -p) <= hc);
	}
	inline void res(int p) {
		do v[p] = 0; while ((p += p & -p) <= hc);
	}
	inline int que(int p) {
		int t = 0; do t += v[p]; while (p &= p - 1); return t;
	}
}ta;
inline bool cmp(const node& l, const node& r) {
	return l.p != r.p ? l.p < r.p : l.v != r.v ? l.v < r.v : l.t < r.t;
}
inline void cdq(int l, int r) {
	if (l == r) return; int mid = l + r >> 1;
	cdq(l, mid); cdq(mid + 1, r);
	for (int lp = l, rp = mid + 1; rp <= r; ++rp) {
		while (lp <= mid && q[lp].p <= q[rp].p)
			ta.ins(q[lp].v, q[lp].c), lp++;
		q[rp].ans += q[rp].c * (ta.que(hc) - ta.que(q[rp].v));
	}
	for (int i = l; i <= mid; ++i) ta.res(q[i].v);
	for (int lp = mid, rp = r; rp > mid; --rp) {
		while (lp >= l && q[lp].p >= q[rp].p)
			ta.ins(q[lp].v, q[lp].c), lp--;
		q[rp].ans += q[rp].c * ta.que(q[rp].v - 1);
	}
	for (int i = l; i <= mid; ++i) ta.res(q[i].v);
	sort(q + l, q + r + 1, cmp);
}
signed main() {
	ios::sync_with_stdio(0); cin >> n;
	for (int i = 1; i <= n; ++i) cin >> h[i], a[i] = h[i];
	sort(a + 1, a + n + 1); hc = unique(a + 1, a + n + 1) - a - 1;
	for (int i = 1; i <= n; ++i)
		h[i] = lower_bound(a + 1, a + hc + 1, h[i]) - a,
		q[++qc] = { 0,i,h[i],1 };
	cin >> m;
	for (int i = 1, l, r; i <= m; ++i) {
		cin >> l >> r;
		q[++qc] = { ++t,l,h[l],-1 };
		q[++qc] = { ++t,r,h[r],-1 };
		swap(h[l], h[r]);
		q[++qc] = { ++t,l,h[l],1 };
		q[++qc] = { ++t,r,h[r],1 };
	}
	cdq(1, qc);
	for (int i = 1; i <= qc; ++i) ans[q[i].t] += q[i].ans;
	for (int i = 1; i <= t; ++i) assert((ans[i] += ans[i - 1]) >= 0);
	for (int i = 0; i <= m; ++i) cout << ans[i << 2] << endl;
}