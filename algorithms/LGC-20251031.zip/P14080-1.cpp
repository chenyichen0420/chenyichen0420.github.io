#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m,ans[100005],bas;
struct MSS{
	int f[100005];
	inline int find(int p){
		while(f[p]!=p) p=f[p]=f[f[p]];
		return p;
	}
	inline bool merge(int l,int r){
		return find(l)!=find(r)?f[find(l)]=find(r),1:0;
	}
}mss; bool chs[100005];
struct edge{ int l,r,v,id; }e[100005];
struct node{
	int p,v; node(int p=0,int v=0):p(p),v(v){}
	friend bool operator<(const node&l,const node&r){
		return l.v!=r.v?l.v<r.v:l.p<r.p;
	}
};set<node>s[100005]; vector<node>son[100005];
inline void merge(set<node>&l,set<node>&r){
	if(l.size()<r.size()) swap(l,r);
	for(const auto&v:r)
		if(l.count(v)) l.erase(v);
		else l.emplace(v);
	r.clear();
}
inline void dfs(int p,int f){
	for(const auto&sp:son[p]) if(sp.p!=f){
		dfs(sp.p,p);
		if(s[sp.p].size()) ans[sp.v]=bas-e[sp.v].v+s[sp.p].begin()->v;
		else ans[sp.v]=-1;
		merge(s[p],s[sp.p]);
	}
}
signed main(){
    ios::sync_with_stdio(0); cin>>n>>m;
	for(int i=1;i<=m;++i) cin>>e[i].l>>e[i].r>>e[i].v,e[i].id=i;
	sort(e+1,e+m+1,[](const edge&l,const edge&r){return l.v<r.v;});
	for(int i=1;i<=n;++i) mss.f[i]=i;
	for(int i=1;i<=m;++i)
		if(chs[i]=mss.merge(e[i].l,e[i].r))
			bas+=e[i].v,
			son[e[i].l].emplace_back(e[i].r,e[i].id),
			son[e[i].r].emplace_back(e[i].l,e[i].id);
	for(int i=1;i<=m;++i) if(!chs[i])
		s[e[i].l].emplace(e[i].id,e[i].v),
		s[e[i].r].emplace(e[i].id,e[i].v);
	for(int i=1;i<=m;++i) ans[i]=bas;
	sort(e+1,e+m+1,[](const edge&l,const edge&r){return l.id<r.id;});
	dfs(1,0); for(int i=1;i<=m;++i) cout<<ans[i]<<"\n";
}
