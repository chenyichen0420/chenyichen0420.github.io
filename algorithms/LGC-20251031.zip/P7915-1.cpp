#include<bits/stdc++.h>
using namespace std;
int a, ps[1000005], p[1000005], n, t, lf, rf, lb, rb;
deque<int> q1, q2; string ans, s;
inline bool solve(bool c) {
	ans = s = ""; q1.clear(); q2.clear();
	ans.push_back(c ? 'L' : 'R'); s.push_back('L');
	if (c) {
		for (int i = 2; i < p[1]; i++) q1.push_back(i);
		for (int i = n; i > p[1]; i--) q2.push_back(i);
	}
	else {
		for (int i = 1; i < p[n]; i++) q1.push_back(i);
		for (int i = n - 1; i > p[n]; i--) q2.push_back(i);
	}
	while (q1.size() > 0 || q2.size() > 0) {
		if ((q1.size() ? lf = q1.front(), lb = q1.back() : lf = lb = 0),
			(q2.size() ? rf = q2.front(), rb = q2.back() : rf = rb = 0),
			p[lf] == lb) ans.push_back('L'), q1.pop_front(), s.push_back('L'), q1.pop_back();
		else if (p[lf] == rb) ans.push_back('L'), q1.pop_front(), s.push_back('R'), q2.pop_back();
		else if (p[rf] == lb) ans.push_back('R'), q1.pop_back(), s.push_back('L'), q2.pop_front();
		else if (p[rf] == rb) ans.push_back('R'), q2.pop_back(), s.push_back('R'), q2.pop_front();
		else return 0;
	}
	reverse(s.begin(), s.end());
	ans += s; cout << ans << endl;
	return 1;
}
int main() {
	ios::sync_with_stdio(0);
	cin >> t; p[0] = -1;
	while (t--) {
		cin >> n; fill(ps + 1, ps + n + 1, 0); n <<= 1;
		for (int i = 1; i <= n; i++)
			if (cin >> a, !ps[a]) ps[a] = i;
			else p[ps[a]] = i, p[i] = ps[a];
		if (!solve(1) && !solve(0)) cout << "-1\n";
	}
}