#include<bits/stdc++.h>
using namespace std;
vector<int>son[500005];
int n, m, dfn[500005], low[500005], cntt;
stack<int>s; vector<int>ec[500005]; int cnt;
inline void tmin(int& l, const int& r) {
	(l > r) && (l = r);
}
#define sp son[p][i]
inline void tarjan(const int& p, const int& f) {
	dfn[p] = low[p] = ++cntt; s.push(p);
	int sn = 0;
	for (int i = 0; i ^ son[p].size(); ++i)
		if (!dfn[sp]) {
			tarjan(sp, p); sn++;
			tmin(low[p], low[sp]);
			if (low[sp] >= dfn[p]) {
				ec[++cnt].emplace_back(p);
				while (s.top() ^ sp)
					ec[cnt].emplace_back(s.top()), s.pop();
				ec[cnt].emplace_back(s.top()), s.pop();
			}
		}
		else if (sp ^ f) tmin(low[p], dfn[sp]);
	if (!f && !sn) ec[++cnt].emplace_back(p);
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m;
	for (int i = 1, l, r; i <= m; ++i)
		cin >> l >> r, 
		son[l].emplace_back(r), 
		son[r].emplace_back(l);
	for (int i = 1; i <= n; ++i) if (!dfn[i]) tarjan(i, 0);
	cout << cnt << endl;
	while(cnt) {
		cout << ec[cnt].size() << " ";
		while (!ec[cnt].empty()) 
			cout << ec[cnt].back() << " ", 
			ec[cnt].pop_back();
		cnt--; cout << endl;
	}
	return 0;
}