#include<bits/stdc++.h>
#include<unordered_set>
using namespace std;
int n, m, gf[205][205];
inline int sg(int a, int b) {
	if (gf[a][b] != -1) return gf[a][b];
	unordered_set<int>us;
	for (int i = 2; i < a - 1; ++i)
		us.insert(sg(i, b) ^ sg(a - i, b));
	for (int i = 2; i < b - 1; ++i)
		us.insert(sg(a, i) ^ sg(a, b - i));
	for (int i = 0;; ++i) if (!us.count(i)) return gf[a][b] = i;
}
int main(){
	ios::sync_with_stdio(0);
	memset(gf, -1, sizeof gf);
	while (cin >> n >> m) puts(sg(n, m) ? "WIN" : "LOSE");
	return 0;
}