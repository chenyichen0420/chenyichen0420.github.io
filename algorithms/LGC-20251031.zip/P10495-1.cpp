#include<bits/stdc++.h>
using namespace std;
int n, tmp, val, cnt;
bitset<2000005>chk;
int prime[2000001], lp[2000001];
signed main() {
	ios::sync_with_stdio(0);
	cin >> n; chk.set();
	chk[0] = chk[1] = 0;
	for (register int i = 2; i <= 2000000; ++i) {
		if (chk[i]) prime[++cnt] = i;
		for (register int j = 1; j <= cnt; ++j) {
			if (i * prime[j] > 2000000) break;
			chk[i * prime[j]] = 0;
			if (i % prime[j] == 0) break;
		}
	}
	for (int i = 2; i <= n; ++i) {
		if (!chk[i]) continue;
		tmp = n; val = 0;
		while (tmp > 0) {
			val += tmp / i;
			tmp /= i;
		}
		if(val) cout << i << " " << val << endl;
	}
	return 0;
}