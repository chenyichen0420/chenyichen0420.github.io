#include<bits/stdc++.h>
using namespace std;
int n, m, cnt; char c;
bitset<1000001>bst;
int main() {
	ios::sync_with_stdio(0);
	cin >> n >> m >> c;
	if (c == 'Y') {
		cout << "No solution\n";
		return 0;
	}
	bst[1] = 1;
	for (register int i = 2; i <= m; ++i)
		cin >> c, bst[i] = (c == 'N');
	if (bst.count() > n || !bst.count()) {
		cout << "No solution\n";
		return 0;
	}
	for (register int i = 1; i <= m; ++i) {
		if (bst[i]) cout << ++cnt << ' ';
		else cout << "1 ";
	}
	return 0;
}