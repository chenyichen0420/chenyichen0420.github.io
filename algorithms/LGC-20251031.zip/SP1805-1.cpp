#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,a[100005],st[100005],tp,wid[100005];
signed main(){
	ios::sync_with_stdio(false);
	while(cin>>n&&n){
		int ans=0,tmp;
		for(int i=1;i<=n;++i) cin>>a[i]; 
		a[0]=a[n+1]=0;
		for(int i=1;i<=n+1;++i){
			if(a[i]>st[tp]){
				st[++tp]=a[i];
				wid[tp]=1;
			}
			else{
				tmp=0;
				while(a[i]<st[tp]){
					tmp+=wid[tp];
					ans=max(ans,tmp*st[tp]);
					tp--;
				}
				st[++tp]=a[i]; wid[tp]=tmp+1;
			}
		}
		cout<<ans<<endl;
	}
	return 0;
}