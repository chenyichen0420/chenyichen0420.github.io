#include<bits/stdc++.h>
using namespace std;
constexpr int online = 0;
int p, t, n, m, l, r, cnt, pid[200005], ans; queue<int>q;
char op, vl[200005], tch[200005]; bitset<200008>vis;
struct node {
	int p, v;
	node(int pi = 0, int vi = 0) :p(pi), v(vi) {};
}; vector<node>son[200005];
inline void clearall() {
	for (int i = 1; i <= n + m; ++i)
		son[i].clear(), vl[i] = 0;
	ans = cnt = 0; vis.reset();
}
inline char chg(const char& st, const bool& chs) {
	if (st == 'T') return (chs ? 'F' : 'T');
	if (st == 'F') return (chs ? 'T' : 'F');
	return 'U';
}
inline int bfs(const int& p, const char& chs) {
	if (vl[p] && vl[p] != chs) return -1;
	tch[p] = chs; while (q.size()) q.pop(); 
	q.push(p); int cn = (p <= n && chs != 'U'), tp;
	while (q.size()) {
		tp = q.front(), q.pop(); vis[tp] = 1;
		for (node sp : son[tp]) {
			op = chg(tch[tp], sp.v);
			if (tch[sp.p] && tch[sp.p] != op ||
				vl[sp.p] && vl[sp.p] != op) return -1;
			if (!vis[sp.p])
				q.push(sp.p), tch[sp.p] = op, vis[sp.p] = 1, 
				cn += (sp.p <= n && op != 'U');
		}
	}
	return cn;
}
inline void nbf(const int& p) {
	while (q.size()) q.pop(); 
	q.push(p); int tp;
	while (q.size()) {
		tp = q.front(), q.pop(); 
		if (!vis[tp]) continue;
		vis[tp] = tch[tp] = 0;
		for (node sp : son[tp])
			if (tch[sp.p]) q.push(sp.p);
	}
}
inline void setf(const int& p) {
	if (vis[p]) return; vis[p] = 1;
	for (node sp : son[p]) 
		if (!vis[sp.p]) setf(sp.p);
}
signed main() {
	if (online)
		freopen("tribool.in", "r", stdin),
		freopen("tribool.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin >> p >> t;
	while (t--) {
		clearall(); cin >> n >> m;
		for (int i = 1; i <= n; ++i)pid[i] = ++cnt;
		for (int i = 1, lid; i <= m; ++i)
			if (cin >> op, op == '+' || op == '-')
				if (cin >> l >> r, l == r)
					lid = pid[l], pid[l] = ++cnt,
					son[lid].emplace_back(node(pid[l], (op != '+'))),
					son[pid[l]].emplace_back(node(lid, (op != '+')));
				else
					pid[l] = ++cnt,
					son[pid[r]].emplace_back(node(pid[l], (op != '+'))),
					son[pid[l]].emplace_back(node(pid[r], (op != '+')));
			else cin >> l, pid[l] = ++cnt, vl[cnt] = op;
		for (int i = 1; i <= n; ++i) if (i != pid[i])
			son[i].emplace_back(node(pid[i], 0)),
			son[pid[i]].emplace_back(node(i, 0));
		for (int i = 1, mxv; i <= cnt; ++i)
			if (!vis[i])
				mxv = max(0, bfs(i, 'T')), nbf(i),
				mxv = max(mxv, bfs(i, 'F')), nbf(i),
				mxv = max(mxv, bfs(i, 'U')), nbf(i),
				ans += mxv, setf(i);
		cout << n - ans << endl;
	}
	return 0;
}