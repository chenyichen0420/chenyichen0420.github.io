#include<bits/stdc++.h>
using namespace std;
#define int long long
int t, n, ans;
inline int mul(int a, int b, int n) {
	int c = (long double)a / n * b;
	int res = (unsigned int)a * b - (unsigned int)c * n;
	return (res + n) % n;
}
inline int qpow(int a, int b, int n) {
	a %= n; int ret = a ? 1 : 0;
	for (; b; b >>= 1, a = mul(a, a, n))
		(b & 1) && (ret = mul(ret, a, n));
	return ret;
}
constexpr int ud[] = { 2,325,9375,28178,450775,9780504,1795265022 };
inline bool isprm(int n) {
	if (n < 3 || n % 2 == 0) return n == 2;//特判
	int u = n - 1, t = 0;
	while (u % 2 == 0) u /= 2, ++t;
	for (int a : ud) {
		int v = qpow(a, u, n);
		if (v == 1 || v == n - 1 || v == 0) continue;
		for (int j = 1; j <= t; j++) {
			v = mul(v, v, n);
			if (v == n - 1 && j != t) { v = 1; break; }
			if (v == 1) return 0;
		}
		if (v != 1) return 0;
	}
	return 1;
}
signed main() {
	ios::sync_with_stdio(0);
	for (cin >> t; t; t--)
		cin >> n, puts(isprm(n) ? "YES" : "NO");
}