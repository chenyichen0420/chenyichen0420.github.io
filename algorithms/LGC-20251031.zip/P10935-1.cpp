#include<bits/stdc++.h>
using namespace std;
#define int long long
int n, m, rd[100005], scn[100005], d[100005], ans;
struct node {
	int p, v;
	node(int pi = 0, int vi = 0) :p(pi), v(vi) {};
}; vector<node>son[100005], nsn[100005];
int dfn[100005], low[100005], cnt, scc[100005], sct;
bool ins[100005]; stack<int>s; queue<int>q;
inline void tmin(int& l, const int r) { (l > r) && (l = r); }
inline void tmax(int& l, const int r) { (l < r) && (l = r); }
inline void tarjan(int p) {
	dfn[p] = low[p] = ++cnt; ins[p] = 1; s.emplace(p);
	for (const node& sp : son[p])
		if (!dfn[sp.p]) tarjan(sp.p), tmin(low[p], low[sp.p]);
		else if (ins[sp.p]) tmin(low[p], dfn[sp.p]);
	if (dfn[p] == low[p]) {
		scc[p] = ++sct;
		while (s.top() != p)
			scc[s.top()] = sct,
			ins[s.top()] = 0, s.pop();
		s.pop(); ins[p] = 0;
	}
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m;
	for (int i = 1, t, l, r;i <= m;++i) {
		cin >> t >> l >> r;
		if (t == 1)
			son[l].emplace_back(r, 0),
			son[r].emplace_back(l, 0);
		else if (t == 2)
			son[l].emplace_back(r, 1);
		else if (t == 3)
			son[r].emplace_back(l, 0);
		else if (t == 4)
			son[r].emplace_back(l, 1);
		else son[l].emplace_back(r, 0);
	}
	for (int i = 1;i <= n;++i)
		if (!dfn[i]) tarjan(i);
	for (int i = 1;i <= n;++i) {
		scn[scc[i]]++;
		for (const node& sp : son[i]) {
			if (scc[i] == scc[sp.p] && sp.v) return cout << "-1\n", 0;
			if (scc[i] != scc[sp.p]) nsn[scc[i]].emplace_back(scc[sp.p], sp.v), rd[scc[sp.p]]++;
		}
	}
	memset(d, 0xcf, sizeof d);
	for (int i = 1;i <= sct;++i)
		if (!rd[i]) q.emplace(i), d[i] = 1;
	while (q.size()) {
		int tp = q.front(); q.pop();
		ans += d[tp] * scn[tp];
		for (const node& sp : nsn[tp]) {
			tmax(d[sp.p], d[tp] + sp.v);
			if (!--rd[sp.p]) q.emplace(sp.p);
		}
	}
	cout << ans << endl;
}