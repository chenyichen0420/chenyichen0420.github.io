#include<bits/stdc++.h>
using namespace std;
vector<int>son[2000005]; string a,b,s[100005],t[100005];
int n,m,ans[100005],cnt,ct,np,ni;
inline int id(char c){
	if(c=='?')return 4; if(c=='A')return 0;
	if(c=='U')return 1; if(c=='G')return 2;
	return 3;
}
struct node{
	int son[5],fp; vector<int>p;
}trie[2000005];
inline void insert(int p){
	np=0;
	for(char c:t[p])
		if(trie[np].son[(ni=id(c))])np=trie[np].son[ni];
		else np=trie[np].son[ni]=++cnt;
	trie[np].p.emplace_back(p);
}
inline void dfs(int p){
	for(int sp:son[p]){
		for(int tp:trie[p].p)
			trie[sp].p.emplace_back(tp);
		dfs(sp);
	}
}
inline void build(){
	queue<int>q;
	for(int i=0;i<5;++i)
		if(trie[0].son[i])
			q.emplace(trie[0].son[i]);
	while(q.size()){
		int p=q.front();q.pop();
		for(int i=0;i<5;++i)
			if(trie[p].son[i])
				q.emplace(trie[p].son[i]),
				trie[trie[p].son[i]].fp=trie[trie[p].fp].son[i];
			else trie[p].son[i]=trie[trie[p].fp].son[i];
	}
	for(int i=1;i<=cnt;++i) son[trie[i].fp].emplace_back(i);
} 
inline void query(int p){
	np=0;
	for(char c:s[p]){
		ni=id(c), np=trie[np].son[ni];
		for(int vl:trie[np].p) ans[vl]++;
	}
}
int main(){
	ios::sync_with_stdio(0); cin>>n>>m;
	for(int i=1;i<=n;++i)cin>>a,s[i]=a+'?'+a;
	for(int i=1;i<=m;++i)cin>>a>>b,t[i]=b+'?'+a,insert(i);
	build();dfs(0); for(int i=1;i<=n;++i)query(i);
	for(int i=1;i<=m;++i)cout<<ans[i]<<endl;
}