#include<bits/stdc++.h>
using namespace std;
int t, n, m, rans[3000001]; string s,p[100001];
int tri[3000001][65], k;
inline void pluswd(string s) {
	register int sz = s.size(), np = 0, tmp;
	for (register int i = 0;i < sz;++i) {
		if ('a' <= s[i] && s[i] <= 'z') tmp = s[i] - 'a';
		else if ('A' <= s[i] && s[i] <= 'Z')tmp = s[i] - 'A' + 26;
		else tmp = s[i] - '0' + 52;
		if (!tri[np][tmp]) tri[np][tmp] = ++k;
		np = tri[np][tmp]; rans[np]++;
	}
}
inline void deplus(string s) {
	register int sz = s.size(), np = 0, tmp;
	for (register int i = 0;i < sz;++i) {
		if ('a' <= s[i] && s[i] <= 'z') tmp = s[i] - 'a';
		else if ('A' <= s[i] && s[i] <= 'Z')tmp = s[i] - 'A' + 26;
		else tmp = s[i] - '0' + 52;
		np = tri[np][tmp]; rans[np]--;
	}
}
inline int gas(string s) {
	register int sz = s.size(), np = 0, tmp;
	for (register int i = 0;i < sz;++i) {
		if ('a' <= s[i] && s[i] <= 'z') tmp = s[i] - 'a';
		else if ('A' <= s[i] && s[i] <= 'Z')tmp = s[i] - 'A' + 26;
		else tmp = s[i] - '0' + 52;
		if (!tri[np][tmp]) return 0;
		np = tri[np][tmp];
	}
	return rans[np];
}
int main() {
	ios::sync_with_stdio(false);
	cin >> t;
	while (t--) {
		cin >> n >> m;
		for (register int i = 1;i <= n;++i)
			cin >> p[i],
			pluswd(p[i]);
		while (m--)
			cin >> s,
			cout << gas(s) << endl;
		for (register int i = 1;i <= n;++i)
			deplus(p[i]);
	}
	return 0;
}