#include<bits/stdc++.h>
using namespace std;
int n, m, o, l, r, v, rt[1000005];
class m_incline_heap {
	struct node {
		int f, s[2], v;
	}re[1000005];
	inline int merge(int l, int r) {
		if (!l || !r) return l | r;
		if (re[l].v > re[r].v) swap(l, r);
		re[re[l].s[1] = merge(re[l].s[1], r)].f = l;
		swap(re[l].s[0], re[l].s[1]);
		return l;
	}//合并操作
public:
	inline void chg(int& r, int p, int v) {
		int f = re[p].f;
		if (f) re[f].s[re[f].s[0] != p] = re[p].f = 0;
		else r = re[p].f = 0; //断开与父节点的边
		re[p].v = v; //改权值
		r = merge(r, p); //合并回去
	}//修改操作
	inline void init() {
		for (int i = 1;i <= n;++i)
			cin >> re[i].v, rt[i] = i;
	}
	inline void del(int h, int p) {
		chg(rt[h], p, INT_MIN); //设置要删除的节点权值极小，也就是置于堆顶
		re[rt[h] = merge(re[rt[h]].s[0], re[rt[h]].s[1])].f = 0; //删除堆顶
	}//从堆 h 中删去元素 p
	inline int top(int h)const { return re[rt[h]].v; }
	inline void merh(int l, int r) {
		re[rt[l] = merge(rt[l], rt[r])].f = 0;
	}//合并两个堆
}mih;
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m; mih.init();
	while (m-- && cin >> o)
		if (o & 2)
			if (o & 1) cin >> l >> r >> v, mih.chg(rt[l], r, v);
			else cin >> l >> r, mih.merh(l, r);
		else
			if (o & 1) cin >> l, cout << mih.top(l) << endl;
			else cin >> l >> r, mih.del(l, r);
	return 0;
}