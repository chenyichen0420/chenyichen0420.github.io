#include<bits/stdc++.h>
using namespace std;
#define int long long
#pragma GCC optimize(2)
inline int read() {
	int r = 0; char c = getchar();
	while (c < '0' || c>'9') c = getchar();
	while (c >= '0' && c <= '9') r = (r << 1) + (r << 3) + (c ^ 48), c = getchar();
	return r;
}
inline void write(int x) {
	if (x > 9) write(x / 10);
	putchar(x % 10 ^ 48);
}
inline void writi(int args) {
	write(args); putchar(32);
}
using cpx = complex<long double>;
int n, lim, rev; const long double pi2 = acos(-1) * 2;
inline void fft(const int& lim, vector<cpx>& v) {
	if (lim == 1) return;
	vector<cpx>vl(lim + 4 >> 1), vr(lim + 4 >> 1);
	for (int i = 0; i <= lim; i += 2)
		vl[i >> 1] = v[i], vr[i >> 1] = v[i + 1];
	fft(lim >> 1, vl); fft(lim >> 1, vr);
	cpx tm(cos(pi2 / lim), sin(pi2 / lim) * rev), tv(1, 0), tmp;
	for (int i = 0; i != lim >> 1; ++i, tv *= tm)
		tmp = tv * vr[i], v[i] = vl[i] + tmp,
		v[i + (lim >> 1)] = vl[i] - tmp;
}
int solve() {
	n = read();
	vector<cpx>f(n + n + 5 << 1), g(n + n + 5 << 1);
	for (int i = 0; i <= n; ++i) f[i] = cpx(read(), 0);
	for (int i = 0; i <= n; ++i) g[i] = cpx(read(), 0);
	lim = rev = 1; while (lim <= n + n) lim <<= 1;
	fft(lim, f); fft(lim, g); rev = -1;
	for (int i = 0; i <= lim; ++i) f[i] *= g[i];
	fft(lim, f);
	for (int i = 0; i <= n + n; ++i)
		writi(f[i].real() / lim + 0.5);
	putchar('\n');
	return 0;
}
signed main() {
	int t = read(); while(t--) solve();
}