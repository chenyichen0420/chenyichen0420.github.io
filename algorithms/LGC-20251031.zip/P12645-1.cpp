#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr int mod=1e9+7;
int n,l,r,s[100005],a[100005],f[100005],b[100005];
signed main(){
	ios::sync_with_stdio(0);
	a[0]=s[0]=f[0]=b[0]=1; cin>>n;
	for(int i=1;i<=n;++i){
		cin>>l>>r;
		a[i]=a[l]+a[r]+f[l]*s[r]+b[r]*s[l]-1;
		a[i]%=mod;
		cout<<a[i]<<endl;
		s[i]=s[l]+s[r];
		f[i]=f[l]+f[r]+s[l]-1;
		b[i]=b[l]+b[r]+s[r]-1;
		s[i]%=mod;
		f[i]%=mod;
		b[i]%=mod;
	}
}