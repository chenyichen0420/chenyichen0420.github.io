#include<bits/stdc++.h>
using namespace std;
int a,b; string s;
int main(){
	ios::sync_with_stdio(0);
	cin>>a>>b>>s;
	for(char c:s)
		if(c=='S') a--;
		else b--;
	if(a+b>0){
		cout<<"-1\n";
		return 0;
	}
	a=max(a,0); b=max(b,0);
	cout<<max(a,b)<<endl;
} 