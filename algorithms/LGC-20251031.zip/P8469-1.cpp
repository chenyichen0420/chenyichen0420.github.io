#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,a[100005],mv=0x3f3f3f3f,ans=1;
signed main(){
	ios::sync_with_stdio(false);
	cin>>n;
	for(int i=1;i<=n;++i)
		cin>>a[i],
		mv=min(mv,a[i]);
	for(int i=1;i<=n;++i)
		ans*=(a[i]/mv),ans%=1000000007;
	cout<<mv<<" "<<ans<<endl;
	return 0;
} 