#include<bits/stdc++.h>
using namespace std;
struct IO {
#define mxsz (1 << 20)
	char buf[mxsz], * p1, * p2;
	char pbuf[mxsz], * pp;
	IO() : p1(buf), p2(buf), pp(pbuf) {}
	~IO() { fwrite(pbuf, 1, pp - pbuf, stdout); }
	inline char gc() {
		if (p1 == p2) p2 = (p1 = buf) + fread(buf, 1, mxsz, stdin);
		return p1 == p2 ? ' ' : *p1++;
	}
#ifndef sipt
	inline int read() {
		int r = 0; char c = gc(); while (c < '0' || c>'9') c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return r;
	}
#else
	inline int read() {
		int r = 0; char c = gc(); bool rev = 0;
		while (c < '0' || c>'9') rev |= (c == '-'), c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return rev ? ~r + 1 : r;
	}
#endif
	inline void push(const char& c) {
		if (pp - pbuf == mxsz) fwrite(pbuf, 1, mxsz, stdout), pp = pbuf;
		*pp++ = c;
	}
	inline void write(int x) {
		static char sta[22]; int top = 0;
		do sta[top++] = x % 10, x /= 10; while (x);
		while (top) push(sta[--top] ^ 48);
	}
	inline void write(int x, char opc) {
#ifdef sopt
		if (x < 0) push('-'), x = ~x + 1;
#endif
		write(x), push(opc);
	}
} io;
int n; stack<int>s, ans;
struct tree_array {
	int v[100005];
	inline void ins(int p, int t = -1) {
		do v[p] += t; while ((p += (p & ~p + 1)) <= n);
	}
	inline int get(int p) {
		int ret = 0;
		for (int i = 16;i >= 0;i--)
			if ((ret | (1ll << i)) <= n && p >= v[ret | (1ll << i)])
				p -= v[ret | (1ll << i)], ret |= (1ll << i);
		return ret + 1;
	}
}ta;
signed main() {
	ios::sync_with_stdio(0); n = io.read(); s.emplace(0);
	for (int i = 1;i != n;++i) s.emplace(io.read());
	for (int i = 1;i <= n;++i) ta.ins(i, 1);
	for (int i = n, a;i >= 1;i--)
		a = ta.get(s.top()), s.pop(),
		ans.emplace(a), ta.ins(a);
	while (ans.size()) io.write(ans.top(), '\n'), ans.pop();
}