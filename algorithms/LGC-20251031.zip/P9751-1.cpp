#include<bits/stdc++.h>
using namespace std;
struct node{
	int l,r;
	node(int li=0,int ri=0){
		l=li,r=ri;
	}
	friend bool operator<(node l,node r){
		return l.r>r.r;
	}
}tmp;
int n,m,k,a,b,c; vector<node>son[10005]; priority_queue<node>pq; bool vis[10005][105];
inline int upper_than(int cv,int tv){
	cv+=ceil((tv-cv)*1.0/k)*k;
	return cv;
}
int main(){
	ios::sync_with_stdio(0);
	cin>>n>>m>>k;
	for(int i=1;i<=m;++i)
		cin>>a>>b>>c,
		son[a].push_back(node(b,c));
	pq.push(node(1,0));
	while(!pq.empty()){
		tmp=pq.top(); pq.pop();
		if(vis[tmp.l][tmp.r%k]) continue;
		vis[tmp.l][tmp.r%k]=1;
		if(tmp.l==n&&tmp.r%k==0){
			cout<<tmp.r<<endl;
			return 0;
		}
		for(int i=0;i<son[tmp.l].size();++i)
			if(!vis[son[tmp.l][i].l][(tmp.r+1)%k])
				if(tmp.r>=son[tmp.l][i].r) pq.push(node(son[tmp.l][i].l,tmp.r+1));
				else pq.push(node(son[tmp.l][i].l,upper_than(tmp.r,son[tmp.l][i].r)+1));
	} 
	cout<<-1<<endl;
	return 0;
} 