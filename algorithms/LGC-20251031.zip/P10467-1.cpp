#include<bits/stdc++.h>
using namespace std;
struct IO {
#define mxsz (1 << 21)
	char buf[mxsz], * p1, * p2;
	char pbuf[mxsz], * pp;
	IO() : p1(buf), p2(buf), pp(pbuf) {}
	~IO() { fwrite(pbuf, 1, pp - pbuf, stdout); }
	inline char gc() {
		if (p1 == p2) p2 = (p1 = buf) + fread(buf, 1, mxsz, stdin);
		return p1 == p2 ? ' ' : *p1++;
	}
#ifndef sipt
	inline int read() {
		int r = 0; char c = gc(); while (c < '0' || c>'9') c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return r;
	}
#else
	inline int read() {
		int r = 0; char c = gc(); bool rev = 0;
		while (c < '0' || c>'9') rev |= (c == '-'), c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return rev ? ~r + 1 : r;
	}
#endif
	inline void push(const char& c) {
		if (pp - pbuf == mxsz) fwrite(pbuf, 1, mxsz, stdout), pp = pbuf;
		*pp++ = c;
	}
	inline void write(int x) {
		static char sta[22]; int top = 0;
		do sta[top++] = x % 10, x /= 10; while (x);
		while (top) push(sta[--top] ^ 48);
	}
	inline void write(int x, char opc) {
#ifdef sopt
		if (x < 0) push('-'), x = ~x + 1;
#endif
		write(x), push(opc);
	}
} io;
using snf = tuple<int, int, int, int, int, int>;
set<snf>s; int n, a, b, c, d, e, f;
signed main() {
	ios::sync_with_stdio(0);
	cin >> n;
	for (int i = 1; i <= n; ++i) {
		cin >> a >> b >> c >> d >> e >> f;
		snf s1 = make_tuple(a, b, c, d, e, f);
		snf s2 = make_tuple(b, c, d, e, f, a);
		snf s3 = make_tuple(c, d, e, f, a, b);
		snf s4 = make_tuple(d, e, f, a, b, c);
		snf s5 = make_tuple(e, f, a, b, c, d);
		snf s6 = make_tuple(f, a, b, c, d, e);
		snf s7 = make_tuple(f, e, d, c, b, a);
		snf s8 = make_tuple(a, f, e, d, c, b);
		snf s9 = make_tuple(b, a, f, e, d, c);
		snf s10 = make_tuple(c, b, a, f, e, d);
		snf s11 = make_tuple(d, c, b, a, f, e);
		snf s12 = make_tuple(e, d, c, b, a, f);
		if (s.count(s1)) return puts("Twin snowflakes found.") & 0;
		if (s.count(s2)) return puts("Twin snowflakes found.") & 0;
		if (s.count(s3)) return puts("Twin snowflakes found.") & 0;
		if (s.count(s4)) return puts("Twin snowflakes found.") & 0;
		if (s.count(s5)) return puts("Twin snowflakes found.") & 0;
		if (s.count(s6)) return puts("Twin snowflakes found.") & 0;
		if (s.count(s7)) return puts("Twin snowflakes found.") & 0;
		if (s.count(s8)) return puts("Twin snowflakes found.") & 0;
		if (s.count(s9)) return puts("Twin snowflakes found.") & 0;
		if (s.count(s10)) return puts("Twin snowflakes found.") & 0;
		if (s.count(s11)) return puts("Twin snowflakes found.") & 0;
		if (s.count(s12)) return puts("Twin snowflakes found.") & 0;
		s.emplace(s1);
		s.emplace(s2);
		s.emplace(s3);
		s.emplace(s4);
		s.emplace(s5);
		s.emplace(s6);
		s.emplace(s7);
		s.emplace(s8);
		s.emplace(s9);
		s.emplace(s10);
		s.emplace(s11);
		s.emplace(s12);
	}
	puts("No two snowflakes are alike.");
}