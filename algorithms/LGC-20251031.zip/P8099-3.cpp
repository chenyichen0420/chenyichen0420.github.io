#include<bits/stdc++.h>
using namespace std;
#define int long long
#define sipt //signed-input
#define sopt //signed-output
struct IO {
#define mxsz (1 << 22)
	char buf[mxsz], * p1, * p2;
	char pbuf[mxsz], * pp;
	IO() : p1(buf), p2(buf), pp(pbuf) {}
	~IO() { fwrite(pbuf, 1, pp - pbuf, stdout); }
	inline char gc() {
		if (p1 == p2) p2 = (p1 = buf) + fread(buf, 1, mxsz, stdin);
		return p1 == p2 ? ' ' : *p1++;
	}
#ifndef sipt
	inline int read() {
		int r = 0; char c = gc(); while (c < '0' || c>'9') c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return r;
	}
#else
	inline int read() {
		int r = 0; char c = gc(); bool rev = 0;
		while (c < '0' || c>'9') rev |= (c == '-'), c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return rev ? ~r + 1 : r;
	}
#endif
	inline void push(char c) {
		if (pp - pbuf == mxsz) fwrite(pbuf, 1, mxsz, stdout), pp = pbuf;
		*pp++ = c;
	}
	inline void write(int x) {
		static char sta[22]; int top = 0;
		do sta[top++] = x % 10, x /= 10; while (x);
		while (top) push(sta[--top] ^ 48);
	}
	inline void write(int x, char opc) {
#ifdef sopt
		if (x < 0) push('-'), x = ~x + 1;
#endif
		write(x), push(opc);
	}
} io;
int n, m, a[100005], v[100005], rd[100005];
unordered_map<int, int>apt;
struct tree_array {
	int v[100005];
	inline int lb(int v) { return v & ~v + 1; }
	inline void ins(int p, int t = 1) {
		do v[p] += t; while ((p += lb(p)) <= n);
	}
	inline int que(int p) {
		int ret = 0; do ret += v[p];
		while (p -= lb(p)); return ret;
	}
}ta;
struct seg_tree {
	struct node {
		int l, r, mv, mp, tg;
	}re[100005 << 2];
	inline void pup(int p) {
		if (re[p << 1].mv <= re[p << 1 | 1].mv)
			re[p].mv = re[p << 1].mv, re[p].mp = re[p << 1].mp;
		else re[p].mv = re[p << 1 | 1].mv, re[p].mp = re[p << 1 | 1].mp;
	}
	inline void pud(int p) {
		if (!re[p].tg) return;
		re[p << 1].tg += re[p].tg;
		re[p << 1].mv += re[p].tg;
		re[p << 1 | 1].tg += re[p].tg;
		re[p << 1 | 1].mv += re[p].tg;
		re[p].tg = 0;
	}
	inline void build(int l, int r, int p) {
		re[p].l = l; re[p].r = r;
		if (l == r) return re[p].mv = rd[l], re[p].mp = l, void();
		build((l + r >> 1) + 1, r, p << 1 | 1);
		build(l, (l + r >> 1), p << 1); pup(p);
	}
	inline void chg(int l, int r, int v, int p) {
		if (re[p].l >= l && re[p].r <= r)
			return re[p].mv += v, re[p].tg += v, void();
		pud(p);
		if (l <= re[p << 1].r) chg(l, r, v, p << 1);
		if (r > re[p << 1].r) chg(l, r, v, p << 1 | 1);
		pup(p);
	}
}sgt;
signed main() {
	ios::sync_with_stdio(0); n = io.read(); m = io.read();
	for (int i = 1;i <= n;++i) v[i] = a[i] = io.read();
	sort(v + 1, v + n + 1);
	for (int i = 1;i <= n;++i)
		a[i] = lower_bound(v + 1, v + n + 1, a[i]) - v + apt[a[i]], apt[v[a[i]]]++;
	for (int i = 1;i <= n;++i) {
		int lp = lower_bound(v + 1, v + n + 1, v[a[i]] - m) - v - 1;
		int rp = upper_bound(v + 1, v + n + 1, v[a[i]] + m) - v - 1;
		rd[a[i]] = (i - 1) + ta.que(lp) - ta.que(rp); ta.ins(a[i]);
	}
	sgt.build(1, n, 1);
	for (int i = 1;i <= n;++i) {
		int ps = sgt.re[1].mp;
		io.write(v[ps], '\n');
		sgt.chg(1, n, -1, 1);
		int lp = lower_bound(v + 1, v + n + 1, v[ps] - m) - v - 1;
		int rp = upper_bound(v + 1, v + n + 1, v[ps] + m) - v - 1;
		sgt.chg(lp + 1, rp, 1, 1);
		sgt.chg(ps, ps, 1145141919810, 1);
	}
}
/*
下午来了补一下注释和题解！！！
*/