#include<bits/stdc++.h>
using namespace std;
#define int long long
int t,n,m;
inline bool solve(int l,int m,int n){
	if(l==1) return 1;
	if(m>=l/2&&n>=l/2) return 0;
	return solve(l/2,m%(l/2),n%(l/2));
}
signed main(){
	ios::sync_with_stdio(0);
	for(cin>>t;t;t--){
		cin>>n>>m; n-=m; int lt=(m+1)/2;
		int len=pow(2,ceil(log(double(lt))/log(double(2)))); n%=len;
		cout<<solve(len,lt-1,n)<<endl;
	}
}