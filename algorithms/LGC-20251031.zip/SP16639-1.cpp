#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr int mod = 10007;
int t, n, m, k, ans, jc[10008], ny[10008], ak;
pair<int, int>p[12]; vector<pair<int, int>>bp;
inline int qpow(int a, int b, int p = mod) {
	int tmp = 1;
	for (; b; b >>= 1, a = a * a % p)
		(b & 1) && (tmp = a * tmp % p);
	return tmp;
}
inline int cvl(int n, int m, int p = mod) {
	if (n < m) return 0;
	return jc[n] * ny[m] % p * ny[n - m] % p;
}
inline int luc(int n, int m, int p = mod) {
	if (n < m) return 0; if (!n) return 1;
	return luc(n / p, m / p, p) * cvl(n % p, m % p, p) % p;
}
inline int delt(int x, int y) {
	if (x > y * 2 || y > x * 2 || (x + y) % 3 || x < 0 || y < 0) return 0;
	int dc = (x + y) / 3; return luc(dc, x - dc);
}
signed main() {
	ios::sync_with_stdio(0);
	for (int i = jc[0] = 1; i != mod; ++i) jc[i] = jc[i - 1] * i % mod;
	ny[mod - 1] = qpow(jc[mod - 1], mod - 2, mod); cin >> t;
	for (int i = mod - 1; i >= 1; i--) ny[i - 1] = ny[i] * i % mod;
	for (int tt = 1; tt <= t; ++tt) {
		cin >> n >> m >> k; ans = 0;
		for (int i = 1; i <= k; ++i)
			cin >> p[i].first >> p[i].second;
		sort(p + 1, p + k + 1);
		for (int i = 0; i != 1ll << k; ++i) {
			bp.clear(); bp.emplace_back(make_pair(1, 1));
			for (int j = 0; j != k; ++j)
				if (i >> j & 1) bp.emplace_back(p[j + 1]);
			bp.emplace_back(make_pair(n, m));
			ak = (bp.size() & 1 ? -1 : 1);
			for (int i = 1; i != bp.size(); ++i)
				ak = ak * delt(bp[i].first - bp[i - 1].first, bp[i].second - bp[i - 1].second) % mod;
			ans += ak;
		}
		cout << "Case #" << tt << ": " << (ans % mod + mod) % mod << endl;
	}
}