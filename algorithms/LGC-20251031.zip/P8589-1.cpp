#include<iostream>
using namespace std;
int main() {
	int n; cin >> n;
	if (n % 4 != 1 || n <= 4) cout << "-1\n";
	else {
		for (int i = 1; i <= n/4; i++)
			printf("0011");
		printf("0\n");
	}
	return 0;
}