#include<bits/stdc++.h>
using namespace std;
long long k,n,e,d,tmp1,tmp2,t;
int main(){
	cin>>k;
	while(k--){
		scanf("%lld%lld%lld",&n,&e,&d);
		tmp1=n-e*d+2; tmp2=tmp1*tmp1-n*4;
		t=sqrt(tmp2);
		if(t*t==tmp2) printf("%lld %lld\n",(tmp1-t)/2,(tmp1+t)/2);
		else if((t+1)*(t+1)==tmp2) printf("%lld %lld\n",(tmp1-t-1)/2,(tmp1+t+1)/2);
		else if((t-1)*(t-1)==tmp2) printf("%lld %lld\n",(tmp1-t+1)/2,(tmp1+t-1)/2);
		else printf("NO\n");
	}
	return 0;
}