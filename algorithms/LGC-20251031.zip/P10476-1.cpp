#include<bits/stdc++.h>
using namespace std;
char hs[2][3];
int len; char c1[2000005], c2[1000005];
signed main() {
	ios::sync_with_stdio(0);
	cin >> c1 >> c2; len = strlen(c1);
	if (len != strlen(c2)) {
		cout << "No\n";
		return 0;
	}
	for (register int i = 0; i < len; ++i)
		hs[0][0] += c1[i],
		hs[1][0] += c2[i],
		hs[0][1] *= c1[i],
		hs[1][1] *= c2[i],
		hs[0][2] ^= c1[i],
		hs[1][2] ^= c2[i],
		c1[i + len] = c1[i];
	if (hs[0][0] != hs[1][0] || hs[0][1] != hs[1][1] || hs[0][2] != hs[1][2]) {
		cout << "No\n";
		return 0;
	}
	putchar('Y'),putchar('e'),putchar('s'),putchar('\n');
	register int i = 0, j = 1, k = 0;
	while (i < len && j < len) {
		while (c1[i + k] == c1[j + k]) k++;
		if (c1[i + k] > c1[j + k]) i += k + 1;
		else j += k + 1; j += (i == j); k = 0;
	}
	for (i = min(i, j), j = 0; j < len; ++j) putchar(c1[i + j]);
	return 0;
}