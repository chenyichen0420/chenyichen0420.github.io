#include<bits/stdc++.h>
using namespace std;
int n, a[3100001], ans;
int tri[3100001][2], k;
inline void get(int val){
	bitset<31>vl; register int pos = 0;
	vl.reset(); vl = val;
	for (register int i = 30;i >= 0;i--) {
		if (!tri[pos][vl[i]]) tri[pos][vl[i]] = ++k;
		pos = tri[pos][vl[i]];
	}
}
inline int retv(int val) {
	bitset<31>vl; int pos = 0, as = 0;
	vl.reset(); vl = val;
	register int ws = log2(val);
	for (register int i = ws;i >= 0;i--) vl[i] = 1 - vl[i];
	for (register int i = 30;i >= 0;i--) {
		if (!tri[pos][vl[i]]) vl[i] = 1 - vl[i];
		pos = tri[pos][vl[i]];
	}
	for (register int i = 0;i <= 30;++i) as += vl[i] * (1 << i);
	return as;
}
int main() {
	ios::sync_with_stdio(0);
	cin >> n;
	for (register int i = 1;i <= n;++i)
		cin >> a[i],
		get(a[i]);
	for (register int i = 1;i <= n;++i)
		ans = max(ans, a[i] ^ retv(a[i]));
	cout << ans << endl;
	return 0;
}