#include<bits/stdc++.h>
using namespace std;
#define int long long
signed main(){
	int t,m,n;
	cin>>t;
	while(t--){
		scanf("%lld%lld",&m,&n);
		if(m%2==0) m++;
		if(n%2==0) n--;
		printf("%lld\n",(n-m)/2+1);
	}
	return 0;
}