#include<iostream>
using namespace std;
long long ecf[40], n, k;
int main() {
	for (long long i = 0ll, j = 1ll; i <= 30ll; ++i, j *= 2ll)  ecf[i] = j;
	scanf("%lld", &k);
	while (k--) {
		scanf("%lld", &n); bool can = 0;
		if (n == 1) {
			cout << 1 << endl;
			continue;
		}
		if (n % 2 == 0) {
			cout << "-1\n";
			continue;
		}
		for (int i = 1; i <= 30; ++i) {
			if (ecf[i] >= n) {
				cout << i << endl;
				break;
			}
		}
	}
}