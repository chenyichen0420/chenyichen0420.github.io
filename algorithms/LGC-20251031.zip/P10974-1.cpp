#include<bits/stdc++.h>
using namespace std;
#define int long long
struct node {
	int p, v;
	node(int p = 0, int v = 0) :p(p), v(v) {};
}; vector<node>son[200005];
int t, n, d[200005], f[200005], ans;
inline void dfs(int p, int f) {
	for (const node& sp : son[p]) if (sp.p != f)
		if (dfs(sp.p, p), son[sp.p].size() == 1) d[p] += sp.v;
		else d[p] += min(sp.v, d[sp.p]);
}
inline void dps(int p, int fa) {
	for (const node& sp : son[p]) if (sp.p != fa) {
		if (son[p].size() == 1) f[sp.p] = d[sp.p] + sp.v;
		else if (son[sp.p].size() == 1) f[sp.p] = d[sp.p] + min(sp.v, f[p] - sp.v);
		else f[sp.p] = d[sp.p] + min(sp.v, f[p] - min(d[sp.p], sp.v));
		dps(sp.p, p); ans = max(ans, f[sp.p]);
	}
}
signed main() {
	ios::sync_with_stdio(0);
	for (cin >> t; t; t--) {
		for (int i = 1; i <= n; ++i) son[i].clear();
		memset(d, 0, sizeof d); cin >> n;
		for (int i = 1, l, r, v; i != n; ++i)
			cin >> l >> r >> v,
			son[l].emplace_back(r, v),
			son[r].emplace_back(l, v);
		dfs(1, 0); f[1] = ans = d[1]; dps(1, 0);
		cout << ans << endl;
	}
}