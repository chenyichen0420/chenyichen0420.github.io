#include<bits/stdc++.h>
using namespace std;
#define getchar getchar_unlocked
inline int read() {
	int r(0), s(1); char c(getchar());
	while (c < '0' || c > '9') { if (c == '-') s = -1; c = getchar(); }
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar();
	return r * s;
}
int n, v;
signed main() {
	n = read();
	while (n--) v += read();
	cout << v << endl;
	return 0;
}