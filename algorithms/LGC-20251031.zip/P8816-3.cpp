#include<bits/stdc++.h>
using namespace std;
struct node{
	int x,y;
}p[505];
int n,k,dp[505][105],ans;
inline bool cmp(node l,node r){
	return (l.x==r.x&&l.y<r.y)||l.x<r.x;
}
int main(){
	cin>>n>>k; ans=k+1;
	for(int i=1;i<=n;++i) cin>>p[i].x>>p[i].y;
	sort(p+1,p+n+1,cmp);
	for(int i=1;i<=n;++i){
		for(int j=0;j<=k;++j){
			dp[i][j]=1;
			for(int _k=0;_k<i;_k++){
				if(p[_k].x>p[i].x||p[_k].y>p[i].y) continue;
				int dis=p[i].x-p[_k].x+p[i].y-p[_k].y-1;
				if(j>=dis) dp[i][j]=max(dp[i][j],dp[_k][j-dis]+1);
			}
			ans=max(ans,dp[i][k]+k);
		}
	}
	cout<<ans<<endl;
	return 0;
}