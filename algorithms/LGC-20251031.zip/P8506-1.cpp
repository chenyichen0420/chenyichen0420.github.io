#include<iostream>
#include<string>
using namespace std;
int main(){
	ios::sync_with_stdio(false);
	int n, ans = 0; string s;
	cin >> n, getline(cin, s);
	for (int i = 0; i < n; i++){
		getline(cin, s); int j = 0;
		while (j < s.length() && s[j] == ' ') j++;
		if (j >= s.length() - 1 || s[j] != '#' || s[++j] != ' ') continue;
		while (j < s.length() && s[j] == ' ') j++;
		if (j >= s.length()) continue;
		ans++;
	}
	cout << ans << endl;
	return 0;
}