#include<bits/stdc++.h>
using namespace std;
int n, m, a[1000005], t[1000005], sz, cn, ans[1000005];
struct node {
	int l, r, id;
	inline int gbk(int ps) {
		return ps / sz;
	}
	inline bool operator<(const node& v) {
		return gbk(l) != gbk(v.l) ? l < v.l : r < v.r;
	}
}q[1000005];
inline void add(int p) {
	cn += !t[a[p]]++;
}
inline void del(int p) {
	cn -= !--t[a[p]];
}
signed main() {
	ios::sync_with_stdio(0); cin >> n;
	for (int i = 1; i <= n; ++i) cin >> a[i];
	cin >> m;
	for (int i = 1; i <= m; ++i)
		cin >> q[i].l >> q[i].r, q[i].id = i;
	sz = sqrt(n); sort(q + 1, q + m + 1);
	for (int i = 1, nl = 1, nr = 0; i <= m; ++i) {
		while (nr < q[i].r) add(++nr);
		while (nl > q[i].l) add(--nl);
		while (nr > q[i].r) del(nr--);
		while (nl < q[i].l) del(nl++);
		ans[q[i].id] = cn;
	}
	for (int i = 1; i <= m; ++i) cout << ans[i] << endl;
}