#include<bits/stdc++.h>
using namespace std;
int n, a[100005], r[2000005], l[2000005]; bool vis[2000005];
inline int find(int p) {
	if (!vis[p]) return p;
	return r[p] = find(r[p]);
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n; r[0] = 1; l[2000001] = 2000000;
	for (int i = 1; i <= 2e6; ++i)
		r[i] = i + 1, l[i] = i - 1;
	for (int i = 1; i <= n; ++i) {
		cin >> a[i]; a[i] = find(a[i]);
		vis[a[i]] = 1;
		r[l[a[i]]] = r[a[i]];
		l[r[a[i]]] = l[a[i]];
	}
	for (int i = 1; i <= n; ++i)
		cout << a[i] << " ";
}