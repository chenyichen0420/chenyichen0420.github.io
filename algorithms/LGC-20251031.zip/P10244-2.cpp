#include<bits/stdc++.h>
using namespace std;
string s[5]; int n;
signed main() {
	ios::sync_with_stdio(0);
	cin>>n;
	for(int i=1;i<=4;++i) cin>>s[i];
	for(int i=0;i<n;++i){
		if(s[1][i]>s[3][i]||s[1][i]==s[3][i]&&s[2][i]>s[4][i]) swap(s[2][i],s[4][i]);
	}
	cout<<s[2]<<endl;
	return 0;
}