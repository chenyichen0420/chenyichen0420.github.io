#include<iostream>
#include<algorithm>
#include<map>
#define int long long
using namespace std;
struct node {
	int d, m;
}r[300005];
bool cmp(node l, node r) {
	return l.d < r.d;
}
map<int, bool>chk; int n, k, rw[300005], ans; map<int, int>pl;
signed main() {
	cin >> n >> k; int tn = 0;
	for (int i = 1; i <= n; ++i)
		cin >> r[i].d >> r[i].m;
	sort(r + 1, r + n + 1, cmp); tn = r[n].d;
	for (int i = 1; i <= n; ++i)
		rw[r[i].d] += r[i].m;
	for (int i = 1; i <= tn + 1; ++i) {
		if (rw[i - 1] > 0) ans += min(rw[i - 1],k);
		ans += min(k - min(rw[i - 1], k), rw[i]);
		rw[i] -= min(k - min(rw[i - 1], k), rw[i]);
	}
	cout << ans << endl;
	return 0;
}