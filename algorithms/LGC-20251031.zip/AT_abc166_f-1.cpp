#include<bits/stdc++.h>
using namespace std;
int n,v[4]; char t[100005][3],an[100005];
inline void net(){
	cout<<"No\n";
	exit(0);
}
int main(){
	ios::sync_with_stdio(0);
	cin>>n>>v[0]>>v[1]>>v[2];
	for(int i=1;i<=n;++i) cin>>t[i];
	for(int i=1;i<=n;++i){
		int cl=t[i][0]-'A',cr=t[i][1]-'A';
		if(v[cl]>v[cr]) v[cl]--,v[cr]++,an[i]=cr+'A';
		else if(v[cl]<v[cr]) v[cr]--,v[cl]++,an[i]=cl+'A';
		else{
			if(!v[cl]) net();
			int ccl=t[i+1][0]-'A',ccr=t[i+1][1]-'A';
			if(cl==ccl&&cr==ccr) an[i]=cl+'A',an[i+1]=cr+'A';
			else if(cl==ccl) an[i]=cl+'A',an[i+1]=ccr+'A',v[cr]--,v[ccr]++;
			else if(cr==ccr) an[i]=cr+'A',an[i+1]=ccl+'A',v[cl]--,v[ccl]++;
			else if(cl==ccr) an[i]='B',an[i+1]='A',v[2]--,v[0]++;  //BC-AB
			else if(cr==ccl) an[i]='B',an[i+1]='C',v[2]++,v[0]--;
			else an[i]=cl+'A',v[cl]++,v[cr]--; i++;
		}
		if(v[0]<0||v[1]<0||v[2]<0) net();
	}
	cout<<"Yes\n";
	for(int i=1;i<=n;++i)cout<<an[i]<<"\n";
}
/*
hack:
9 1 0 1
BC
AB
BC
BC
AB
AB
AC
AB
AB
*/