#include<iostream>
#include<algorithm>
using namespace std;
int main() {
	int cntzo = 0, cntfo = 0, n, a;
	cin >> n;
	while (n--) {
		scanf("%d", &a);
		if (a == 1) cntzo++;
		else cntfo++;
	}
	int minval = min(cntzo, cntfo);
	for (int i = 1; i <= minval; ++i) printf("1 -1 ");
	cntzo -= minval; cntfo -= minval;
	if(cntzo) for (int i = 1; i <= cntzo; ++i) printf("1 ");
	else for (int i = 1; i <= cntfo; ++i) printf("-1 ");
	return 0;
}