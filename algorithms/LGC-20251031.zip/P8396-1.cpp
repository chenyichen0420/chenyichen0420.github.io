#include<bits/stdc++.h>
using namespace std;
string a[100005][3],b[100005][3],s1,s2,s3;
map<string,int>s;
int num,x,y,g;
int main(){
	cin>>x;
	for(int i=1;i<=x;i++)
		cin>>a[i][1]>>a[i][2];
	cin>>y;
	for(int i = 1;i <= y;i++)
		cin>>b[i][1]>>b[i][2];
	cin>>g;
	for(int i=1;i<=g;i++)
		cin>>s1>>s2>>s3,s[s1]=s[s2]=s[s3]=i;
	for(int i=1;i<=x;i++)
		if(s[a[i][1]]!=s[a[i][2]])
			num++;
	for(int i=1;i<=y;i++)
		if(s[b[i][1]]==s[b[i][2]])
			num++;
	cout<<num<<endl;
	return 0;
}