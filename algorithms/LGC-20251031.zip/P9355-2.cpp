#include<bits/stdc++.h>
using namespace std;
int main(){
    ios::sync_with_stdio(false);
	register long long t,n,m;
	cin.tie(0);cout.tie(0);cin>>t;
	while(t--){
		cin>>n>>m;
		cout<<(n-1)*m+(m-1)*n<<endl;
	}
	return 0;
}