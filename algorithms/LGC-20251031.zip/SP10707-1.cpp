#include<bits/stdc++.h>
using namespace std;
vector<int>son[40005]; int bs;
int n, m, a[40005], b[40005], l2[205];
bitset<40008>ha[205][9], ht;
int hs[40005], sz[40005], f[40005], d[40005];
inline void spl_lnk(int p, int fa) {
	f[p] = fa; d[p] = d[fa] + 1; sz[p] = 1;
	for (int sp : son[p]) if (sp != fa)
		spl_lnk(sp, p), sz[p] += sz[sp],
		(sz[sp] > sz[hs[p]]) && (hs[p] = sp);
}
int lnk[40005], nid[40005], cc;
inline void down_he(int p, int t) {
	lnk[p] = t; nid[p] = ++cc; b[cc] = a[p];
	if (!hs[p]) return; down_he(hs[p], t);
	for (int sp : son[p]) if (!lnk[sp]) down_he(sp, sp);
}
#define bk(v) ((v - 1) / bs + 1)
inline void init() {
	for (int i = 1; i <= n; ++i) ha[bk(i)][0][b[i]] = 1;
	for (int i = 1; i <= 8; ++i)
		for (int j = 1; j + (1ll << i) - 1 <= bk(n); ++j)
			ha[j][i] = ha[j][i - 1] | ha[j + (1ll << i - 1)][i - 1];
}
inline void qub(int l, int r) {
	int bl = bk(l), br = bk(r), p;
	if (bl == br) {
		for (int i = l; i <= r; ++i) ht[b[i]] = 1;
		return;
	}
	for (int i = l; bk(i) == bl; ++i) ht[b[i]] = 1;
	for (int i = r; bk(i) == br; --i) ht[b[i]] = 1;
	if (br - bl > 1) p = l2[br - bl - 1],
		ht |= ha[bl + 1][p] | ha[br - (1ll << p)][p];
}
inline int que(int l, int r) {
	ht.reset();
	while (lnk[l] != lnk[r]) {
		if (d[lnk[l]] < d[lnk[r]]) swap(l, r);
		qub(nid[lnk[l]], nid[l]); l = f[lnk[l]];
	}
	if (d[l] > d[r]) swap(l, r); qub(nid[l], nid[r]);
	return ht.count();
}
signed main() {
	ios::sync_with_stdio(0); cin >> n >> m;
	for (int i = 1; i <= n; ++i) cin >> a[i];
	memcpy(b, a, sizeof a); sort(b + 1, b + n + 1);
	for (int i = 1; i <= n; ++i)
		a[i] = lower_bound(b + 1, b + n + 1, a[i]) - b;
	for (int i = 1, l, r; i != n; ++i)
		cin >> l >> r,
		son[l].emplace_back(r),
		son[r].emplace_back(l);
	spl_lnk(1, 0); down_he(1, 1);
	bs = sqrt(n) * 2; init();
	for (int i = 2; i <= bk(n); ++i) l2[i] = l2[i >> 1] + 1;
	for (int i = 1, l, r, la = 0; i <= m; ++i)
		cin >> l >> r, cout << (la = que(l, r)) << endl;
}