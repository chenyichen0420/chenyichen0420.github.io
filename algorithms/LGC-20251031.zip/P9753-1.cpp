#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,ans; char c[2000005];
int v[2000005],lp[2000005];
signed main(){
    ios::sync_with_stdio(0);
    cin>>n>>(c+1); lp[0]=1;
    for(int i=1;i<=n;++i){
        if(c[i]==c[i-1]){
            lp[i]=i-2;
            v[i]=v[lp[i]]+1;
            ans+=v[i];
            continue;
        }
        int p=i-1;
        while(lp[p]<p&&c[i]!=c[p]) p=lp[p];
        if(c[i]!=c[p]) lp[i]=i;
        else v[i]=v[lp[i]=p-1]+1; ans+=v[i];
    }
    cout<<ans<<endl;
    return 0;
}