#include<bits/stdc++.h>
using namespace std;
#define int long long
int n;
signed main() {
	ios::sync_with_stdio(0);
	cin >> n;
	cout << (n & 1 ? "No\n" : "Yes\n");
	return 0;
}