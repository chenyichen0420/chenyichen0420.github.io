#include<iostream>
#include<cmath>
#include<algorithm>
#include<vector>
#include<stack>
#include<queue>
#include<unordered_map>
#include<map>
using namespace std;
long long x = 100000ll * 1000000ll , y, z;
signed main() {
	cin >> y >> z;
	if (z == (long long)1e12) cout << abs(x + y - z) << endl;
	else if (z < 100000ll * 1000000ll) cout << x + y - z << endl;
	else {
		x = z / (long long)1e6;
		cout << min(min((x + 1)*1e6 + y - z, abs(x*1e6 + y - z)), abs((x - 1)*1e6 + y - z)) << endl;
	}
}