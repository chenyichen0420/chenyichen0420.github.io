#include<bits/stdc++.h>
using namespace std;
int n, m, k, fa[1001], t, l, r;
inline int find(int val) {
	if (val == fa[val]) return val;
	return fa[val] = find(fa[val]);
}
inline void mer(int l, int r) {
	l = find(l); r = find(r);
	fa[l] = r;
}
inline bool jud(int l, int r) {
	return find(l) == find(r);
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m >> k;
	for (int i = 1; i <= n; ++i) fa[i] = i;
	for (int i = 1; i <= m; ++i)
		for (int j = 1; j <= n; ++j)
			cin >> t, mer(t, j);
	for (int i = 1; i <= k; ++i)
		cin >> l >> r,
		cout << (jud(l, r) ? "DA\n" : "NE\n");
	return 0;
}