#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr int p=998244353;
int t,n,m,a[10000005],jc[10000005],ny[10000005],ans;
inline int qpow(int a,int b=p-2){
	int ret=1;
	for(;b;b>>=1,a=a*a%p)
		(b&1)&&(ret=ret*a%p);
	return ret;
}
inline int cvl(int n,int m){
	if(n<m||n<0||m<0) return 0;
	return jc[n]*ny[m]%p*ny[n-m]%p;
}
signed main(){
	ios::sync_with_stdio(0); jc[0]=1;
	for(int i=1;i<=1e7;++i) jc[i]=jc[i-1]*i%p;
	ny[10000000]=qpow(jc[10000000]);
	for(int i=1e7;i>0;i--) ny[i-1]=ny[i]*i%p;
	for(cin>>t;t;t--){
		cin>>n>>m; m--; int tn=n;
		for(int i=1;i<=tn;++i) cin>>a[i];
		for(int i=1;i<tn;++i)
			(a[i]>=a[i+1])&&(m--,n--);
		n--; ans=0;
		for(int i=0;i<=m;++i)
			ans=(ans+cvl(n,i))%p;
		cout<<ans<<endl;
	}
	return 0;
} 