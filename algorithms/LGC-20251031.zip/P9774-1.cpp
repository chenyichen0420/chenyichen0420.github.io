#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m,v,jc[1000005];
inline void init(){
	for(int i=jc[0]=1;i<m;++i)
		jc[i]=jc[i-1]*i%m;
}
inline int qpow(int l,int r){
	int ret=1,tmp=l;
	for(;r;r>>=1,tmp=tmp*tmp%m)
		if(r&1) ret=ret*tmp%m;
	return ret;
}
inline int que(int vl){
	if(vl<m) return jc[vl];
	return qpow(jc[m-1],vl/m)*jc[vl%m]%m*que(vl/m)%m;
}
signed main(){
	ios::sync_with_stdio(0);
	for(cin>>n>>m,init();n;n--) cin>>v,cout<<que(v)<<endl;
} 