#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online=0;
//于是设 f[i][j][k] 表示当前看了 i 个 PPT 并且在第 j 个教室，另外一个教室在 f[i][j][k] 这个时刻放映的 PPT 看没看过（k=0,1）最少用时
int n[2],s,l[2][300005],r[2][300005],dp[600005][2][2],ans; pair<int,int>t[300005];
inline int cid(int c,int p){
    int id=lower_bound(r[c]+1,r[c]+n[c]+1,p)-r[c];
    if(id<=n[c]&&p>=l[c][id]) return id; return 0;
}
inline int nxt(int c,int p){
    int id=upper_bound(l[c]+1,l[c]+n[c]+1,p)-l[c];
    if(id<=n[c]) return id; return 0;
}
inline void tmin(int&l,const int r){(l>r)&&(l=r);}
signed main(){
    if(online)
        freopen("lesson.in","r",stdin),
        freopen("lesson.out","w",stdout);
    ios::sync_with_stdio(0); cin>>n[0]>>n[1]>>s;
    for(int c:{0,1}){
        for(int i=1;i<=n[c];++i) cin>>t[i].first>>t[i].second,t[i].second--;
        sort(t+1,t+n[c]+1);
        for(int i=1;i<=n[c];++i) l[c][i]=t[i].first,r[c][i]=t[i].second;
    }
    memset(dp,0x0f,sizeof dp); dp[!l[0][1]][0][0]=0;
    for(int i=0,cup,cnp,anp;i<=n[0]+n[1];++i)
        for(int rnd=0;rnd!=2;++rnd)
            for(int j:{0,1})
                for(int k:{0,1})
                    if(dp[i][j][k]<=1e10){
                        ans=i; cup=cid(j,dp[i][j][k]), cnp=nxt(j,dp[i][j][k]), anp=cid(!j,dp[i][j][k]+s);
//                        cerr<<j<<" "<<dp[i][j][k]<<" "<<cup<<" "<<cnp<<" "<<anp<<endl;
                        if(cnp) tmin(dp[i+1][j][k&&anp&&anp==cid(!j,l[j][cnp]+s)],l[j][cnp]);
                        tmin(dp[i+(anp&&!k)][!j][cup&&cup==cid(j,dp[i][j][k]+s*2)],dp[i][j][k]+s);
                    }
    cout<<ans<<endl; return 0;
}
