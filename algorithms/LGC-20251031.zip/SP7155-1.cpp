#include<bits/stdc++.h>
using namespace std;
#define int long long
string s1, s2, s3;
template<const int p,const int mod>
struct shash {
	int pv[100005], v[100005];
	inline void inip() {
		for (int i = pv[0] = 1; i <= 1e5; ++i) pv[i] = pv[i - 1] * p % mod;
	}
	inline void init(const string& s) {
		for (int i = 1; i <= s.size(); ++i)
			v[i] = (v[i - 1] * p + s[i - 1]) % mod;
	}
	inline int get(int l, int r) {
		return (v[r] - v[l] * pv[r - l] % mod + mod) % mod;
	}
};
shash<13331, 1000000097>sh[3];
inline int msfb(int p1, int l1, int p2, int ml) {
	for (int i = ml; i >= 1; --i)
		if (sh[p1].get(l1 - i, l1) == sh[p2].get(0, i))
			return i;
	return 0;
}
inline bool has(int p1, int l1, int p2, int l2) {
	for (int i = 0, j = l2; j <= l1; ++i, ++j)
		if (sh[p1].get(i, j) == sh[p2].get(0, l2))
			return 1;
	return 0;
}
signed main() {
	ios::sync_with_stdio(0);
	sh[0].inip(); sh[1].inip(); sh[2].inip();
	while (cin >> s1 >> s2 >> s3) {
		sh[0].init(s1); sh[1].init(s2); sh[2].init(s3);
		if (has(0, s1.size(), 1, s2.size())) sh[1].init(s2 = "");
		if (has(0, s1.size(), 2, s3.size())) sh[2].init(s3 = "");
		if (has(1, s2.size(), 0, s1.size())) sh[0].init(s1 = "");
		if (has(1, s2.size(), 2, s3.size())) sh[2].init(s3 = "");
		if (has(2, s3.size(), 0, s1.size())) sh[0].init(s1 = "");
		if (has(2, s3.size(), 1, s2.size())) sh[1].init(s2 = "");
		int v123 =
			msfb(0, s1.size(), 1, min(s1.size(), s2.size())) +
			msfb(1, s2.size(), 2, min(s2.size(), s3.size())); //1-2-3
		int v132 =
			msfb(0, s1.size(), 2, min(s1.size(), s3.size())) +
			msfb(2, s3.size(), 1, min(s3.size(), s2.size())); //1-2-3
		int v213 =
			msfb(1, s2.size(), 0, min(s2.size(), s1.size())) +
			msfb(0, s1.size(), 2, min(s1.size(), s3.size())); //1-2-3
		int v231 =
			msfb(1, s2.size(), 2, min(s2.size(), s3.size())) +
			msfb(2, s3.size(), 0, min(s3.size(), s1.size())); //1-2-3
		int v312 =
			msfb(2, s3.size(), 0, min(s3.size(), s1.size())) +
			msfb(0, s1.size(), 1, min(s1.size(), s2.size())); //1-2-3
		int v321 =
			msfb(2, s3.size(), 1, min(s3.size(), s2.size())) +
			msfb(1, s2.size(), 0, min(s2.size(), s1.size())); //1-2-3
		cout << s1.size() + s2.size() + s3.size() - max({ v123,v132,v213,v231,v312,v321 }) << endl;
	}
}