#include<bits/stdc++.h>
using namespace std;
int main(){
	ios::sync_with_stdio(false);
	cout<<"NIE\nNIE\nTAK\nTAK\nTAK\nTAK\nNIE\nTAK\nTAK\nNIE\n";
	//     1    2    3    4    5    6    7    8    9    10
	return 0;
}