#include<bits/stdc++.h>
using namespace std;
int n, m, x[2005], y[2005], dis[2005][155][155], f[2005];
bool vis[155][155]; int cd;
struct node {
	int l, r, v;
	node(int li = 0, int ri = 0, int vi = 0) :l(li), r(ri), v(vi) {};
	inline bool operator<(const node& t) {
		return v < t.v;
	}
}tmp, e[2005 * 2005]; int ecn, ans;
constexpr int dx[] = { 2,2,1,1,-1,-1,-2,-2 }, dy[] = { 1,-1,2,-2,2,-2,1,-1 };
inline bool ok(int x, int y) {
	return x > 0 && x <= m && y > 0 && y <= m && !vis[x][y];
}
inline void bfs(int x, int y, int id) {
	memset(vis, 0, sizeof vis); vis[x][y] = 1;
	queue<node>q; q.emplace(x, y, 0);
	while (q.size()) {
		tmp = q.front(); q.pop();
		dis[id][tmp.l][tmp.r] = tmp.v;
		for (int i = 0; i != 8; ++i)
			if (ok(tmp.l + dx[i], tmp.r + dy[i]))
				vis[tmp.l + dx[i]][tmp.r + dy[i]] = 1,
				q.emplace(tmp.l + dx[i], tmp.r + dy[i], tmp.v + 1);
	}
}
inline int find(int p) {
	return f[p] != p ? f[p] = find(f[p]) : p;
}
inline bool merge(int l, int r) {
	l = find(l), r = find(r);
	if (l == r) return 0;
	return f[l] = r, 1;
}
signed main() {
	ios::sync_with_stdio(0); cin >> n >> m;
	for (int i = 1; i <= n; ++i) cin >> x[i] >> y[i];
	for (int i = 1; i <= n; ++i) bfs(x[i], y[i], i), f[i] = i;
	for (int i = 1; i <= n; ++i)
		for (int j = i + 1; j <= n; ++j)
			e[++ecn] = node(i, j, dis[i][x[j]][y[j]] + 1);
	sort(e + 1, e + ecn + 1);
	for (int i = 1; i <= ecn; ++i)
		ans += merge(e[i].l, e[i].r) ? e[i].v : 0;
	cout << ans << endl;
}