#include<bits/stdc++.h>
using namespace std;
int n,a[100005],ans; 
priority_queue<int>d;
signed main(){
	ios::sync_with_stdio(0);
	cin>>n;
	for(int i=1;i<=n;++i)
		cin>>a[i],d.emplace(a[i]);
	while(d.size()){
		int tp=d.top(); d.pop();
		if(tp==1) break;
		while(d.size()&&d.top()==tp){
			d.pop();
		}
		d.emplace(tp-1); ans++;
	}
	cout<<ans+n<<endl;
	return 0;
}