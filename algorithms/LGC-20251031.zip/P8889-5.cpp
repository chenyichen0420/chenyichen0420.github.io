#include<bits/stdc++.h>
using namespace std;
#define int long long
int m,n,a[500005],b,cnt;
map<int,bool>can;
signed main() {
	scanf("%lld%lld",&m,&n);
	for(int i=1;i<=m;++i) scanf("%lld",&a[i]);
	for(int i=1;i<=n;++i) scanf("%lld",&b),can[b]=true;
	int dis=0;
	for(int i=1;i<=m;++i)
		if(can[a[i]]){
			if(dis!=0) cnt++;
			dis=0;
		}
		else dis++;
	if(dis!=0) cnt++;
	cout<<cnt<<endl;
	return 0;
}