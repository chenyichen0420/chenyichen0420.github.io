#include<bits/stdc++.h>
using namespace std;
#define int long long
int jg[1000005],cnt,n,w,mon;
signed main(){
	cin>>n;
	for(int i=1;i<=n;++i) cin>>jg[i];
	sort(jg+1,jg+n+1); cin>>w;
	for(int i=1;i<=n;++i){
		if(jg[i]>w) break;
		mon=jg[i];
	}
	for(int i=1;i<=n;++i)
		if(mon>=jg[i])
			cnt++,mon-=jg[i];
	cout<<cnt<<endl;
	return 0;
}