#include<iostream>
#include<queue>
using namespace std;
queue<int>q;
int a[100006], b[100006], c[100006], d[100006], e[100006], f[100006], check[100006], n, sum = 0;
int main(){
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
		f[a[i]] = i;
	}
	for (int i = 1; i <= n; i++)
		cin >> b[i];
	for (int i = 1; i <= n; i++)
		cin >> c[i];
	for (int i = 1; i <= n; i++) {
		d[b[i]]++;
		e[c[i]]++;
	}
	for (int i = 1; i <= n; i++) {
		if (d[i] == 0 || e[i] == 0)
			q.push(i);
		while (!q.empty()) {
			int p = q.front();
			q.pop();
			if (check[f[p]]) 
				continue;
			check[f[p]] = 1;
			d[b[f[p]]]--;
			e[c[f[p]]]--;
			if (d[b[f[p]]] == 0)
				q.push(b[f[p]]);
			if (e[c[f[p]]] == 0)
				q.push(c[f[p]]);
			sum++;
		}
	}
	cout << sum;
	return 0;
}