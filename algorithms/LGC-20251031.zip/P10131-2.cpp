#include<bits/stdc++.h>
using namespace std;
int t, n, a[200005]; 
map<int, bool>ans; map<int, bool>::iterator it;
int main() {
	ios::sync_with_stdio(0);
	cin >> t;
	while (t--) {
		cin >> n; ans.clear();
		for (int i = 1; i <= n; ++i) {
			cin >> a[i];
			if (i > 1 && a[i] == a[i - 1]) ans[a[i]] = 1;
			if (i > 2 && a[i] == a[i - 2]) ans[a[i]] = 1;
		}
		for (it = ans.begin(); it != ans.end(); ++it)
			cout << it->first << " ";
		if (!ans.size()) cout << "-1";
		cout << endl;
	}
	return 0;
}