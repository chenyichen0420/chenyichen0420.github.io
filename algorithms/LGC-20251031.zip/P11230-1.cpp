#include<bits/stdc++.h>
using namespace std;
#ifdef _WIN32
#define getchar_unlocked _getchar_nolock
#define putchar_unlocked _putchar_nolock
#endif
#define enumi for (int j = l[i - 1] + 1, p = -1e9; j <= l[i]; ++j)
inline int read() {
	int r = 0; char c(getchar_unlocked()); while (c < '0' || c>'9') c = getchar_unlocked();
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar_unlocked(); return r;
}
int t, n, k, m, l[100005], v[200005], app[200005];
int ans[105][200005];bool vis[200005];
vector<int>lp; vector<pair<int, int>> np;
inline void init() {
    lp.clear(); np.clear();
	for (int i = 1; i <= n; i++) enumi{
			if (j - p < k) np.emplace_back(i, v[j]), ans[1][v[j]] = 1;
			if (v[j] == 1) p = j;
	}
	for (int rp = 2; rp <= 100; rp++) {
		memset(app, -1, sizeof app);
		for (pair<int, int> ps : np)
			if (app[ps.second] == -1) app[ps.second] = ps.first;
			else if (app[ps.second] != ps.first) app[ps.second] = 0;
		for (int i = 1; i <= n; i++)
			enumi if (~app[v[j]] && app[v[j]] != i) lp.emplace_back(j);
		np.clear(); for (int ps : lp) vis[ps] = 1;
		for (int i = 1; i <= n; i++) enumi{
				if (j - p < k) np.emplace_back(i, v[j]), ans[rp][v[j]] = 1;
				if (vis[j]) p = j;
		}
		for (int ps : lp) vis[ps] = 0; lp.clear();
	}
}
int main() {
	ios::sync_with_stdio(0);
	for (t = read(); t; t--) {
		n = read(); k = read(); m = read();
		for (int i = 1; i <= n; ++i) {
			l[i] = read() + l[i - 1];
			enumi v[j] = read();
		}
		memset(ans, 0, sizeof ans);
		memset(vis, 0, sizeof vis); init();
		for (int i = 1, lc, rc; i <= m; ++i)
			lc = read(), rc = read(),
			putchar_unlocked(ans[lc][rc] ^ 48),
			putchar_unlocked('\n');
	}
	return 0;
}