#include<bits/stdc++.h>
using namespace std;
struct node {
	int p, v;
	node(int pi = 0, int vi = 0) :p(pi), v(vi) {};
}; queue<node>q;
int n, k, m, rd[5005]; vector<int>son[5005];
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m >> k;
	for (int i = 1,p; i <= k; ++i)
		cin >> p, q.emplace(p, 0);
	cin >> k;
	for (int i = 1, p, c, v; i <= k; ++i) {
		cin >> v >> c;
		while (c--)
			cin >> p, rd[v]++,
			son[p].emplace_back(v);
	}
	while (q.size()) {
		node tmp = q.front(); q.pop();
		if (tmp.p == m) {
			cout << tmp.v << endl;
			return 0;
		}
		for (int sp : son[tmp.p])
			if (!--rd[sp]) q.emplace(sp, tmp.v + 1);
	}
	cout << "-1\n";
}