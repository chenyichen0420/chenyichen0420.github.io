#include<bits/stdc++.h>
using namespace std;
int t, n, m, a[105], dp[105][105];
inline void tmin(int& l, const int r) {
	(l > r) && (l = r);
}
inline bool check(int l, int r, int d) {
	string vl = "";
	for (int i = 0; i * d != (r - l + 1); ++i) {
		string tmp = "";
		for (int j = l + i * d; j != l + (i + 1) * d; ++j)
			tmp += char(a[j] ^ 48);
		if (!vl.size()) vl = tmp;
		else if (vl != tmp) return 0;
	}
	return 1;
}
int main() {
	ios::sync_with_stdio(0);
	for (cin >> t; t; t--) {
		cin >> n >> m; memset(dp, 0x3f, sizeof dp);
		for (int i = 1; i <= n; ++i) cin >> a[i];
		for (int i = 1; i <= n; ++i) dp[i][i] = 1;
		for (int l = 2; l <= n; ++l)
#define t (s + l - 1) 
			for (int s = 1; t <= n; ++s) {
				for (int j = s; j != t; ++j)
					tmin(dp[s][t], dp[s][j] + dp[j + 1][t]);
				for (int j = 1; j != l; ++j)
					if (l % j == 0)
						if (check(s, t, j)) {
							tmin(dp[s][t], dp[s][s + j - 1]);
							break;
						}
			}
		puts(dp[1][n] <= m ? "YES" : "NO");
	}
}