#include<bits/stdc++.h>
using namespace std;
#define int long long 
int t,n,k,a[300005],mx,kt,res;
string sk,sm,sd;
struct node{
	int l,r;
	node(int li=0,int ri=0){
		l=li,r=ri;
	}
	friend bool operator<(const node&l,const node&r){
		return l.l^r.l?l.l<r.l:l.r<r.r;
	}
};vector<node>v;
inline long long stoim(string s){
	int vl=0;
	for(int i=0;i<s.size();++i){
		vl=vl*10+(s[i]^48);
	}
	return vl;
}
signed main() {
	ios::sync_with_stdio(0);
	cin>>t;
	while(t--){
		cin>>n>>k; mx=0; res=0; v.clear();
		for(int i=1;i<=n;++i)
			cin>>a[i],mx=max(mx,stoim(to_string(i)+to_string(a[i])));
		if(k==1){
			cout<<"0\n";
			continue;
		}
		kt=k;
		while(kt<=mx){
			sk=to_string(kt);
			for(int i=1;i<sk.size();++i){
				sm=sk.substr(0,i); sd=sk.substr(i,sk.size()-i);
				if(stoim(sm)>n) break;
				if(stoim(sd)<=a[stoim(sm)]&&sd[0]!='0')
					res++,v.push_back(node(stoim(sm),stoim(sd)));
			}
			kt*=k;
		}
		cout<<res<<endl; sort(v.begin(),v.end());
		for(int i=0;i<res;++i) cout<<v[i].l<<" "<<v[i].r<<endl;
	}
	return 0;
}