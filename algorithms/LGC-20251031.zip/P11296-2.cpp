#include<bits/stdc++.h>
using namespace std;
#define int long long
int h, n, p[10005], sum, mn[20005];
signed main() {
	ios::sync_with_stdio(0); cin >> h >> n;
	for (int i = 0; i != n; i++) cin >> p[i], sum += p[i];
	for (int i = 0; i != 2 * n; i++) {
		mn[i + 1] = max(mn[i] + p[i % n], 0ll);
		if (mn[i + 1] >= h) {
			cout << i / n << ' ' << i % n << endl;
			return 0;
		}
	}
	if (sum <= 0) return cout << "-1 -1\n", 0;
	int ans = 1e18, ps = 0;
	for (int i = 0; i != n; i++) {
		int nd = 1 + (h - mn[n + i + 1] + sum - 1) / sum;
		if (ans > nd) ans = nd, ps = i;
	}
	cout << ans << ' ' << ps << endl;
}