#include<bits/stdc++.h>
using namespace std;
#define int long long
inline int lb(int v) { return v & -v; }
int n, m, a[50005];
struct tree_array {
	int c[50005];
	inline void ins(int p, int v) {
		do c[p] ^= v;while ((p += lb(p)) <= n);
	}
	inline int que(int p) {
		int ans = 0;
		do ans ^= c[p];while (p -= lb(p));
		return ans;
	}
}ta;
struct libs {
	int a[32];
	libs() { memset(a, 0, sizeof a); }
	inline void ins(int v) {
		for (int i = 30;v;i--)
			if (v >> i & 1)
				if (a[i]) v ^= a[i];
				else return void(a[i] = v);
	}
	inline libs operator+(libs r) {
		for (int i = 30;i >= 0;i--) if (a[i]) r.ins(a[i]);
		return r;
	}
	inline void operator+=(libs r) {
		for (int i = 30;i >= 0;i--) if (r.a[i]) ins(r.a[i]);
	}
}cur;
struct seg_tree {
	struct node { libs lib; int l, r; }re[200005];
	inline void build(int p, int l, int r) {
		for (int i = l;i <= r;i++) re[p].lib.ins(a[i]);
		if ((re[p].l = l) == (re[p].r = r)) return;
		build(p << 1, l, (l + r >> 1));
		build(p << 1 | 1, (l + r >> 1) + 1, r);
		re[p].lib = re[p << 1].lib + re[p << 1 | 1].lib;
	}
	inline void chg(int p, int cp, int v) {
		if (re[p].l == re[p].r) {
			re[p].lib = libs();
			re[p].lib.ins(a[re[p].l] ^= v);
			return;
		}
		if (cp <= re[p << 1].r) chg(p << 1, cp, v);
		else chg(p << 1 | 1, cp, v);
		re[p].lib = re[p << 1].lib + re[p << 1 | 1].lib;
	}
	inline libs que(int p, int l, int r) {
		if (re[p].l >= l && re[p].r <= r) return re[p].lib;
		libs ret;
		if (l <= re[p << 1].r) ret = que(p << 1, l, r);
		if (r > re[p << 1].r) ret += que(p << 1 | 1, l, r);
		return ret;
	}
}sgt;
inline void upd(int l, int r, int v) {
	ta.ins(l, v); sgt.chg(1, l, v);
	if (r != n) ta.ins(r + 1, v), sgt.chg(1, r + 1, v);
}
inline int que(int l, int r, int v) {
	int t = ta.que(l); if (l == r) return max(v, t ^ v);
	cur = sgt.que(1, l + 1, r); cur.ins(t);
	for (int i = 30;i >= 0;i--)
		(!(v >> i & 1)) && (v ^= cur.a[i]);
	return v;
}
signed main() {
	ios::sync_with_stdio(0); cin >> n >> m;
	for (int i = 1;i <= n;i++) cin >> a[i];
	for (int i = n;i >= 1;i--) 
		a[i] ^= a[i - 1], ta.ins(i, a[i]);
	sgt.build(1, 1, n);
	for (int i = 1, o, l, r, v;i <= m;i++)
		if (cin >> o >> l >> r >> v, o & 1) upd(l, r, v);
		else cout << que(l, r, v) << endl;
}