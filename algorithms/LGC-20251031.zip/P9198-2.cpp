#include<bits/stdc++.h>
using namespace std;
int n,m,q,x,y,c,t,val[4][105][105]; // color col row
inline bool chk(){
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m/2;++j)
			for(int k=1;k<=3;++k)
				if(val[k][i][j]!=val[k][i][m-j+1]) return 0;
	return 1;
}
signed main(){
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	cin>>n>>m>>q;
	for(int i=1;i<=q;++i){
		cin>>x>>y>>t>>c; c%=256;
		val[t][x][y]=(val[t][x][y]+c)%256;
		cout<<(chk()?"Yes\n":"No\n");
	}
}