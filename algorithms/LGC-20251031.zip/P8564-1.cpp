#include<bits/stdc++.h>
using namespace std;
#define int long long
int n, f[5005], a, b, dp[5005][5005], sz[5005]; vector<int>sn[5005];
inline void tmin(int& l, int r) {
	(l > r) && (l = r);
}
inline void dfs(const int& p, const int& f) {
	sz[p] = 1; dp[p][0] = 0;
	for (int i = 0; i ^ sn[p].size(); ++i) {
#define sp sn[p][i]
		if (sp == f) continue; dfs(sp, p);
		for (int s = sz[p] - 1; s >= 0; s--)
			for (int s2 = sz[sp] - 1; s2 >= 0; s2--)
				tmin(dp[p][s + s2], dp[p][s] + dp[sp][s2]);
		sz[p] += sz[sp];
	}
	for (int i = 0; i < sz[p] - 1; ++i)
		tmin(dp[p][sz[p] - 1], dp[p][i] + ::f[sz[p] - i]);
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n; memset(dp, 0x0f, sizeof dp);
	for (int i = 1; i ^ n; ++i) cin >> f[i + 1];
	for (int i = 1; i ^ n; ++i)
		cin >> a >> b,
		sn[a].emplace_back(b),
		sn[b].emplace_back(a);
	dfs(1, 0); cout << dp[1][n - 1] << endl;
	return 0;
}