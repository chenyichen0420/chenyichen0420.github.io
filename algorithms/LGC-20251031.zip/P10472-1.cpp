#include<bits/stdc++.h>
using namespace std;
char c[10005]; int sz,ans; stack<char>s;
int main(){
	ios::sync_with_stdio(0);
	cin>>c; sz=strlen(c);
	for(int i=0;i<sz;++i){
		while(s.size()) s.pop();
		for(int j=i;j<sz;++j){
			if(c[j]=='('||c[j]=='['||c[j]=='{') s.push(c[j]);
			else{
				if(!s.size()) break;
				if(c[j]==')'&&s.top()=='('||c[j]==']'&&s.top()=='['||c[j]=='}'&&s.top()=='{') s.pop();
				else break;
			}
			if(!s.size()) ans=max(ans,j-i+1);
		}
	}
	cout<<ans<<endl;
	return 0;
}