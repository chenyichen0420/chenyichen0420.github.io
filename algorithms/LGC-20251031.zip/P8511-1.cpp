#include<bits/stdc++.h>
using namespace std;
#define int long long
class trie {
	signed cnt, sn[500001 * 62][2]; unordered_map<int, int>vl;
public:
	inline void clear() {
		cnt = 0; vl.clear(); memset(sn, 0, sizeof sn);
	}
	inline void ins(long long v, int id) {
		int np = 0;
		for (int i = 61; ~i; i--)
			if (!sn[np][(v >> i) & 1]) np = sn[np][(v >> i) & 1] = ++cnt;
			else np = sn[np][(v >> i) & 1];
		vl[np] = id;
	}
	inline pair<long long, int> que(long long v) {
		int np = 0; long long ret = 0;
		for (int i = 61; ~i; i--)
			if (!sn[np][((v >> i) & 1) ^ 1]) np = sn[np][((v >> i) & 1)];
			else np = sn[np][((v >> i) & 1) ^ 1], ret |= (1ll << i);
		return make_pair(ret, vl[np]);
	}
}re; vector<int>son[500005], ps; bitset<500008>vis, lb; long long ans[500005];
int n, f[500005], a[500005]; pair<long long, pair<int, int>>ap; long long tmp;
inline void dfs(const int& p) {
	re.ins(a[p], p); lb[p] = 1;
	tmp = max(tmp, re.que(a[p]).first);
	for (int sp : son[p]) if (!lb[sp]) dfs(sp);
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n;
	for (int i = 2; i <= n; ++i) cin >> f[i], son[f[i]].emplace_back(i);
	for (int i = 1; i <= n; ++i) {
		cin >> a[i]; re.ins(a[i], i);
		pair<long long, int>vt = re.que(a[i]);
		if (vt.first > ap.first)
			ap = make_pair(vt.first, make_pair(vt.second, i));
	}
	re.clear();
	for (int np = ap.second.first; np != 1; np = f[np]) ps.emplace_back(np);
	reverse(ps.begin(), ps.end());
	for (int sp : ps) vis[sp] = lb[sp] = 1, dfs(f[sp]), ans[sp] = tmp;
	ps.clear(); re.clear(); tmp = 0; lb.reset();
	for (int np = ap.second.second; np != 1; np = f[np]) ps.emplace_back(np);
	reverse(ps.begin(), ps.end()); vis[1] = 1;
	for (int sp : ps) vis[sp] = lb[sp] = 1, dfs(f[sp]), ans[sp] = tmp;
	for (int i = 1; i <= n; ++i)
		if (vis[i]) cout << ans[i] << endl;
		else cout << ap.first << endl;
	return 0;
}