#include<bits/stdc++.h>
using namespace std;
#define int long long
signed main(){
	int n,ans=0,tmp;
	cin>>n; tmp=n/3;
	//110110110110
	ans=tmp*(tmp-1);
	ans+=tmp*(n%3);
	ans+=tmp*(tmp+1)/2*3-tmp;
	cout<<ans<<endl;
	return 0;
} 