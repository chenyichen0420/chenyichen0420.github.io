#include<bits/stdc++.h>
using namespace std;
#define int long long
#ifdef _WIN32
#define getchar_unlocked getchar
#define putchar_unlocked putchar
#endif
inline int read() {
	int r = 0, s = 1; char c = getchar_unlocked();
	while (c < '0' || c > '9') { if (c == '-') s = -1; c = getchar_unlocked(); }
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar_unlocked();
	return r * s;
}
inline void write(int x) {
	if (x > 9) write(x / 10);
	putchar_unlocked(x % 10 + '0');
	return;
}
inline void writi(int args) {
	if (args < 0) args = ~args + 1, putchar_unlocked('-');
	write(args); putchar_unlocked(10);
}
struct vecor {
	int x, y;
	vecor(const int& l = 0, const int& r = 0) :x(l), y(r) {}
	friend vecor operator+(const vecor& l, const vecor& r) {
		return vecor(l.x + r.x, l.y + r.y);
	}
	friend vecor operator-(const vecor& l, const vecor& r) {
		return vecor(l.x - r.x, l.y - r.y);
	}
	friend int operator*(const vecor& l, const vecor& r) {
		return (l.x * r.y - l.y * r.x);
	}
	inline bool operator==(const vecor& v) {
		return x == v.x && y == v.y;
	}
}sp; vector<vecor>tp, anp;
int t, n, st[1000005], l, r, pt, ans; bitset<1000008>vis;
inline bool covcmp(const vecor& l, const vecor& r) {
	return (l.x != r.x ? l.x < r.x : l.y < r.y);
}
inline void convex(vector<vecor>in) {
	l = in.size(); st[pt = 1] = 0; vis.reset();
	sort(in.begin(), in.end(), covcmp);
	for (int i = 1; i < l; ++i) {
		while (pt > 1 && (in[st[pt]] - in[st[pt - 1]]) * (in[i] - in[st[pt]]) <= 0)
			vis[st[pt]] = 0, pt--;
		vis[i] = 1; st[++pt] = i;
	} r = pt;
	for (int i = l - 2; i >= 0; i--)
		if (!vis[i]) {
			while (pt > r && (in[st[pt]] - in[st[pt - 1]]) * (in[i] - in[st[pt]]) <= 0)
				vis[st[pt]] = 0, pt--;
			vis[i] = 1; st[++pt] = i;
		}
	sp = sp + in[st[1]];
	for (int i = 2; i <= pt; ++i)
		anp.emplace_back(in[st[i]] - in[st[i - 1]]);
}
inline bool fis(const vecor& p) {
	return (p.x > 0 || (p.x == 0 && p.y > 0));
}
inline bool mikcmp(const vecor& l, const vecor& r) {
	int tl = fis(l), tr = fis(r);
	if (tl != tr) return tl;
	return l * r > 0;
}
inline int dis(const vecor& p) {
	return p.x * p.x + p.y * p.y;
}
signed main() {
	t = read();
	while (t--) {
		n = read(); tp.clear();
		for (int i = 1; i <= n; ++i)
			l = read(), r = read(), tp.emplace_back(vecor(l, r));
		convex(tp);
	}
	sort(anp.begin(), anp.end(), mikcmp);
	for (int i = 0; i < anp.size(); ++i)
		ans = max(ans, dis(sp)),
		sp = sp + anp[i];
	writi(ans);
}
//私は猫です