#include<bits/stdc++.h>
using namespace std;
int n,t,a[16],mdep,tmp[6][16],l,r; bool flg;
inline static int gj(){
	int tot=0;
	for(int i=1;i<n;++i) tot+=(a[i]+1!=a[i+1]);
	return (tot+2)/3;
}    
void dfs(int dep){
	if(flg) return;
	if(!gj()){
		cout<<dep<<endl;
		flg=1; return;
	}
	if(dep+gj()>mdep) return; 
	for(int len=1;len<n;++len)
		for(int i=1;i+len-1<=n;++i){
			int j=i+len-1;
			for(int k=j+1;k<=n;++k){
				memcpy(tmp[dep],a,sizeof a);
				for(l=j+1,r=i;l<=k;l++,r++) a[r]=tmp[dep][l];
				for(l=i;l<=j;++l,++r) a[r]=tmp[dep][l];
				dfs(dep+1); if(flg) return;
				memcpy(a,tmp[dep],sizeof a);
			}
		}
	return;
}
int main(){
	ios::sync_with_stdio(false);
	cin>>t;
	while(t--){
		cin>>n; mdep=0; flg=0;
		for(int i=1;i<=n;++i) cin>>a[i];
		for(mdep=gj();mdep<=5;++mdep){
			if(mdep>=5){
				cout<<"5 or more\n";
				break;
			}
			dfs(0); if(flg) break;
		}
	}
	return 0;
}