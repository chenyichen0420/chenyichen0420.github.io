#include<bits/stdc++.h>
using namespace std;
#define int long long
const bool online=0;
int n,dis,p[100005],a[100005],b[100005],ans,pos=1,miv,dist;
signed main(){
	if(online)
		freopen("road.in","r",stdin),
		freopen("road.out","w",stdout);
	ios::sync_with_stdio(0);
	cin>>n>>dis;
	for(int i=2;i<=n;++i) cin>>p[i];
	for(int i=1;i<=n;++i) a[i]=a[i-1]+p[i];
	for(int i=1;i<=n;++i) cin>>b[i];
	while(pos<n){
		for(miv=pos;miv<n;++miv)
			if(b[miv]<b[pos]) break;
		int tmpdis=a[miv]-a[pos];
		if(dist<tmpdis) 
			ans+=ceil((tmpdis-dist)*1.0/dis)*b[pos],
			dist+=ceil((tmpdis-dist)*1.0/dis)*dis;
		dist-=tmpdis; pos=miv;
	}
	cout<<ans<<endl;
	return 0;
}