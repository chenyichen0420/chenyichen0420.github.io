#include<bits/stdc++.h>
using namespace std;
int n, a[2000005], b[2000005], tim, pos;
int main() {
	ios::sync_with_stdio(0);
	cin >> n;
	for (int i = 1; i <= n; ++i) cin >> a[i];
	for (int i = 1; i <= n; ++i) {
		tim = n - i + 1; pos = i;
		a[i] ^= (tim & 1);
		pos += tim / 2;
		if (tim & 1) pos -= (i - 1);
		b[pos] = a[i];
	}
	for (int i = 1; i <= n; ++i) cout << b[i] << " ";
	return 0;
}