#include<bits/stdc++.h>
using namespace std;
int n,a[305],k,x,y,tmp; vector<int>pf[305];
int dfs(int i){
	if(a[i]){
		a[i]--;
		return 1;
	}
	if(pf[i].size()==0){
		if(a[i]>=1){
			a[i]--;
			return 1;
		}
		return 0;
	}
	int flag=1;
	for(int j=0;j<pf[i].size();++j)
		if(!dfs(pf[i][j])) return 0;
	return 1;
}
int main(){
	scanf("%d",&n);
	for(int i=1;i<=n;++i) scanf("%d",&a[i]);
	scanf("%d",&k);
	for(int i=1;i<=k;++i){
		scanf("%d%d",&x,&y);
		for(int j=1;j<=y;++j)
			scanf("%d",&tmp),pf[x].push_back(tmp);
	}
	int ans=0;
	while(dfs(n)) ans++;
	cout<<ans<<endl;
	return 0;
}