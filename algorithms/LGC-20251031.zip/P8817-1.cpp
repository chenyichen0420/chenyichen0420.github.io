#include <bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online = 0;
struct node {
	int p, v;
	node(int pi = 0, int vi = 0) :p(pi), v(vi) {}
}tmp; queue<node>pq;
vector<int>son[2505]; bitset<2508>vis;
int n, m, k, dis[2505][2505], v[2505], ans;
inline void getdis(int sp) {
	pq.emplace(node(sp, 0)); vis.reset();
	while (pq.size()) {
		tmp = pq.front(), pq.pop();
		if (vis[tmp.p]) continue;
		vis[tmp.p] = 1; dis[sp][tmp.p] = tmp.v;
		for (int sp : son[tmp.p])
			if (!vis[sp]) pq.emplace(node(sp, tmp.v + 1));
	}
}
int mx[5][2505];
inline void solve(int p) {
	for (int i = 2; i <= n; ++i)
		if (i != p && dis[1][i] <= k && dis[i][p] <= k)
			if (v[i] > v[mx[1][p]]) mx[4][p] = mx[3][p], mx[3][p] = mx[2][p], mx[2][p] = mx[1][p], mx[1][p] = i;
			else if (v[i] > v[mx[2][p]]) mx[4][p] = mx[3][p], mx[3][p] = mx[2][p], mx[2][p] = i;
			else if (v[i] > v[mx[3][p]]) mx[4][p] = mx[3][p], mx[3][p] = i;
			else if (v[i] > v[mx[4][p]]) mx[4][p] = i;
}
inline bool check(int a, int b, int c, int d) {
	if (a == b || a == c || a == d || b == c || b == d || c == d) return 0;
	if (!a || !b || !c || !d) return 0; return 1;
}
signed main() {
	if (online)
		freopen("holiday.in", "r", stdin),
		freopen("holiday.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin >> n >> m >> k; k++; memset(dis, 0x3f, sizeof dis);
	for (int i = 2; i <= n; ++i) cin >> v[i];
	for (int i = 1, l, r; i <= m; ++i)
		cin >> l >> r,
		son[l].emplace_back(r),
		son[r].emplace_back(l);
	for (int i = 1; i <= n; ++i) getdis(i);
	for (int i = 1; i <= n; ++i) solve(i);
	for (int i = 2; i <= n; ++i)
		for (int j = 2; j <= n; ++j)
			if (i != j && dis[i][j] <= k)
				for (int pi = 1; pi <= 4; ++pi)
					for (int pj = 1; pj <= 4; ++pj)
						if (check(i, j, mx[pi][i], mx[pj][j]))
							ans = max(ans, v[i] + v[j] + v[mx[pi][i]] + v[mx[pj][j]]);
	cout << ans << endl;
}