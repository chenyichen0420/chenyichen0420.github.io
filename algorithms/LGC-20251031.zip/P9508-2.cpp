#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin>>n;
    if(n%3==1){
        for(int i=1;i<=n;++i
        ){
            if(i%3==1){
                cout<<i/3+1;
            }
            else cout<<0;
            cout<<' ';
        }
        return 0;
    }
    for(int i=1;i<=n;++i){
        if(i%3==2){
            cout<<i/3+1;
        }
        else cout<<0;
        cout<<' ';
        
    }
    cout<<endl;
    return 0;
}