#include<bits/stdc++.h>
using namespace std;
int n,s,t,cl,cr,l[1005],r[1005]; char x; 
int main(){
	cin>>n;
	for (int i=1;i<=n;i++){
		cin>>x>>t;
		if (x=='L')l[++cl]=t;
		else r[++cr]=t;
	}
	s=n-1;
	sort(l+1,l+cl+1);
	sort(r+1,r+cr+1);
	for(int i=1;i<=cl;i++)
		for (int j=1;j<=cr;j++)
			if(r[j]<=l[i])s = min(s,cr-j+i-1);
	printf ("%d\n",s);
	return 0;
}