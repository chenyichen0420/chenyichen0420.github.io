#include<string>
int Alice(std::string S) {
	long long ret = 0;
	for (int i = 1;i <= S.size();++i)
		if (S[i - 1] ^ 48) ret ^= i;
	return ret;
}
int Bob(std::string T, int x) {
	long long ret = 0;
	for (int i = 1;i <= T.size();++i)
		if (T[i - 1] ^ 48) ret ^= i;
	return x ^ ret;
}