#include<bits/stdc++.h>
using namespace std;
#define int long long
int n, p, q, r, a[100005], ans, sm, sa[100005], v[100005], sv[100005];
inline int fnd(int v) {
	int l = 1, r = n + 1, mid;
	while (l != r)
		if (sa[mid = l + r + 1 >> 1] >= v) l = mid;
		else r = mid - 1;
	return l;
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> p >> q >> r;
	for (int i = 1; i <= n; ++i) cin >> a[i], sm += a[i];
	sort(a + 1, a + n + 1); if (sm >= 0) return cout << "0\n", 0;
	//结论1：起点不重要，总和>0 即可。选前缀和最小为起点。
	//结论2：交换操作无效
	//结论3：只删除负数，删够为止
	//特殊处理全负数
	if (a[n] >= 0) {
		while (a[n] >= 0 && n > 0) n--; sm = -sm;
		for (int i = 1; i <= n; ++i) a[i] = -a[i];
		for (int i = 1; i <= n; ++i) {
			int nd = min(sm, a[i]);
			ans += min(nd * p, q);
			if ((sm -= nd) <= 0) break;
		}
	}
	else {
		for (int i = 1; i != n; ++i) ans += min(-p * a[i], q);
		ans += -a[n] * p;
	}
	cout << ans << endl;
}