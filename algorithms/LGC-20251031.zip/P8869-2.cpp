#include<iostream>
using namespace std;
int main() {
	long long a, b; cin >> a>> b;
	if (b > 0ll) cout << abs(a) << endl;
	else cout << -abs(a) << endl;
	return 0;
}