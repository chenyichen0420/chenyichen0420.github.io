#include<bits/stdc++.h>
using namespace std;
int n, a[1000005], t[1000005], cnt;
vector<int>ps[1000005], cal; long long ans;
signed main() {
	ios::sync_with_stdio(0);
	cin >> n;
	for (int i = 1; i <= n; ++i)
		cin >> a[i], ps[a[i]].emplace_back(i);
	for (int i = 1; i <= n; ++i)
		if (ps[i].size() > 1)
			cal.emplace_back(ps[i][ps[i].size() - 2]);
	sort(cal.begin(), cal.end());
	for (int i = 0, j = 1; i != cal.size(); ++i) {
		for (; j != cal[i];++j) if (!t[a[j]]++) cnt++;
		ans += cnt; if (t[a[cal[i]]]) ans--;
	}
	cout << ans << endl;
}