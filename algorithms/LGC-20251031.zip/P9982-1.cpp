#include<bits/stdc++.h>
using namespace std;
#define int long long
int n, x[200005], m, a, b, dl[1000005], dr[1000005], l, r, mid, anv;
inline bool get(int p) {
	int vad = (dl[p + 1] - dl[p]) * a;
	int vdc = (dr[p] - dr[p + 1]) * b;
	return vad - vdc >= 0;
}
inline int ans(int p) {
	return dl[p] * a + dr[p] * b;
}
signed main() {
	ios::sync_with_stdio(0); cin >> n;
	for (int i = 1; i <= n; ++i) cin >> x[i];
	sort(x + 1, x + n + 1);
	for (int i = 0, cl = 0; i <= 1e6; ++i) {
		if (i)dl[i] = dl[i - 1] + cl;
		while (x[cl + 1] == i) cl++;
	}
	for (int i = 1e6, cr = 0; i >= 0; --i) {
		dr[i] = dr[i + 1] + cr;
		while (x[n - cr] == i) cr++;
	}
	//a->b(a<b)，增加了 (dl[b]-dl[a])*a，减少了(dr[a]-dr[b])*b
	cin >> m;
	for (int i = 1; i <= m; ++i) {
		cin >> a >> b; anv = 2e18;
		l = 0, r = 1e6 - 1;
		while (l != r)
			if (get(mid = l + r >> 1))r = mid;
			else l = mid + 1;
		for (int i = -1; i <= 1; ++i)
			if (l + i >= 0 && l + i <= 1e6)
				anv = min(anv, ans(i + l));
		cout << anv << endl;
	}
}