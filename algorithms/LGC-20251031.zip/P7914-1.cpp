#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr int mod = 1e9 + 7;
int n, m, dp[505][505][6]; char s[505];
inline bool peek(const char& c, const char& any) { return c == any || c == '?'; }
inline void mad(int& l, const int& r) { if ((l += r % mod) >= mod)l -= mod; }
signed main() {
    ios::sync_with_stdio(0); cin >> n >> m >> (s + 1);
    for (int i = 1; i <= n; ++i) dp[i][i - 1][0] = 1;
#define r (l + ln - 1)
    for (int ln = 1; ln <= n; ++ln)
        for (int l = 1; r <= n; ++l) {
            if (ln <= m) dp[l][r][0] = peek(s[r], '*') && dp[l][r - 1][0];
            if (ln > 1) {
                if (peek(s[l], '(') && peek(s[r], ')')) 
                    dp[l][r][1] = (dp[l + 1][r - 1][0] + dp[l + 1][r - 1][2] + dp[l + 1][r - 1][3] + dp[l + 1][r - 1][4]) % mod;
                for (int i = l; i < r; ++i)
                    mad(dp[l][r][2], dp[l][i][3] * dp[i + 1][r][0]),
                    mad(dp[l][r][3], (dp[l][i][2] + dp[l][i][3]) * dp[i + 1][r][1]),
                    mad(dp[l][r][4], (dp[l][i][4] + dp[l][i][5]) * dp[i + 1][r][1]),
                    mad(dp[l][r][5], dp[l][i][4] * dp[i + 1][r][0]);
            }
            mad(dp[l][r][5], dp[l][r][0]); mad(dp[l][r][3], dp[l][r][1]);
        }
    cout << dp[1][n][3] << endl;;
}