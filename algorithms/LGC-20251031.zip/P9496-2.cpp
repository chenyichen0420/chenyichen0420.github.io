#include<bits/stdc++.h>
using namespace std;
bitset<80>a,b;
int main(){
    long long aa,bb;
    bool ah,bh; int t;
    cin>>t;
    while(t--){
    cin>>aa>>bb;a.reset();b.reset();
    a=aa,b=bb;ah=bh=0;
    for(int i=0;i<=70;++i){
        if(a[i]&&!b[i])ah=1;
        if(!a[i]&&b[i])bh=1;
    }
    cout<<ah+bh<<endl;
    }
}