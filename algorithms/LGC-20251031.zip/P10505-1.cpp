#include<bits/stdc++.h>
using namespace std;
#define int long long
int n, m, a[1005], b[1005], l, r, mid, t[1005], cc;
signed main() {
	ios::sync_with_stdio(0); 
	while (cin >> n >> m, n + m) {
		for (int i = 1; i <= n; ++i) cin >> a[i];
		for (int i = 1; i <= n; ++i) cin >> b[i];
		l = 0, r = 1000;
		while (r != l) {
			mid = l + r + 1 >> 1;
			for (int j = 1; j <= n; ++j) 
				t[j] = a[j] * 1000 - b[j] * mid;
			sort(t + 1, t + n + 1); cc = 0;
			reverse(t + 1, t + n + 1);
			for (int i = 1; i + m <= n; ++i) cc += t[i];
			if (cc >= 0) l = mid;
			else r = mid - 1;
		}
		cout << (l + 5) / 10 << endl;
	}
}