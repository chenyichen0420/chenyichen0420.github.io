#include<iostream>
#include<vector>
#include<string>
#include<map>
#include<sstream>
using namespace std;
bool check(string s) {
	long long a, b, c, d, port;
	if (sscanf(s.c_str(), "%lld.%lld.%lld.%lld:%lld", &a, &b, &c, &d, &port) != 5)  return false;
	if (a < 0 || a > 255 || b < 0 || b > 255 || c < 0 || c > 255 || d < 0 || d > 255 || port < 0 || port > 65535)  return false;
	stringstream ss;
	ss << a << '.' << b << '.' << c << '.' << d << ':' << port;
	return ss.str() == s;
}
string numtstr(int n) {
	int s = n, k; string str;
	while (s > 0) {
		k = s % 10;
		s /= 10;
		if (k == 0) str = "0" + str;
		if (k == 1) str = "1" + str;
		if (k == 2) str = "2" + str;
		if (k == 3) str = "3" + str;
		if (k == 4) str = "4" + str;
		if (k == 5) str = "5" + str;
		if (k == 6) str = "6" + str;
		if (k == 7) str = "7" + str;
		if (k == 8) str = "8" + str;
		if (k == 9) str = "9" + str;
	}
	str += "\n";
	return str;
}
int main() {
	ios::sync_with_stdio(false);
	int n; cin >> n; vector<string> kind(n + 1); vector<string> pos(n + 1); map<string, bool>s; map<string, int>p;
	for (int i = 1; i <= n; ++i) {
		cin >> kind[i] >> pos[i];
		if (check(pos[i]) == false) {
			cout<<"ERR\n";
			continue;
		}
		if (kind[i] == "Server") {
			if (s[pos[i]] == false) s[pos[i]] = true, p[pos[i]] = i, cout<<"OK\n";
			else {
				cout<< "FAIL\n";
				continue;
			}
		}
		if (kind[i] == "Client") cout << (s[pos[i]] == true ? numtstr(p[pos[i]]) : "FAIL\n");
	}
	return 0;
}