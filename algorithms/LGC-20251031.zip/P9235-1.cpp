#include<bits/stdc++.h>
using namespace std;
#define int long long
#define sopt
struct IO {
#define mxsz (1 << 21)
	char buf[mxsz], * p1, * p2;
	char pbuf[mxsz], * pp; bool acc[128];
	IO() : p1(buf), p2(buf), pp(pbuf) {}
	~IO() { fwrite(pbuf, 1, pp - pbuf, stdout); }
	inline void setacc(const char* c) {
		while (*c) acc[*c++] = 1;
	}
	inline char gc() {
		if (p1 == p2) p2 = (p1 = buf) + fread(buf, 1, mxsz, stdin);
		return p1 == p2 ? ' ' : *p1++;
	}
	inline char getc() {
		char c; while (!acc[c = gc()]); return c;
	}
#ifndef sipt
	inline int read() {
		int r = 0; char c = gc(); while (c < '0' || c>'9') c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return r;
	}
#else
	inline int read() {
		int r = 0; char c = gc(); bool rev = 0;
		while (c < '0' || c>'9') rev |= (c == '-'), c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return rev ? ~r + 1 : r;
	}
#endif
	inline void push(const char& c) {
		if (pp - pbuf == mxsz) fwrite(pbuf, 1, mxsz, stdout), pp = pbuf;
		*pp++ = c;
	}
	inline void write(int x) {
		static char sta[22]; int top = 0;
		do sta[top++] = x % 10, x /= 10; while (x);
		while (top) push(sta[--top] ^ 48);
	}
	inline void write(int x, char opc) {
#ifdef sopt
		if (x < 0) push('-'), x = ~x + 1;
#endif
		write(x), push(opc);
	}
} io;
struct nod {
	int p, v;
	nod(int pi = 0, int vi = 0) :p(pi), v(vi) {};
};
int n, m, fa[100005][18], d[100005], a[100005], ans, mv[100005][18];
vector<nod>son[100005];
inline void tmin(int& l, const int r) { (l > r) && (l = r); }
inline void dfs(int p, int f) {
	fa[p][0] = f; d[p] = d[f] + 1;
	for (int i = 1; i <= 17; ++i)
		fa[p][i] = fa[fa[p][i - 1]][i - 1],
		mv[p][i] = min(mv[p][i - 1], mv[fa[p][i - 1]][i - 1]);
	for (const nod& sp : son[p])
		if (sp.p != f) mv[sp.p][0] = sp.v, dfs(sp.p, p);
}
inline int lcv(int l, int r) {
	int ret = 1e9;
	if (d[l] < d[r]) swap(l, r);
	for (int i = 17; i >= 0; i--)
		(d[r] <= d[fa[l][i]]) && (tmin(ret, mv[l][i]), l = fa[l][i]);
	if (l == r) return ret < 1e7 ? ret : -1;
	for (int i = 17; i >= 0; i--)
		(fa[l][i] != fa[r][i]) && (
			tmin(ret, mv[l][i]), tmin(ret, mv[r][i]),
			l = fa[l][i], r = fa[r][i]);
	tmin(ret, mv[l][0]); tmin(ret, mv[r][0]);
	return ret < 1e7 ? ret : -1;
}
struct node {
	int l, r, v;
	node(int li = 0, int ri = 0, int vi = 0) :l(li), r(ri), v(vi) {};
	inline bool operator<(const node& r) {
		return v > r.v;
	}
}e[300005];
int k, ff[100005];
inline int find(int p) {
	return ff[p] != p ? ff[p] = find(ff[p]) : p;
}
inline bool merge(int l, int r) {
	l = find(l); r = find(r);
	if (l == r) return 0;
	return ff[l] = r, 1;
}
signed main() {
	ios::sync_with_stdio(0);
	memset(mv, 0x0f, sizeof mv);
	n = io.read(); m = io.read(); k = io.read();
	for (int i = 1; i <= m; ++i)
		e[i].l = io.read(), e[i].r = io.read(), e[i].v = io.read();
	sort(e + 1, e + m + 1);
	for (int i = 1; i <= n; ++i) ff[i] = i;
	for (int i = 1; i <= m; ++i)
		if (merge(e[i].l, e[i].r))
			son[e[i].l].emplace_back(e[i].r, e[i].v),
			son[e[i].r].emplace_back(e[i].l, e[i].v);
	for (int i = 1; i <= n; ++i)
		if (!fa[i][0]) dfs(i, 0);
	for (int i = 1, l, r; i <= k; ++i) {
		l = io.read(), r = io.read();
		if (find(l) != find(r)) io.write(-1, '\n');
		else io.write(lcv(l, r), '\n');
	}
	return 0;
}