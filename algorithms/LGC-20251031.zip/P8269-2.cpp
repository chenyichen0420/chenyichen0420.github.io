#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,rd[100005],x,y,a[100005],v[100005],ans; 
queue<int>q; bool vis[100005];
void dfs(int pl,int &an){
	an=min(an,v[pl]);
	vis[pl]=true;
	if(vis[a[pl]]) return;
	dfs(a[pl],an);
}
signed main(){
	cin>>n;
	for(int i=1;i<=n;++i){
		cin>>a[i]>>v[i];
		rd[a[i]]++;
	}
	for(int i=1;i<=n;++i)
		if(rd[i]==0) q.push(i);
	while(!q.empty()){
		int t=q.front(); q.pop();
		vis[t]=true; rd[a[t]]--; ans+=v[t];
		if(!rd[a[t]]) q.push(a[t]);
	}
	for(int i=1;i<=n;++i){
		if(!vis[i]) ans+=v[i];
	}
	for(int i=1;i<=n;++i)
		if(!vis[i]) {
			int minnum=(1e18+10);dfs(i,minnum);
			ans-=minnum;
		}	
	cout<<ans<<endl;
	return 0;
}