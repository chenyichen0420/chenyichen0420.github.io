#include<bits/stdc++.h>
using namespace std;
namespace FastIO {
	char buf[1 << 21], *p1 = buf, *p2 = buf;
#define getchar() (p1 == p2 && (p1 = buf, p2 = (p1 + fread(buf, 1, 1 << 21, stdin))) == p1 ? EOF : *p1++)
	inline int read() { int x = 0, w = 0; char ch = getchar(); while (ch < '0' || ch > '9') w |= (ch == '-'), ch = getchar(); while ('0' <= ch && ch <= '9') x = x * 10 + (ch ^ '0'), ch = getchar(); return w ? -x : x; }
	inline void write(int x) { if (!x) return; write(x / 10), putchar((x % 10) ^ '0'); }
	inline void print(int x) { if (x > 0) write(x); else if (x < 0) putchar('-'), write(-x); else putchar('0'); }
	inline void print(int x, char en) { print(x), putchar(en); }
}; using namespace FastIO;
#undef getchar()
int n,m,q,o,l,r,tmp[4000005];
vector<int>v[25]; bool st[25];
inline void chk(int p){
	if(!st[p]) 
		sort(v[p].begin(),v[p].end()),
		st[p]=1;
}
inline void merge(int l,int r){
	int pl=0,pr=0; chk(l); chk(r);
	if(v[l].back()<=v[r][0]) return;
	if(v[l][0]>=v[r].back()){
		swap(v[l],v[r]); return;
	}
	for(int i=0;i<n<<1;++i){
		if(pl==n) tmp[i]=v[r][pr++];
		else if(pr==n) tmp[i]=v[l][pl++];
		else if(v[l][pl]<v[r][pr]) tmp[i]=v[l][pl++];
		else tmp[i]=v[r][pr++];
	}
	for(int i=0;i<n;++i) v[l][i]=tmp[i];
	for(int i=0;i<n;++i) v[r][i]=tmp[i+n];
}
signed main(){
	n=read(); m=read(); q=read();
	for(int i=1;i<=m;++i)
		for(int j=1;j<=n;++j)
			v[i].emplace_back(read());
	for(int i=1;i<=q;++i){
		o=read(); l=read(); r=read();
		if(o&1) merge(l,r);
		else print(v[l][r-1],'\n');
	}
	return 0;
}