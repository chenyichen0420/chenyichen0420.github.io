#include<bits/stdc++.h>
using namespace std;
const bool online = 0;
int n, m, q, p, s, t;
vector<int>son[1001];
bool rem[1001][1001], chk[1001];
inline void dfs(int pos, int rv) {
	if (rem[rv][pos]) return;
	rem[rv][pos] = 1;
	for (int i = 0; i < son[pos].size(); ++i)
		dfs(son[pos][i], rv);
}
inline int read(){
	register int r=0; register char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') r=(r<<3)+(r<<1)+(c^48),c=getchar();
	return r;
}
int main() {
	if (online)
		freopen("kutije.in", "r", stdin),
		freopen("kutije.out", "w", stdout);
	n=read(); m=read(); q=read();
	for (int i = 1; i <= m; ++i)
		for (int j = 1; j <= n; ++j)
			p=read(), son[p].push_back(j);
	while (q--) {
		s=read(); t=read();
		if (!chk[t]) dfs(t, t);
		if (rem[t][s]) putchar('D'),putchar('A'),putchar('\n');
		else putchar('N'),putchar('E'),putchar('\n');
	}
	return 0;
}