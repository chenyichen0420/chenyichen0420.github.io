#include<bits/stdc++.h>
using namespace std;
#define int long long
vector<int>son[100005];
int n, m, k, v[100005];
int lg[100005], f[100005][20], dp[100005];
int ind[100005], oud[100005], cnt, mv[100005];
inline void dfs(int p, int mx) {
	mv[p] = mx = max(mx, p);
	ind[p] = ++cnt; dp[p] = dp[f[p][0]] + 1;
	for (int i = 1; i <= lg[dp[p]]; ++i)
		f[p][i] = f[f[p][i - 1]][i - 1];
	for (int sp : son[p]) dfs(sp, mx);
	oud[p] = ++cnt;
}
inline bool cmp(const int& l, const int& r) {
	return dp[l] < dp[r];
}
inline int lca(int l, int r) {
	if (dp[l] < dp[r]) swap(l, r);
	for (int i = 18; i >= 0; i--)
		if (dp[f[l][i]] >= dp[r]) l = f[l][i];
	if (l == r) return l;
	for (int i = 18; i >= 0; i--)
		if (f[l][i] != f[r][i]) l = f[l][i], r = f[r][i];
	return f[l][0];
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n; lg[1] = 1;
	for (int i = 1; i < n; ++i)
		cin >> f[i][0], son[f[i][0]].emplace_back(i),
		lg[i] = lg[i - 1] + (1ll << lg[i - 1] == i);
	dfs(0, -1); cin >> m;
	while (m--) {
		cin >> k;
		for (int i = 1; i <= k; ++i) cin >> v[i];
		sort(v + 1, v + k + 1, cmp);
		for (int i = 2; i <= k; ++i)
			if (ind[v[i]] > oud[v[1]] || ind[v[1]] > oud[v[i]])
				v[1] = lca(v[1], v[i]);
		cout << mv[v[1]] << endl;
	}
	return 0;
}