#include<bits/stdc++.h>
using namespace std;
#define int long long
#define sipt //signed-input
#define sopt //signed-output
struct IO {
#define mxsz (1 << 20)
	char buf[mxsz], * p1, * p2;
	char pbuf[mxsz], * pp;
	IO() : p1(buf), p2(buf), pp(pbuf) {}
	~IO() { fwrite(pbuf, 1, pp - pbuf, stdout); }
	inline char gc() {
		if (p1 == p2) p2 = (p1 = buf) + fread(buf, 1, mxsz, stdin);
		return p1 == p2 ? ' ' : *p1++;
	}
#ifndef sipt
	inline int read() {
		int r = 0; char c = gc(); while (c < '0' || c>'9') c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return r;
	}
#else
	inline int read() {
		int r = 0; char c = gc(); bool rev = 0;
		while (c < '0' || c>'9') rev |= (c == '-'), c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return rev ? ~r + 1 : r;
	}
#endif
	inline void push(const char& c) {
		if (pp - pbuf == mxsz) fwrite(pbuf, 1, mxsz, stdout), pp = pbuf;
		*pp++ = c;
	}
	inline void write(int x) {
		static char sta[22]; int top = 0;
		do sta[top++] = x % 10, x /= 10; while (x);
		while (top) push(sta[--top] ^ 48);
	}
	inline void write(int x, char opc) {
#ifdef sopt
		if (x < 0) push('-'), x = ~x + 1;
#endif
		write(x), push(opc);
	}
} io;
int n, m, a[500005];
inline int gcd(int l, int r) {
	return !r ? abs(l) : gcd(r, l % r);
}
struct seg_tree {
	struct node {
		int l, r, s, v;
	}re[500005 << 2];
	inline void pup(int p) {
		re[p].s = re[p << 1].s + re[p << 1 | 1].s;
		re[p].v = gcd(re[p << 1].v, re[p << 1 | 1].v);
	}
	inline void build(int l, int r, int p) {
		re[p].l = l;re[p].r = r;
		if (l == r) {
			re[p].s = re[p].v = a[l];
			return;
		}
		build((l + r >> 1) + 1, r, p << 1 | 1);
		build(l, (l + r >> 1), p << 1); pup(p);
	}
	inline void chg(int cp, int v, int p) {
		if (re[p].l == re[p].r) {
			re[p].v += v; re[p].s += v;
			return;
		}
		if (cp > re[p << 1].r) chg(cp, v, p << 1 | 1);
		else chg(cp, v, p << 1); pup(p);
	}
	inline int que(int l, int r, int p) {
		if (re[p].l >= l && re[p].r <= r) return re[p].v;
		int ret = 0;
		if (l <= re[p << 1].r) ret = gcd(que(l, r, p << 1), ret);
		if (r > re[p << 1].r) ret = gcd(que(l, r, p << 1 | 1), ret);
		return ret;
	}
	inline int qus(int r, int p) {
		if (re[p].r <= r) return re[p].s;
		int ret = qus(r, p << 1);
		if (r > re[p << 1].r) ret += qus(r, p << 1 | 1);
		return ret;
	}
}sgt;
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m;
	for (int i = 1;i <= n;++i) cin >> a[i];
	for (int i = n;i;i--) a[i] -= a[i - 1];
	sgt.build(1, n, 1); char o;
	for (int i = 1, l, r, v;i <= m;++i)
		if (cin >> o, (o) ^ 'C') {
			cin >> l >> r;
			if (l == r) io.write(abs(sgt.qus(l, 1)), '\n');
			else io.write(gcd(sgt.qus(l, 1), sgt.que(l + 1, r, 1)), '\n');
		}
		else {
			cin >> l >> r >> v;
			sgt.chg(l, v, 1);if (r != n) sgt.chg(r + 1, -v, 1);
		}
	return 0;
}