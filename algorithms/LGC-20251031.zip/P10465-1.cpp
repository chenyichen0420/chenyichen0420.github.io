#include<bits/stdc++.h>
using namespace std;
int n, ans, lst = 0x3f3f3f3f; pair<int, int>v[200001]; bool up;
int main() {
	ios::sync_with_stdio(0);
	cin >> n;
	for (int i = 1; i <= n; ++i)
		cin >> v[i].first, v[i].second = i;
	sort(v + 1, v + n + 1);
	for (int i = 1, j = 1; i < n; i = j) {
		while (j < n && v[j].first == v[i].first)j++;
		if (!up) {
			if (lst > v[j - 1].second) lst = v[i].second;
			else lst = v[j - 1].second, up ^= 1;
		}
		else {
			if (lst < v[i].second) lst = v[j - 1].second;
			else lst = v[i].second, up ^= 1, ans++;
		}
	}
	cout << ans + 1 << endl;
	return 0;
}