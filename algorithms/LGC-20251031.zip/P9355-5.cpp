#include<bits/stdc++.h>
using namespace std;
long long t,n,m;
int main(){
	cin>>t;
	while(t--){
		cin>>n>>m;
		cout<<(n-1)*m+(m-1)*n<<endl;
	}
	return 0;
}