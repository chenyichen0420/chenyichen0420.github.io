#include<bits/stdc++.h>
using namespace std;
#define int long long
int arr[18] = { 45,49,445,499,4445,4999,44445,49999,444445,499999,4444445,4999999,44444445,49999999,444444445,499999999,4444444445,4999999999 };
int a[10], b[10], n, v, ans;
signed main() {
	ios::sync_with_stdio(0);
	for (int i = 1; i <= 9; ++i)
		a[i] = arr[(i - 1) * 2],
		b[i] = arr[i * 2 - 1],
		cerr << a[i] << " " << b[i] << endl;
	for (cin >> n; n; n--) {
		cin >> v; ans = 0;
		int ps = upper_bound(a + 1, a + 10, v) - a - 1;
		if (v > b[ps]) {
			for (int i = 1; i <= ps; ++i)
				ans += (b[i] - a[i] + 1);
			cout << ans << endl;
		}
		else {
			for (int i = 1; i < ps; ++i)
				ans += (b[i] - a[i] + 1);
			ans += (v - a[ps] + 1);
			cout << ans << endl;
		}
	}
}