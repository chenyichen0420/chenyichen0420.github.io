#include<bits/stdc++.h>
using namespace std;
#define int long long
int n, a[3005], b[3005], dp[3005][3005], ans;
signed main() {
	ios::sync_with_stdio(0); cin >> n;
	for (int i = 1; i <= n; ++i) cin >> a[i];
	for (int i = 1; i <= n; ++i) cin >> b[i];
	for (int i = 1; i <= n; ++i) {
		int v = 0;
		for (int j = 1; j <= n; ++j) {
			if (a[i] == b[j]) dp[i][j] = v + 1;
			else dp[i][j] = dp[i - 1][j];
			if (b[j] < a[i]) v = max(v, dp[i - 1][j]);
		}
	}
	for (int i = 1; i <= n; ++i) ans = max(ans, dp[n][i]);
	cout << ans << endl;
}