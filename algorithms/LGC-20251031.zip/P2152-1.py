import math
import sys
sys.set_int_max_str_digits(0)
a = int(input())
b = int(input())
print(math.gcd(int(a),int(b)))
