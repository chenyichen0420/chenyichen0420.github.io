#include<bits/stdc++.h>
using namespace std;
const bool online=0;
int t,n,m,cnt; char c1[21][21],c2[21][21]; bool cn[21][21];
inline bool can(int x,int y){
	for(int i=1;i<=m;++i)
		for(int j=1;j<=m;++j)
			if(c1[x+i-1][y+j-1]=='.'&&c2[i][j]=='*')
				return 0;
	return 1;
}
inline bool assign(int x,int y){
	for(int i=1;i<=m;++i)
		for(int j=1;j<=m;++j)
			if(c2[i][j]=='*') cn[x+i-1][y+j-1]=1;
}
inline void reverse(){
	char tmp[21][21];
	for(int i=1;i<=m;++i)
		for(int j=1;j<=m;++j)
			tmp[m-j+1][i]=c2[i][j];
	memcpy(c2,tmp,sizeof c2);
}
int main(){
	if(online)
		freopen("stamp.in","r",stdin),
		freopen("stamp.out","w",stdout);
	ios::sync_with_stdio(0);
	cin>>t;
	while(t--){
		cin>>n;
		for(int i=1;i<=n;++i)
			for(int j=1;j<=n;++j)
				cin>>c1[i][j],cn[i][j]=(c1[i][j]=='.');
		cin>>m;
		for(int i=1;i<=m;++i)
			for(int j=1;j<=m;++j)
				cin>>c2[i][j];
		for(int k=1;k<=4;++k,reverse())
			for(int i=1;i<=n-m+1;++i)
				for(int j=1;j<=n-m+1;++j)
					if(can(i,j)) assign(i,j);
		cnt=0;
		for(int i=1;i<=n;++i)
			for(int j=1;j<=n;++j)
				cnt+=cn[i][j];
		if(cnt==n*n) cout<<"YES\n";
		else cout<<"NO\n";
	}
	return 0;
} 