#include <bits/stdc++.h>
using namespace std;
unsigned long long n,m,p,x,y,z,k,h[1000010],s[1000010];
struct node{
	unsigned long long x,y,z,next;
}d[1000010];
void add(unsigned long long x, unsigned long long y, unsigned long long z){
	d[++p].y=y;
	d[p].z=z;
	d[p].next=h[x];
	h[x]=p;
}
void dfs(unsigned long long a, unsigned long long b){
	for (unsigned long long i=h[a]; i; i=d[i].next){
		unsigned long long to=d[i].y;
		if (to==b) continue;
		s[to]=s[a]^d[i].z;
		dfs(to,a);
	}
}
int main(){
	ios::sync_with_stdio(false);
	cin>>n>>m;
	for(unsigned long long i=1; i<n; i++){
		cin>>x>>y>>z;
		add(x,y,z);
		add(y,x,z);
	}
	dfs(1, 0);
	while(m--){
		cin>>x>>y>>k;
		if((s[x]^s[y])==k)cout<<"yes\n";
		else cout<<"no\n";
	}
	return 0;
}