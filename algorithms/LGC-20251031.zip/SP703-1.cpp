#include<bits/stdc++.h>
using namespace std;
int t, n, m, dp[2][205][205], d[205][205], p[1005], ans;
inline void tmin(int& l, const int r) { (l > r) && (l = r); }
signed main() {
	ios::sync_with_stdio(0);
	for (cin >> t; t; t--)
	{
		cin >> n >> m; p[0] = 3;
		for (int i = 1; i <= n; ++i)
			for (int j = 1; j <= n; ++j)
				cin >> d[i][j];
		for (int i = 1; i <= m; ++i) cin >> p[i];
		memset(dp[0], 0x3f, sizeof dp[0]);
		dp[0][1][2] = 0; ans = dp[0][0][0];
		for (int i = 1; i <= m; ++i) {
			memset(dp[i & 1], 0x3f, sizeof dp[0]);
			for (int j = 1; j <= n; ++j)
				for (int k = 1; k <= n; ++k) {
					if (j == k || j == p[i - 1] || k == p[i - 1]) continue;
					if (p[i] != j && p[i] != k) tmin(dp[i & 1][j][k], dp[i - 1 & 1][j][k] + d[p[i - 1]][p[i]]);
					if (p[i] != k) tmin(dp[i & 1][p[i - 1]][k], dp[i - 1 & 1][j][k] + d[j][p[i]]);
					if (p[i] != j) tmin(dp[i & 1][j][p[i - 1]], dp[i - 1 & 1][j][k] + d[k][p[i]]);
				}
		}
		for (int j = 1; j <= n; ++j)
			for (int k = 1; k <= n; ++k)
				tmin(ans, dp[m & 1][j][k]);
		cout << ans << endl;
	}
}
/*
1
5 12
0 0 0 0 0
0 0 1 1 1
0 1 0 1 1
0 1 1 0 1
0 1 1 1 0
1 1 2 2 3 3 4 5 4 5 4 2
*/