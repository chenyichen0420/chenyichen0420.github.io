#include<iostream>
#include<algorithm>
using namespace std;
int n, q, t[8005], wiq, x, v;
struct node {
	int num, id;
}a[8005];
bool cmp(node x, node y) {
	if (x.num != y.num) return x.num < y.num;
	return x.id < y.id;
}
int main() {
	cin >> n >> q;
	for (int i = 1; i <= n; i++) {
		cin >> a[i].num;
		a[i].id = i;
	}
	sort(a + 1, a + n + 1, cmp);
	for (int i = 1; i <= n; i++)
		t[a[i].id] = i;
	for (int i = 1; i <= q; i++) {
		cin >> wiq;
		if (wiq == 1) {
			cin >> x >> v;
			a[t[x]].num = v;
			for (int j = n; j >= 2; j--)
				if (cmp(a[j], a[j - 1]))
					swap(a[j], a[j - 1]);
			for (int j = 2; j <= n; j++)
				if (cmp(a[j], a[j - 1])) {
					swap(a[j], a[j - 1]);
				}
			for (int i = 1; i <= n; i++)
				t[a[i].id] = i;
		}
		else {
			cin >> x;
			cout << t[x] << endl;
		}
	}
	return 0;
}