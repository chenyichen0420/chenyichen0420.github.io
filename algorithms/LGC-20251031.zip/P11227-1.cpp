#include<bits/stdc++.h>
using namespace std;
int n; set<string>st; string s;
int main() {
	ios::sync_with_stdio(0);
	cin >> n;
	for (int i = 1; i <= n; ++i)
		cin >> s, st.emplace(s);
	cout << 52 - st.size() << endl;
}