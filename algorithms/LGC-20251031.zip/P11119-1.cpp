#include<bits/stdc++.h>
using namespace std;
constexpr bool online=0;
#define int long long
int n,m,a[1000005],lt[1000005],rt[1000005],f[1000005],g[1000005],ans,s;
inline void tmin(int&l,const int r){(l>r)&&(l=r);}
inline void tmax(int&l,const int r){(l<r)&&(l=r);}
struct tree_array{
    int v[1000005];
    inline void ins(int p,int t){
        do v[p]+=t; while((p+=p&~p+1)<=n+1);
    }
    inline int que(int p){
        int t=0; do t+=v[p]; while(p&=p-1); return t;
    }
}ta1,ta2;
signed main(){
    if(online)
        freopen("network.in","r",stdin),
        freopen("network.out","w",stdout);
    ios::sync_with_stdio(0); cin>>n>>m;
    for(int i=1;i<=n;++i) lt[i]=rt[i]=i;
    for(int i=1;i<=n;++i){
        cin>>a[i];
        int l=max(1ll,i-a[i]);
        int r=min(n,i+a[i]);
        tmax(lt[l],r); tmin(rt[r],l);
    }
    for(int i=2;i<=n;++i) tmax(lt[i],lt[i-1]);
    for(int i=n-1;i>=1;i--) tmin(rt[i],rt[i+1]);
    for(int i=n-1;i>=1;i--) g[i]=n-lt[i]+g[lt[i]+1];
    for(int i=1;i<=n;++i) f[lt[i]+1]+=++f[i];
    for(int i=1;i<=n;++i) ans+=g[i],s+=g[i];
    for(int i=1;i<=n;++i) ta1.ins(i,g[i]),ta2.ins(i,1);
    for(int i=1;i<=n;++i){
        int p=(i+m<=n?rt[i+m]-1:n),r=min(i+m,n);
        int l=max(i-m-1,0ll);
        if(l&&lt[l]<n){
            ta1.ins(lt[l]+1,f[l]*g[lt[l]+1]);
            ta2.ins(lt[l]+1,f[l]);
        }
        if(m<=a[i] || p<l) continue;
        tmin(ans,s-ta1.que(p)+ta1.que(l)+(ta2.que(p)-ta2.que(l))*(n-r+g[r+1]));
    }
    cout<<ans<<endl;
    return 0;
}
