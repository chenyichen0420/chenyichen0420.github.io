#include<bits/stdc++.h>
using namespace std;
#define no_cost_flow
constexpr bool double_side = 1;
int n, m, s, t, ans, mic;
#ifdef no_cost_flow
struct dinic {
	struct node { int p, v; }tmp;
	vector<node>e; vector<int>h[1005];
	inline void ins(int l, int r, int v) {
		h[l].emplace_back(e.size());
		tmp.p = r; tmp.v = v;
		e.emplace_back(tmp);
		h[r].emplace_back(e.size());
		tmp.p = l; tmp.v = v * double_side;
		e.emplace_back(tmp);
	}
	int d[1005]; bool vis[1005];
	inline bool bfs() {
		memset(vis, 0, sizeof vis);
		queue<int>q; q.emplace(s); vis[s] = 1;
		while (q.size()) {
			int tp = q.front(); q.pop();
			for (int i : h[tp]) {
				const node& sp = e[i];
				if (sp.v && !vis[sp.p])
					d[sp.p] = d[tp] + 1, 
					vis[sp.p] = 1, q.emplace(sp.p);
			}
		}
		return vis[t];
	}
	int hp[1005];
	inline int dfs(int p, int f) {
		if (p == t || !f) return f; int ret = 0, tv;
		for (int& i = hp[p]; i != h[p].size(); ++i) {
			node& sp = e[h[p][i]];
			if ((d[sp.p] == d[p] + 1) && (tv = dfs(sp.p, min(sp.v, f)))) {
				e[h[p][i] ^ 1].v += tv; ret += tv; sp.v -= tv;
				if (!(f -= tv)) return ret;
			}
		}
		return ret;
	}
	inline int mxf() {
		ans = 0;
		while (bfs())
			memset(hp, 0, sizeof hp),
			ans += dfs(s, 2e9);
		return ans;
	}
	inline void clear() {
		e.clear(); for (int i = 0; i <= t + 2; ++i) h[i].clear();
	}
}din;
#else

#endif //2025/06/04 重写版
char c; int a[25][25], vl[25], vr[25], mx;
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m >> s >> t;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			cin >> c, a[i][j] = c ^ 48;
	fill(vl + 1, vl + n + 1, -s);
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			vl[i] += a[i][j];
	fill(vr + 1, vr + m + 1, -t);
	for (int i = 1; i <= m; i++)
		for (int j = 1; j <= n; j++)
			if (vl[j] > 0) vr[i] += a[j][i];
	for (int i = 1; i <= m; i++)
		if (vr[i] > 0 && (mx += vr[i]))
			for (int j = 1; j <= n; j++)
				if (a[j][i] && vl[j] > 0)
					mx -= s, vl[j] = 0;
	cout << max(mx, 0) << endl;
}