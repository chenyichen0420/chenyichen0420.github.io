#include<bits/stdc++.h>
using  namespace std;
int n, m, a[1000005], np, ans, hs[1000005], b[1000005];
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m;
	for (int i = 1; i <= n; ++i) cin >> a[i];
	if (!m) {
		for (int i = 1; i <= n; ++i) if (a[i]) ans++;
		cout << ans << endl;
		for (int i = 1; i <= n; ++i) cout << "0 ";
		return 0;
	}
	memcpy(b, a, sizeof a);
	if (m <= n + 1)
		for (int i = 1, lp = 0; i <= n; ++i) {
			if (a[i] <= m) hs[a[i]]++;
			if (a[i] == m) {
				while (lp != i) if (a[++lp] <= m) hs[a[lp]]--;
				np = 0; continue;
			}
			while (hs[np]) np++;
			if (np == m) {
				ans++; np = 0; b[i] = m;
				while (lp != i) if (a[++lp] <= m) hs[a[lp]]--;
			}
		}
	cout << ans << endl;
	for (int i = 1; i <= n; ++i) cout << b[i] << " ";
	return 0;
}