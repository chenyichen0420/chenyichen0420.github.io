#include<bits/stdc++.h> 
using namespace std;
int n,a,t[500005],ans;
int main(){
    ios::sync_with_stdio(0);
    cin>>n;
    for(int i=1;i<=n;++i)
    	cin>>a, t[a]++;
    sort(t+1,t+n+1); reverse(t+1,t+n+1);
    while(!t[n]) n--;
    for(int l=1,r=n;l<=r;++l){
    	int tmp=t[l]-1; ans++;
    	while(r>l&&tmp>=t[r]) tmp-=t[r],r--;
    	if(r>l) t[r]-=tmp;
	}
	cout<<ans<<endl;
	return 0;
}