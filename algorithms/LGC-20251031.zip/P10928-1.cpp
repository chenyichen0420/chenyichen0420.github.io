#include<bits/stdc++.h>
using namespace std;
struct node {
	int l, r, v;
	node(int li = 0, int ri = 0, int vi = 0) :l(li), r(ri), v(vi) {};
}; vector<node>e;
int t, n, l, r, v, fa[6005], siz[6005], ans;
inline int find(const int& p) {
	return (fa[p] != p ? fa[p] = find(fa[p]) : p);
}
int main() {
	ios::sync_with_stdio(0);
	cin >> t;
	while (t--) {
		cin >> n; e.clear(); ans = 0;
		for (int i = 1; i < n; ++i)
			cin >> l >> r >> v,
			e.emplace_back(node(l, r, v));
		for (int i = 1; i <= n; ++i) fa[i] = i, siz[i] = 1;
		sort(e.begin(), e.end(), [&](const node& l, const node& r) {
			return l.v < r.v;
		});
		for (int i = 0; i < n - 1; ++i) {
			int fl = find(e[i].l), fr = find(e[i].r);
			ans += (siz[fl] * siz[fr] - 1) * (e[i].v + 1);
			fa[fl] = fr; siz[fr] += siz[fl];
		}
		cout << ans << endl;
	}
	return 0;
}