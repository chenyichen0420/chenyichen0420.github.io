#include<bits/stdc++.h>
using namespace std;
#define int long long
int n, m, d[30005], tmp; bool vis[30005];
struct node {
	int p, v;
	node(int pi = 0, int vi = 0) :p(pi), v(vi) {};
}; vector<node>son[30005]; queue<int>q;
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m;
	for (int i = 1, l, r, v; i <= m; ++i)
		cin >> l >> r >> v, son[l - 1].emplace_back(r, v);
	for (int i = 0; i != n; ++i) son[i].emplace_back(i + 1, 0);
	for (int i = 1; i <= n; ++i) son[i].emplace_back(i - 1, -1);
	memset(d, 0xcf, sizeof d);
	q.emplace(d[0] = 0);
	while (q.size()) {
		tmp = q.front(); q.pop(); vis[tmp] = 0;
		for (const node& sp : son[tmp])
			if (d[sp.p] < d[tmp] + sp.v)
				if (d[sp.p] = d[tmp] + sp.v, !vis[sp.p])
					q.emplace(sp.p);
	}
	cout << d[n] << endl;
}