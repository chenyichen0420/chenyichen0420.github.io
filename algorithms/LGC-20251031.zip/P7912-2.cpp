#include<bits/stdc++.h> 
using namespace std;
struct node{
	int st,ed,then;
}f,x,add;
int n,cnt,t[200002]; queue<node>q1,q2; bool used[200001];
int main(){
	scanf("%d",&n);
	for (int i=1;i<=n;i++) scanf("%d",t+i);
	t[n+1]=!t[n];
	for (int i=2,si=1;i<=n+1;i++)
		if (t[i]!=t[i-1]) q1.push((node){si,i-1,t[i-1]}),si=i;
	while(cnt<n){
		while(!q1.empty()){
			f=q1.front(); q1.pop();
			while(used[f.st]&&f.st<=f.ed)f.st++;
			if (f.st>f.ed) continue;
			printf("%d ",f.st),cnt++;
			used[f.st]=1;
			if (f.ed==f.st) continue;
			f.st++; q2.push(f);
		}
		cout<<endl;
		while (q2.size()){
			add=q2.front(); q2.pop();
			while(!q2.empty()){
				x=q2.front();
				if(x.then==add.then) add.ed=x.ed,q2.pop();
				else break;
			}
			q1.push(add);
		}
	}
	return 0;
}