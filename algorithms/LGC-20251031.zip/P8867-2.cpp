#include<bits/stdc++.h>
#include<unordered_set>
using namespace std;
#define int long long
constexpr int mod = 1e9 + 7;
inline void tmin(int& l, const int& r) {
	(l > r) && (l = r);
}
inline int qpow(int a, int b, const int& p = mod) {
	if (b == 0) return 1;
	int tmp = 1;
	while (b) {
		if (b & 1) tmp *= a, tmp %= p;
		a *= a; a %= p; b >>= 1;
	}
	return tmp;
}
inline int read() {
	int r = 0; char c = getchar();
	while (c < '0' || c>'9') c = getchar();
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar();
	return r;
}
//full use, functional up
unordered_set<long long>s; vector<int>son[500005], nsn[500005];
int n, m, dfn[500005], low[500005], cntt, ans;
int isc[500005], sct, nc[500005], ec[500005];
#define sp son[p][i]
#define node(i,j) (i * (n + 1) + j)
inline void tarjan(const int& p, const int& f) {
	dfn[p] = low[p] = ++cntt;
	for (int i = 0; i != son[p].size(); ++i)
		if (!dfn[sp]) {
			tarjan(sp, p), tmin(low[p], low[sp]);
			if (low[sp] > dfn[p]) s.insert(node(sp, p));
		}
		else if (sp != f) tmin(low[p], dfn[sp]);
}
inline void dfs(const int& p) {
	isc[p] = sct; nc[sct]++;
	for (int i = 0; i != son[p].size(); ++i)
		if (!isc[sp] && !s.count(node(p, sp)) && !s.count(node(sp, p))) dfs(sp);
}
int dp[500005][2], sme[500005];
inline void adde() {
	tarjan(1, 0);
	for (int i = 1; i <= n; ++i)
		if (!isc[i]) sct++, dfs(i);
	for (int p = 1; p <= n; ++p)
		for (int i = 0; i != son[p].size(); ++i)
			if (isc[p] != isc[sp]) nsn[isc[p]].emplace_back(isc[sp]);
			else ec[isc[p]]++;
	for (int i = 1; i <= sct; ++i)
		ec[i] >>= 1, dp[i][0] = qpow(2, ec[i]),
		dp[i][1] = (qpow(2, ec[i] + nc[i]) - dp[i][0] + mod) % mod;
}
#undef sp
#define sp nsn[p][i]
inline void gsme(const int& p, const int& fa) {
	sme[p] = ec[p];
	for (int i = 0; i != nsn[p].size(); ++i)
		if (sp != fa) gsme(sp, p), sme[p] += sme[sp] + 1;
}
inline void dps(const int& p, const int& fa) {
	for (int i = 0; i != nsn[p].size(); ++i) {
		if (sp == fa) continue; dps(sp, p);
		dp[p][1] = (dp[p][1] * ((dp[sp][0] * 2 + dp[sp][1]) % mod) % mod + dp[p][0] * dp[sp][1] % mod) % mod;
		(dp[p][0] *= dp[sp][0] * 2 % mod) %= mod;
	}
	if (fa) (ans += dp[p][1] * qpow(2, sme[1] - sme[p] - 1) % mod) %= mod;
	else (ans += dp[1][1]) %= mod;
}
signed main() {
	ios::sync_with_stdio(0);
	n = read(); m = read();
	for (int i = 1, l, r; i <= m; ++i)
		son[l = read()].emplace_back(r = read()),
		son[r].emplace_back(l);
	adde(); gsme(1, 0); dps(1, 0);
	cout << ans << endl;
	return 0;
}