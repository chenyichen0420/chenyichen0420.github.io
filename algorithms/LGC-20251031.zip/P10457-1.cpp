#include<bits/stdc++.h>
using namespace std;
#define p(a,b) make_pair(a,b)
#define fi first
#define se second
#define fr front()
#define bk back()
#define pfr pop_front()
#define pbk pop_back()
list<pair<int,bool> >ls[14]; char c1,c2,c3,c4; int cnt=4,cp[14],tmp;
inline int rev(char c){
	if(c=='A') return 1;
	if(c=='J') return 11;
	if(c=='Q') return 12;
	if(c=='K') return 13;
	if(c=='0') return 10;
	return c-'0';
}
int main(){
	for(int i=1;i<=13;++i)
		cin>>c1>>c2>>c3>>c4,
		ls[i].push_back(p(rev(c1),0)),
		ls[i].push_back(p(rev(c2),0)),
		ls[i].push_back(p(rev(c3),0)),
		ls[i].push_back(p(rev(c4),0));
	while(cnt){
		int c=ls[13].fr.fi; ls[13].pfr; cp[c]++;
		while(c!=13){
			tmp=ls[c].bk.fi; ls[c].pbk; c=tmp;
			if(c==13) break; ls[c].push_front(p(c,1));
		} 
		cnt--;
	}
	for(int i=1;i<13;++i)
		while(!ls[i].empty())
			cp[ls[i].fr.fi]+=ls[i].fr.se,
			ls[i].pfr;
	for(int i=1;i<=13;++i) cnt+=cp[i]==4;
	cout<<cnt<<endl;
	return 0;
}