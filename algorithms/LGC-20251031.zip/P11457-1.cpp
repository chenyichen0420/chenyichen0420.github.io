#include<bits/stdc++.h>
using namespace std;
#define int long long
int t, n, tim;
struct node {
	int l, r;
	inline bool operator<(const node& v) {
		return l < v.l;
	}
}q[200005];
priority_queue<int>pq;
signed main() {
	ios::sync_with_stdio(0);
	for (cin >> t; t; t--) {
		cin >> n; tim = 0;
		for (int i = 1; i <= n; ++i)
			cin >> q[i].l >> q[i].r, q[i].l += q[i].r;
		sort(q + 1, q + n + 1);
		while (pq.size()) pq.pop();
		for (int i = 1; i <= n; ++i) {
			tim += q[i].r;
			pq.emplace(q[i].r);
			while (tim > q[i].l)
				tim -= pq.top(), pq.pop();
		}
		cout << pq.size() << endl;
	}
}
