#include<bits/stdc++.h>
using namespace std;
int n, m, idx, id[1002][1002];
struct node {
	int l, r; char c;
}q[200005];
vector<int>son[1005 * 1005];
constexpr int
dx[] = { 0,0,1,-1 },
dy[] = { 1,-1,0,0 };
bool dne[1005][1005], cn[1005 * 1005];
int ans;
inline void dfs(int p) {
	cn[p] = 1; ans--;
	for (int sp : son[p])
		if (!cn[sp]) dfs(sp);
}
stack<int>ant;
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m; ans = n * n + 1;
	for (int i = 1; i <= m; ++i)
		cin >> q[i].l >> q[i].r >> q[i].c,
		dne[q[i].l][q[i].r] = 1;
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= n; ++j)
			id[i][j] = ++idx;
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= n; ++j)
			if (!dne[i][j])
				for (int k = 0; k < 4; ++k)
					son[id[i + dx[k]][j + dy[k]]].
					emplace_back(id[i][j]);
	for (int i = 1; i <= m; ++i)
		if (q[i].c == 'L')
			son[id[q[i].l][q[i].r - 1]].
			emplace_back(id[q[i].l][q[i].r]);
		else if (q[i].c == 'R')
			son[id[q[i].l][q[i].r + 1]].
			emplace_back(id[q[i].l][q[i].r]);
		else if (q[i].c == 'U')
			son[id[q[i].l - 1][q[i].r]].
			emplace_back(id[q[i].l][q[i].r]);
		else if (q[i].c == 'D')
			son[id[q[i].l + 1][q[i].r]].
			emplace_back(id[q[i].l][q[i].r]);
	dfs(0);
	for (int i = m; i > 0; i--) {
		ant.emplace(ans);
		//ctrl-z the change of ith operator
		dne[q[i].l][q[i].r] = 0;
		for (int k = 0; k < 4; ++k)
			son[id[q[i].l + dx[k]][q[i].r + dy[k]]].
			emplace_back(id[q[i].l][q[i].r]);
		bool sbh = 0;
		for (int k = 0; k < 4; ++k)
			if (cn[id[q[i].l + dx[k]][q[i].r + dy[k]]])
				sbh = 1;
		if (sbh && !cn[id[q[i].l][q[i].r]]) dfs(id[q[i].l][q[i].r]);
	}
	while (ant.size())
		cout << ant.top() << endl,
		ant.pop();
}