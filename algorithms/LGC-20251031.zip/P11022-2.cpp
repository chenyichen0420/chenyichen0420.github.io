#include<bits/stdc++.h>
using namespace std;
struct node {
	int p, nt;
}e[400005]; int h[200005], cnt;
inline void adde(int l, int r) {
	e[++cnt].nt = h[l]; e[cnt].p = r; h[l] = cnt;
	e[++cnt].nt = h[r]; e[cnt].p = l; h[r] = cnt;
}
bitset<200008>vis;
inline void dfc(int p) {
	if (vis[p]) return; vis[p] = 1;
	for (int i = h[p]; i; i = e[i].nt) dfc(e[i].p);
}
int t, n, m, ans, cp; bitset<200005 << 1> bz; vector<int>an;
int bcc_cnt, dfn[200005], low[200005], ibc[200005];
void tarjan(int x, int in) {
	dfn[x] = low[x] = ++bcc_cnt;
	for (int i = h[x]; i; i = e[i].nt) {
		int v = e[i].p;
		if (dfn[v] == 0) {
			tarjan(v, i ^ 1);
			if (dfn[x] < low[v]) bz[i] = bz[i ^ 1] = 1;
			low[x] = min(low[x], low[v]);
		}
		else if (i != in) low[x] = min(low[x], dfn[v]);
	}
}
void dfs(int x) {
	ibc[x] = ans;
	for (int i = h[x]; i; i = e[i].nt) {
		int v = e[i].p;
		if (ibc[v] || bz[i]) continue;
		dfs(v);
	}
}
inline void dfcol(int p) {
	if (vis[p]) return; vis[p] = 1;
	for (int i = h[p]; i; i = e[i].nt)
		if (ibc[p] != ibc[e[i].p]) dfcol(e[i].p);
}
int main() {
	ios::sync_with_stdio(0);
	cin >> t;
	while (t--) {
		cin >> n >> m; cnt = 1; bcc_cnt = 0;
		ans = 0;
		for (int i = 1; i <= n; ++i) ibc[i] = h[i] = dfn[i] = 0;
		bz.reset();
		for (int i = 1, l, r; i <= m; ++i)
			cin >> l >> r, adde(l, r);
		vis.reset(); dfc(1);
		if (vis.count() != n) {
			cout << "-1\n";
			continue;
		}
		tarjan(1, 0); vis.reset();
		for (int i = 1; i <= n; ++i)
			if (!ibc[i]) ans++, dfs(i);
		dfcol(1);
		if (vis.count() == n) {
			cout << "-1\n";
			continue;
		}
		for (int i = 1; i <= n; ++i) cout << (vis[i] ? 'B' : 'W');
		cout << endl;
	}
}