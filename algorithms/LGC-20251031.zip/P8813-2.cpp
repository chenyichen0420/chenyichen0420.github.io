#include<iostream>
using namespace std;
int main(){
    long long a,b,t;scanf("%lld%lld",&a,&b);t=a;
    if(a==1){
        cout<<1<<endl;
        return 0;
    }
    for(long long i=1ll;i<b;++i){
        a*=t; 
        if(a>1000000000ll){
            cout<<-1<<endl;
            return 0;
        }
    }
    cout<<a<<endl;
    return 0;
}