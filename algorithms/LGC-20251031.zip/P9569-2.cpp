#include<bits/stdc++.h>
using namespace std;
#define pii pair<int,int>
int n, t, a, b; pair<int,int> tt[100005];
inline bool cmp(pii l, pii r) {
	if (l.first == r.first)return l.second < r.second;
	return l.first > r.first;
}
int main() {
	ios::sync_with_stdio(0);
	cin >> n >> t;
	for (int i = 1; i <= n; ++i)
		cin >> b >> a,
		tt[i].first = (t - a) * b, 
		tt[i].second = i;
	sort(tt + 1, tt + n + 1, cmp);
	cout << tt[1].second << endl;
	return 0;
}