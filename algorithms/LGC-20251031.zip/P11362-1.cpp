#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr int mod = 1e9 + 7;
int t, n, m, v, ans;
pair<int, int>vl[100005];
inline int qpow(int l, int r) {
	int ret = 1;
	for (; r; r >>= 1, l = l * l % mod)
		if (r & 1) ret = l * ret % mod;
	return ret;
}
inline int get(int dis) {
	int ret = qpow(v, dis * 2);
	ret -= qpow(v, dis);
	ret += qpow(v, dis - 1);
	return (ret + mod * 2) % mod;
}
signed main() {
	ios::sync_with_stdio(0);
	for (cin >> t; t; t--) {
		cin >> n >> m >> v;
		for (int i = 1; i <= m; ++i)
			cin >> vl[i].first >> vl[i].second;
		sort(vl + 1, vl + m + 1); ans = 1;
		for (int i = 2; i <= m; ++i) {
			if (vl[i].first == vl[i - 1].first)
				if (vl[i].second != vl[i - 1].second)
					ans = 0;
				else continue;
			if (!ans) break;
			ans = ans * get(vl[i].first - vl[i - 1].first) % mod;
		}
		ans = ans * qpow(v, 2 * (vl[1].first - 1)) % mod;
		ans = ans * qpow(v, 2 * (n - vl[m].first)) % mod;
		cout << ans << endl;
	}
}