#include<bits/stdc++.h>
using namespace std;
int n; string t;
int main(){
	cin>>n;
	while(n--){
		cin>>t;int mvn=10,ans=0;
		for(int i=0;i<t.size();++i) ans+=t[i]-'0',mvn=min(mvn,t[i]-'0');
		cout<<ans+9-(mvn!=0)<<endl;
	}
	return 0;
}