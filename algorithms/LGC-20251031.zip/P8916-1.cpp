#include<bits/stdc++.h>
using namespace std;
#define int long long
vector<int>son[305];
int n, v[305], dp[305][2][305][305];
inline void dfs(const int& p, const int& f) {
	for (int i = 0; i != n; ++i)
		for (int j = 0; j != n; ++j)
			dp[p][0][i][j] = (i + 1) * v[p],
			dp[p][1][i][j] = (j + 1) * v[p];
	for (int sp : son[p]) {
		if (sp == f) continue; dfs(sp, p);
		for (int i = 0; i != n; ++i)
			for (int j = 0; j != n; ++j)
				dp[p][0][i][j] += max(dp[sp][0][i + 1][j], dp[sp][1][i][j]),
				dp[p][1][i][j] += max(dp[sp][1][i][j + 1], dp[sp][0][i][j]);
	}
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n;
	for (int i = 1, l, r; i != n; ++i)
		cin >> l >> r,
		son[l].emplace_back(r),
		son[r].emplace_back(l);
	for (int i = 1; i <= n; ++i) cin >> v[i];
	dfs(1, 0); 
	cout << max(dp[1][0][0][0], dp[1][1][0][0]) << endl;
	return 0;
}
//私は猫です