#include<bits/stdc++.h>
using namespace std;
const bool online = 0;
string s1, s2; int sb1, sb2, sb3, n;
int main(){
	if (online)
		freopen("kaucuk.in", "r", stdin),
		freopen("kaucuk.out", "w", stdout);
	ios::sync_with_stdio(0); cin >> n;
	while (n--) {
		cin >> s1 >> s2;
		if (s1 == "section") ++sb1, cout << to_string(sb1) << " " << s2 << endl, sb2 = sb3 = 0;
		else if (s1 == "subsection") ++sb2, cout << to_string(sb1) << "." << to_string(sb2) << " " << s2 << endl, sb3 = 0;
		else ++sb3, cout << to_string(sb1) << "." << to_string(sb2) << "." << to_string(sb3) << " " << s2 << endl;
	}
}