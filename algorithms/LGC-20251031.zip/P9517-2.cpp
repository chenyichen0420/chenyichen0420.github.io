#include<iostream>
using namespace std;
int main() {
	int n, l = 0, r = -1, v;
	cin >> n;
	for (int i = 1; i <= n; ++i) {
		cin >> v;
		if (v) {
			if (!l) l = i;
			r = i;
		}
	}
	cout << r - l + 1 << endl;
}