#include<bits/stdc++.h>
using namespace std;
int n,m; vector<int>v;
inline void dfs(int t){
	if(v.size()+n-t+1<m) return;
	if(v.size()==m){
		for(int i=0;i<m;++i) cout<<v[i]<<" ";
		cout<<endl; return;
	}
	v.push_back(t); dfs(t+1); v.pop_back(); dfs(t+1);
}
int main(){
	cin>>n>>m; dfs(1); return 0;
}