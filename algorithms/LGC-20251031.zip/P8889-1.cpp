#include<bits/stdc++.h>
using namespace std;
#define int long long
int m,n,a[500005],b,cn;
map<int,bool>can;
signed main() {
	scanf("%lld%lld",&m,&n);
	for(register int i=1;i<=m;++i) scanf("%lld",&a[i]);
	for(register int i=1;i<=n;++i) scanf("%lld",&b),can[b]=true;
	register int dis=0;
	for(register int i=1;i<=m;++i)
		if(can[a[i]]){
			if(dis!=0) cn++;
			dis=0;
		}
		else dis++;
	if(dis!=0) cn++;
	printf("%d\n",cn);
	return 0;
}