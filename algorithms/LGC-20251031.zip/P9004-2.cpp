#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online=0;
int n,m,p,ans[16][32],sm[121][121][32];__int128 dp[16][121][121][32],tmp[121][121][32];
inline void mad(int&l,const int r){(l+=r)>=p&&(l-=p);}
signed main(){
    if(online)
        freopen("cp.in","r",stdin),
        freopen("cp.out","w",stdout);
    ios::sync_with_stdio(0);
    time_t st=clock();
    cin>>n>>m>>p;
    dp[1][0][0][1]=1;
    for(int i=2;i<=n;++i){
        memcpy(dp[i],dp[i-1],sizeof tmp);
        memcpy(tmp,dp[i],sizeof tmp);
        int mx=(i-1)*(i-2)/2;
        for(int n3=0;n3<=i*(i-1)/2;++n3)
            for(int n4=1;n4<m;++n4)
                for(int n2=n3;n2<=i*(i-1)/2;++n2)
                    sm[n2][n3][n4]=(n2?sm[n2-1][n3][n4]:0)+tmp[n2][n3][n4],
                    (sm[n2][n3][n4]>=p) && (sm[n2][n3][n4]-=p);
        for(int j=2;j<=i;++j){
            for(int w3=0;w3<=mx;++w3)
                for(int w2=w3;w2<=mx;++w2)
                    for(int w4=1;w4<=w2-w3+1 && w4<m;++w4)
                        if(dp[i][w2][w3][w4])
                            for(int n3=j-1;n3<w3;++n3)
                                for(int n4=1;w4+n4<=m;++n4){
                                    int l=n3+n4-j,r=w3-j,ad;
                                    if(r<l) continue;
                                    ad=sm[r][n3-j+1][n4]-(l?sm[l-1][n3-j+1][n4]:0);
                                    if(ad<0) ad+=p;
                                    dp[i][w2][n3][w4+n4]=(dp[i][w2][n3][w4+n4]+dp[i][w2][w3][w4]*ad);
                                }
            for(int w3=0;w3<=(i-2)*(i-1)/2;++w3)
                for(int w2=w3;w2<=(i-2)*(i-1)/2;++w2)
                    for(int w4=1;w4<=w2-w3+1 && w4<=m;++w4)
                        dp[i][w2+j-1][w3+j-1][w4]+=tmp[w2][w3][w4];
            mx++;
			for(int w3=0;w3<=mx;++w3)
                for(int w2=w3;w2<=mx;++w2)
                    for(int w4=1;w4<=w2-w3+1 && w4<=m;++w4)
						dp[i][w2][w3][w4]%=p;
        }//如果选择进行 log 次合并呢？不好处理。不如优化边界。
    }
    for(int i=1;i<=n;++i)
        for(int j=0;j<=i*(i-1)/2;++j)
            for(int k=0;k<=j;++k)
                for(int l=1;l<=j-k+1 && l<=m;++l)
                    ans[i][l]=(ans[i][l]+dp[i][j][k][l])%p;
    for(int i=1;i<=n;++i, cout<<endl)
        for(int j=1;j<=m;++j)
            cout<<ans[i][j]<<" ";
    cerr<<clock()-st<<endl<<CLOCKS_PER_SEC<<endl;
}
