#include<bits/stdc++.h>
using namespace std;
int n,l,r;
int main(){
	cin>>n>>l>>r;
	int tl=l%n,tr=r%n,fdl=l/n,fdr=r/n;
	if(fdl==fdr)
		cout<<tr<<endl;
	else cout<<n-1<<endl;
	return 0;
}