#include<bits/stdc++.h>
using namespace std;
struct node {
	int l, r;
	node(int li = 0, int ri = 0) {
		l = li, r = ri;
	}
	friend bool operator<(const node& l, const node& r) {
		return l.l < r.l;
	}
}tmp;
int n, a, l, r, mid; set<node>v; set<node>::iterator it;
inline int read() {
	register int r = 0, s = 1; register char c = getchar();
	while (c < '0' || c > '9') { if (c == '-') s = -1; c = getchar(); }
	while (c >= '0' && c <= '9') r = (r << 3) + (r << 1) + (c ^ 48), c = getchar();
	return r * s;
}
inline void write(int x) {
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
	return;
}
inline void writi(int args, char anth_outchar = '\n') {
	write(args); putchar(anth_outchar);
}
signed main() {
	ios::sync_with_stdio(0);
	n = read(), a = read(); v.insert(node(a, 1));
	for (int i = 2; i <= n; ++i) {
		tmp = node(0x3f3f3f3f, 0); a = read();
		it = v.insert(node(a, i)).first;
		if (it-- != v.begin()) tmp = node(a - it->l, it->r);
		it = v.find(node(a, i));
		if (++it != v.end() && it->l - a < tmp.l) tmp = node(it->l - a, it->r);
		writi(tmp.l, ' '); writi(tmp.r);
	}
	return 0;
}