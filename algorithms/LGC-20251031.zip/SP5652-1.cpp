#include<bits/stdc++.h>
using namespace std;
inline int read() {
	int r = 0; char c = getchar();
	while (c < '0' || c>'9') c = getchar();
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar();
	return r;
}
inline void write(int x) {
	if (x > 9) write(x / 10);
	putchar(x % 10 ^ 48);
	return;
}
inline void writi(int args) {
	write(args); putchar(10);
}
struct tree{
	int lc,rc,cn;
}re[1000005*23];
int n,m,l,r,cnt,rt[1000005];
#define mid (l+r>>1)
inline void add(int l,int r,int v,int &np,int op){
	np=++cnt; re[np]=re[op]; re[np].cn++;
	if(l==r) return;
	if(v>mid) add(mid+1,r,v,re[np].rc,re[op].rc);
	else add(l,mid,v,re[np].lc,re[op].lc);
}
inline int que(int l,int r,int v,int np,int op){
	if(l==r) return l;
	if(2*(re[re[np].lc].cn-re[re[op].lc].cn)>v) return que(l,mid,v,re[np].lc,re[op].lc);
	if(2*(re[re[np].rc].cn-re[re[op].rc].cn)>v) return que(mid+1,r,v,re[np].rc,re[op].rc);
	return 0;
}
int main(){
	n=read(); read(); 
	for(int i=1;i<=n;++i)
		add(1,n*5,read(),rt[i],rt[i-1]);
	m=read();
	for(int i=1;i<=m;++i){
		l=read(),r=read();
		int tt=que(1,n*5,r-l+1,rt[r],rt[l-1]);
		if(tt) printf("yes "),writi(tt);
		else printf("no\n");
	}
	return 0;
}