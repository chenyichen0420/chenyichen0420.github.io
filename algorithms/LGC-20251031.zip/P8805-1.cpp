#include<bits/stdc++.h>
using namespace std;
struct IO {
#define mxsz (1 << 21)
	char buf[mxsz], * p1, * p2;
	char pbuf[mxsz], * pp;
	IO() : p1(buf), p2(buf), pp(pbuf) {}
	~IO() { fwrite(pbuf, 1, pp - pbuf, stdout); }
	inline char gc() {
		if (p1 == p2) p2 = (p1 = buf) + fread(buf, 1, mxsz, stdin);
		return p1 == p2 ? ' ' : *p1++;
	}
#ifndef sipt
	inline int read() {
		int r = 0; char c = gc(); while (c < '0' || c>'9') c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return r;
	}
#else
	inline int read() {
		int r = 0; char c = gc(); bool rev = 0;
		while (c < '0' || c>'9') rev |= (c == '-'), c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return rev ? ~r + 1 : r;
	}
#endif
	inline void push(const char& c) {
		if (pp - pbuf == mxsz) fwrite(pbuf, 1, mxsz, stdout), pp = pbuf;
		*pp++ = c;
	}
	inline void write(int x) {
		static char sta[22]; int top = 0;
		do sta[top++] = x % 10, x /= 10; while (x);
		while (top) push(sta[--top] ^ 48);
	}
	inline void write(int x, char opc) {
#ifdef sopt
		if (x < 0) push('-'), x = ~x + 1;
#endif
		write(x), push(opc);
	}
} io;
int n, m, s, d[500005], fa[500005][20], dis[500005], ans;
vector<int>son[500005];
inline void dfs(int p, int f) {
	dis[p] = dis[f] + son[p].size();
	fa[p][0] = f; d[p] = d[f] + 1;
	for (int i = 1; i <= 19; ++i)
		fa[p][i] = fa[fa[p][i - 1]][i - 1];
	for (int sp : son[p])
		if (sp != f) dfs(sp, p);
}
inline int lca(int l, int r) {
	if (d[l] < d[r]) swap(l, r);
	for (int i = 19; i >= 0; i--)
		(d[r] <= d[fa[l][i]]) && (l = fa[l][i]);
	if (l == r) return l;
	for (int i = 19; i >= 0; i--)
		(fa[l][i] != fa[r][i]) && (l = fa[l][i], r = fa[r][i]);
	return fa[l][0];
}
signed main() {
	ios::sync_with_stdio(0);
	n = io.read(); m = io.read();
	for (int i = 1, l, r; i != n; ++i)
		l = io.read(), r = io.read(),
		son[l].emplace_back(r),
		son[r].emplace_back(l);
	dfs(1, 0);
	for (int i = 1, l, r, lc; i <= m; ++i)
		l = io.read(), r = io.read(), lc = lca(l, r),
		io.write(dis[l] + dis[r] - dis[lc] - dis[fa[lc][0]], '\n');
	return 0;
}