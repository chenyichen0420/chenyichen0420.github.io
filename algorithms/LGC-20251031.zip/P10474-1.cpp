#include<bits/stdc++.h>
using namespace std;
using hss = unsigned long long;
constexpr hss p = 131, p2 = 13331;
hss vc[1005][1005], vr[1005][1005], q[1005], q2[1005];
int n, m, a, b, k; char s[1005][1005]; unordered_set<hss>ap;
inline hss genc(int x, int y) {
	return vc[x][y] - vc[x][y - b] * q[b];
}
inline hss genr(int x, int y) {
	return vr[x][y] - vr[x - a][y] * q2[a];
}
int main() {
	ios::sync_with_stdio(0);
	cin >> n >> m >> a >> b;
	for (int i = q[0] = 1; i <= 1e3; ++i) q[i] = q[i - 1] * p;
	for (int i = q2[0] = 1; i <= 1e3; ++i) q2[i] = q2[i - 1] * p2;
	for (int i = 1; i <= n; ++i) {
		cin >> (s[i] + 1);
		for (int j = 1; j <= m; ++j)
			vc[i][j] = (vc[i][j - 1] * p + s[i][j]);
	}
	for (int i = 1; i <= n; ++i)
		for (int j = b; j <= m; ++j)
			vr[i][j] = (vr[i - 1][j] * p2 + genc(i, j));
	for (int i = a; i <= n; ++i)
		for (int j = b; j <= m; ++j)
			ap.emplace(genr(i, j));
	for (cin >> k; k; k--) {
		for (int i = 1; i <= a; ++i) {
			cin >> (s[i] + 1);
			for (int j = 1; j <= b; ++j)
				vc[i][j] = (vc[i][j - 1] * p + s[i][j]);
		}
		for (int i = 1; i <= a; ++i)
			vr[i][b] = (vr[i - 1][b] * p2 + genc(i, b));
		cout << (ap.count(genr(a, b))) << endl;
	}
}