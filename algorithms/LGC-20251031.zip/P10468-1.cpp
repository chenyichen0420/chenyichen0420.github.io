#include<bits/stdc++.h>
using namespace std;
int l1, r1, l2, r2, n, tpl, tpr, sz; unsigned int pv[1000001] = { 1 }, qh[1000001];
char dna[1000001];
inline static void out(bool typ) {
	if (typ) putchar('Y'), putchar('e'), putchar('s'), putchar('\n');
	else putchar('N'), putchar('o'), putchar('\n');
}
inline static int read() {
	int r = 0; char c = getchar();
	while (c < '0' || c>'9') c = getchar();
	while (c >= '0' && c <= '9') r = (r << 3) + (r << 1) + (c ^ 48), c = getchar();
	return r;
}
int main() {
	char c;
	while ((c = getchar()) != 10) dna[sz++] = c;
	n = read();
	for (register int i = 1; i <= sz; ++i)
		qh[i] = qh[i - 1] * 13331 + dna[i - 1],
		pv[i] = pv[i - 1] * 13331;
	while (n--)
		l1 = read(), r1 = read(), l2 = read(), r2 = read(),
		tpl = qh[r1] - qh[l1 - 1] * pv[r1 - l1 + 1],
		tpr = qh[r2] - qh[l2 - 1] * pv[r2 - l2 + 1],
		out(tpl == tpr);
	return 0;
}