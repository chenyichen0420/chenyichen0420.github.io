#include<bits/stdc++.h>
using namespace std;
string s; int n, sa[1000005], rk[1000005 * 2], h[1000005];
int bc[1000005], oldrk[1000005 * 2], oldsa[1000005];
signed main() {
	ios::sync_with_stdio(0);
	cin >> s; n = s.size(); s = ' ' + s;
	for (int i = 1; i <= n; ++i) s[i] -= 'a' - 1;
	for (int i = 1; i <= n; ++i) ++bc[rk[i] = s[i]];
	for (int i = 1; i <= 26; ++i) bc[i] += bc[i - 1];
	for (int i = n; i >= 1; i--) sa[bc[rk[i]]--] = i;
	memcpy(oldrk + 1, rk + 1, sizeof(int) * n);
	for (int i = 1, p = 0; i <= n; ++i)
		rk[sa[i]] = (p += (oldrk[sa[i]] != oldrk[sa[i - 1]]));
	for (int w = 1; w < n; w <<= 1) {
		memset(bc, 0, sizeof bc);
		memcpy(oldsa + 1, sa + 1, sizeof(int) * n);
		for (int i = 1; i <= n; ++i) ++bc[rk[oldsa[i] + w]];
		for (int i = 1; i <= n; ++i) bc[i] += bc[i - 1];
		for (int i = n; i >= 1; i--) sa[bc[rk[oldsa[i] + w]]--] = oldsa[i];

		memset(bc, 0, sizeof bc);
		memcpy(oldsa + 1, sa + 1, sizeof(int) * n);
		for (int i = 1; i <= n; ++i) ++bc[rk[oldsa[i]]];
		for (int i = 1; i <= n; ++i) bc[i] += bc[i - 1];
		for (int i = n; i >= 1; i--) sa[bc[rk[oldsa[i]]]--] = oldsa[i];

		memcpy(oldrk + 1, rk + 1, sizeof(int) * n);
		for (int i = 1, p = 0; i <= n; ++i)
			rk[sa[i]] = (p += (oldrk[sa[i]] != oldrk[sa[i - 1]] ||
				oldrk[sa[i] + w] != oldrk[sa[i - 1] + w]));
	}
	for (int i = 1; i <= n; ++i) cout << sa[i] - 1 << " "; 
	cout << endl; //O(nlogn) 求 sa
	for (int i = 1, k = 0; i <= n; ++i) {
		if (k) k--;
		if (rk[i] == 1) continue;
		int j = sa[rk[i] - 1];
		while (s[i + k] == s[j + k]) k++;
		h[rk[i]] = k;
	}
	for (int i = 1; i <= n; ++i) cout << h[i] << " ";
	cout << endl; //O(n) 求 height
}