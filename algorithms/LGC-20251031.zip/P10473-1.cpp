#include<bits/stdc++.h>
using namespace std;
string s, s1;
#define int long long
struct token {
	int val; short pri; char op; bool typ;
	token(bool it, int vi, short ip, char io) {
		val = vi, pri = ip, op = io, typ = it;
	}
}; vector<token>tk, gv;
inline bool isdig(char c) {
	return (c >= '0' && c <= '9');
}
inline int qpow(int a, int b) {
	if (a == 1) return 1;
	if (b == 0) return 1;
	if (a == -1) {
		if (b & 1) return -1;
		return 1;
	}
	if (b < 0) return 0;
	int tmp = 1;
	while (b) {
		if (b % 2) tmp *= a;
		a *= a; b /= 2;
	}
	return tmp;
}
void toke() {
	int tmp = 0, flg = 1;
	for (int i = 0; i < s.size(); ++i) {
		if (isdig(s[i])) {
			tmp = 0;
			while (isdig(s[i])) tmp = tmp * 10 + (s[i++] ^ 48);
			tk.push_back(token(1, tmp * flg, 0, '\0')); flg = 1;
			i--;
		}
		else {
			if (s[i] == '(') tk.push_back(token(0, 0, 0, s[i]));
			else if (s[i] == '+') tk.push_back(token(0, 0, 1, s[i]));
			else if (s[i] == '-'){
				if (!isdig(s[i - 1]) && s[i - 1] != ')') flg = -1;
				else tk.push_back(token(0, 0, 1, s[i]));
			}
			else if (s[i] == '*' || s[i] == '/') tk.push_back(token(0, 0, 2, s[i]));
			else if (s[i] == '^') tk.push_back(token(0, 0, 3, s[i]));
			else tk.push_back(token(0, 0, 4, s[i]));
		}
	}
}
void back() {
	stack<token>st;
	for (int i = 0; i < tk.size(); ++i)
		if (tk[i].typ) gv.push_back(tk[i]);
		else if (tk[i].op == ')') {
			while (st.top().op != '(') gv.push_back(st.top()), st.pop();
			st.pop();
		}
		else if (tk[i].op == '(') st.push(tk[i]);
		else {
			while (!st.empty() && st.top().pri >= tk[i].pri)
				gv.push_back(st.top()), st.pop();
			st.push(tk[i]);
		}
	while (st.size()) gv.push_back(st.top()), st.pop();
}
int solve() {
	stack<int>sv; int a, b;
	for (int i = 0; i < gv.size(); ++i)
		if (gv[i].typ) sv.push(gv[i].val);
		else {
			a = sv.top(); sv.pop();
			b = sv.top(); sv.pop();
			if (gv[i].op == '+') sv.push(a + b);
			else if (gv[i].op == '-') sv.push(b - a);
			else if (gv[i].op == '*') sv.push(b * a);
			else if (gv[i].op == '/') sv.push(b / a);
			else sv.push(qpow(b, a));
		}
	return sv.top();
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> s; stack<char>st; int cnt = 0;
	for (int i = 0; i < s.size(); ++i)
		if (s[i] == '(') cnt++;
		else if (s[i] == ')') cnt--;
	if (cnt > 0) for (int i = 1; i <= cnt; ++i) s += ')';
	else for (int i = 1; i <= -cnt; ++i) s = '(' + s;
	s = '(' + s + ')';
	toke(); back(); 
	cout << solve() << endl;
	return 0;
}
//hack:1+(2^10)^(1^1)-1000