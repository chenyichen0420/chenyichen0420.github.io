#include<bits/stdc++.h>
using namespace std;
int n, a[100005], pt;
int main() {
	ios::sync_with_stdio(0);
	cin >> n;
	for (int i = 1; i <= n; ++i) cin >> a[i];
	sort(a + 1, a + n + 1);
	for (int i = 2; i <= n; ++i)
		if (a[i] > a[pt + 1]) pt++;
	cout << n - pt << endl;
}