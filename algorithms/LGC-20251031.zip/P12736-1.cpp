#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m,l1,l2,ln,ans,c;
struct mss{
    int f[500005];
    mss(){ iota(f,f+500001,0); }
    inline int find(int p){
        return f[p]==p?p:f[p]=find(f[p]);
    }
    inline void merge(int l,int r){
        f[find(l)]=find(r);
    }
}ms[20];
signed main() {
	ios::sync_with_stdio(0);
    cin>>n>>m;
    for(int i=1;i<=m;++i){
        cin>>l1>>l2>>ln;
        for(int j=19;j>=0;j--)
            if(ln>>j&1)
                ms[j].merge(l1,l2),
                l1+=1ll<<j,l2+=1ll<<j;
    }
    for(int j=19;j;j--)
        for(int i=1;i+(1ll<<j)-1<=n;++i)
            ms[j-1].merge(ms[j].find(i),i),
            ms[j-1].merge(ms[j].find(i)+(1ll<<j-1),i+(1ll<<j-1));
    for(int i=1;i<=n;++i) c+=ms[0].find(i)==i;
    cout<<c<<endl;
}