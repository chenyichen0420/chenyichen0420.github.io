#include<bits/stdc++.h>
using namespace std;
long long l,r; int ans=1;
inline int sol(long long val){
	int tmp=0;
	while(val){
		int k=val%10; val/=10;
		if(k==0||k==6||k==9) tmp+=6;
		else if(k==1) tmp+=2;
		else if(k==2||k==3||k==5) tmp+=5;
		else if(k==4) tmp==4;
		else if(k==7) tmp+=3;
		else tmp+=7;
	}
	return tmp;
}
signed main() {
	cin>>l>>r;
	for(long long i=l;i<=l+10000000&&i<r;++i){
		if(sol(i)==sol(i+1)){
			cout<<2<<endl;
			return 0;
		}
	}
	cout<<1<<endl;
	return 0;
}