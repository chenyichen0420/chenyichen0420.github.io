#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr int mod = 1e9 + 7, szv = 1e6 + 5;
vector<int>son[szv];
int n, siz[szv], ans[szv], jc, ny[szv];
inline void dfsz(const int& p, const int& f) {
	siz[p] = 1;
	for (int sp : son[p])
		if (sp != f) 
			dfsz(sp, p), 
			siz[p] += siz[sp];
	ans[1] = ans[1] * ny[siz[p]] % mod;
}
inline void dfsa(const int& p, const int& f) {
	if (f) ans[p] = ans[f] * ny[n - siz[p]] % mod * siz[p] % mod;
	for (int sp : son[p]) if (sp != f) dfsa(sp, p);
}
inline int qpow(int a) {
	int tmp = 1, b = mod - 2;
	while (b) {
		if (b & 1) tmp *= a, tmp %= mod;
		a *= a; a %= mod; b >>= 1;
	}
	return tmp;
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n; jc = 1;
	for (int i = 1, l, r; i < n; ++i)
		cin >> l >> r,
		son[l].emplace_back(r),
		son[r].emplace_back(l);
	for (int i = 2; i <= n; ++i) jc = jc * i % mod;
	for (int i = n; i >= 0; i--) ny[i] = qpow(i);
	ans[1] = jc; dfsz(1, 0); dfsa(1, 0);
	for (int i = 1; i <= n; ++i) cout << ans[i] << endl;
	return 0;
}
//私は猫です