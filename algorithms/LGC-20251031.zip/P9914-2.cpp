#include<bits/stdc++.h>
#include<unordered_map>
using namespace std;
int n, m, a, b, ans;
unordered_map<long long, int>vis;
int main() {
	ios::sync_with_stdio(0);
	cin >> n >> m;
	for (int i = 1; i <= n; ++i) cin >> a, vis[a * 1ll * i] += (a != 0);
	for (int i = 1; i <= m; ++i) cin >> b, ans += vis[b * 1ll * i];
	cout << ans << endl;
	return 0;
}