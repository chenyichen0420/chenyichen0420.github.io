#include<bits/stdc++.h>
using namespace std;
#define int long long
int t,n;
signed main(){
    cin>>t;
    while(t--){
        cin>>n;
        if(n%2) cout<<"Yes\n";
        else cout<<"No\n";
    }
}