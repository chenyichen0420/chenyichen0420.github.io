#include<bits/stdc++.h>
using namespace std;
struct rec { int x, c, l, r, t1, t2; }cm[18][230][18][18][2][2], mp;
int n, m, k, a[18][18], dp[18][230][18][18][2][2], sm[18][18], mx;
vector<pair<int, int>>ans;
inline const rec& lst(const rec& p) { return cm[p.x][p.c][p.l][p.r][p.t1][p.t2]; }
inline void back(const rec& l) {
	for (int i = l.r; i >= l.l; i--) ans.emplace_back(make_pair(l.x, i));
	if (l.c != l.r - l.l + 1) back(lst(l));
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m >> k;
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j)
			cin >> a[i][j], sm[i][j] = sm[i][j - 1] + a[i][j];
	memset(dp, 0xcf, sizeof dp);
	for (int i = 0; i <= n; ++i) dp[i][0][0][0][1][0] = 0;
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= k; ++j)
			for (int l = 1; l <= m; ++l)
				for (int r = l; r <= m; ++r) {
					const int dl = sm[i][r] - sm[i][l - 1];
					if (j >= r - l + 1) {
						int& ret = dp[i][j][l][r][1][0], val;
						rec& cp = cm[i][j][l][r][1][0];
						if (j == r - l + 1) {
							if ((val = dp[i - 1][0][0][0][1][0] + dl) > ret)
								ret = val, cp = { i - 1,0,0,0,1,0 };
						}
						else{
							for (int p = l; p <= r; ++p)
								for (int q = p; q <= r; ++q)
									if ((val = dp[i - 1][j - (r - l + 1)][p][q][1][0] + dl) > ret)
										ret = val, cp = { i - 1,j - (r - l + 1),p,q,1,0 };
						}
						if (j == k && ret > mx) mx = ret, mp = { i,j,l,r,1,0 };
					}//1.0
					if (j >= r - l + 1) {
						int& ret = dp[i][j][l][r][1][1], val;
						rec& cp = cm[i][j][l][r][1][1];
						for (int p = l; p <= r; ++p)
							for (int q = r; q <= m; ++q)
								for (int t = 0; t != 2; ++t)
									if ((val = dp[i - 1][j - (r - l + 1)][p][q][1][t] + dl) > ret)
										ret = val, cp = { i - 1,j - (r - l + 1),p,q,1,t };
						if (j == k && ret > mx) mx = ret, mp = { i,j,l,r,1,1 };

					}//1.1
					if (j >= r - l + 1) {
						int& ret = dp[i][j][l][r][0][0], val;
						rec& cp = cm[i][j][l][r][0][0];
						for (int p = 1; p <= l; ++p)
							for (int q = l; q <= r; ++q)
								for (int t = 0; t != 2; ++t)
									if ((val = dp[i - 1][j - (r - l + 1)][p][q][t][0] + dl) > ret)
										ret = val, cp = { i - 1,j - (r - l + 1),p,q,t,0 };
						if (j == k && ret > mx) mx = ret, mp = { i,j,l,r,0,0 };
					}//0.0
					if (j >= r - l + 1) {
						int& ret = dp[i][j][l][r][0][1], val;
						rec& cp = cm[i][j][l][r][0][1];
						for (int p = 1; p <= l; ++p)
							for (int q = r; q <= m; ++q)
								for (int tp = 0; tp != 2; ++tp)
									for (int tq = 0; tq != 2; ++tq)
										if ((val = dp[i - 1][j - (r - l + 1)][p][q][tp][tq] + dl) > ret)
											ret = val, cp = { i - 1,j - (r - l + 1),p,q,tp,tq };
						if (j == k && ret > mx) mx = ret, mp = { i,j,l,r,0,1 };
					}//0.1
				}
	if (!mx) return cout << "Oil : 0\n", 0;
	cout << "Oil : " << mx << endl; back(mp);
	reverse(ans.begin(), ans.end());
	for (const auto& v : ans) cout << v.first << " " << v.second << endl;
}