#include<bits/stdc++.h>
using namespace std;
#define int long long
int n, m, vx[1005][1005], vy[1005][1005], vz[1005][1005], ans;
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m;
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= n; ++j)
			vx[i][j] = vy[i][j] = vz[i][j] = n;
	for (int i = 1, a, b, c; i <= m; ++i) {
		cin >> a >> b >> c;
		a++, b++, c++;
		ans += (!--vx[a][b]);
		ans += (!--vy[a][c]);
		ans += (!--vz[b][c]);
		cout << ans << endl;
	}
}