#include<bits/stdc++.h>
using namespace std;
#define int long long
int n, m, a[1000005];
int t, l, r;
signed main() {
	ios::sync_with_stdio(0);
	cin >> t;
	while (t--)
		cin >> l >> r,
		cout << (r == 1 ? "YES" : "NO") << endl;
	/*
	cin >> n >> m;
	for (int i = 1; i <= n; ++i) cin >> a[i];
	if (n & 1) a[++n] = 0;
	*/
	return 0;
}