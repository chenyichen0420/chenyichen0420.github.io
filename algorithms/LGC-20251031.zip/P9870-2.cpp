#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 0;
inline int read() {
	int r = 0; char c = getchar();
	while (c < '0' || c>'9') c = getchar();
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar();
	return r;
}
struct node {
	int mi, ma;
	node(int ii = 0, int ai = 0) :mi(ii), ma(ai) {};
}tmp;
int v, n, m, k, a[500005], b[500005], ta[500005], tb[500005], p1, p2, l, r;
node pmx[500005], pmy[500005], smx[500005], smy[500005];
inline bool check(const int& px, const int& py) {
	if (px == 1 || py == 1) return 1;
	node xl = pmx[px - 1], yl = pmy[py - 1];
	if (a[xl.mi] < b[yl.mi]) return check(xl.mi, py);
	if (b[yl.ma] > a[xl.ma]) return check(px, yl.ma);
	return 0;
}
inline bool check2(const int& px, const int& py, const int& n, const int& m) {
	if (px == n || py == m) return 1;
	node xl = smx[px + 1], yl = smy[py + 1];
	if (a[xl.mi] < b[yl.mi]) return check2(xl.mi, py, n, m);
	if (b[yl.ma] > a[xl.ma]) return check2(px, yl.ma, n, m);
	return 0;
}
inline bool solve(int n, int m) {
	if (a[1] >= b[1]) return 0;
	pmx[1] = pmy[1] = node(1, 1);
	smx[n] = node(n, n); smy[m] = node(m, m);
	for (int i = 2; i <= n; ++i)
		pmx[i] = node(a[i] < a[pmx[i - 1].mi] ? i : pmx[i - 1].mi,
			a[i] > a[pmx[i - 1].ma] ? i : pmx[i - 1].ma);
	for (int i = 2; i <= m; ++i) {
		if (b[i] < b[pmy[i - 1].mi])
			tmp.mi = i, tmp.ma = pmy[i - 1].ma;
		else if (b[i] > b[pmy[i - 1].ma])
			tmp.mi = pmy[i - 1].mi, tmp.ma = i;
		else tmp = pmy[i - 1];
		pmy[i] = tmp;
	}
	for (int i = n - 1; i > 0; --i) {
		if (a[i] < a[smx[i + 1].mi])
			tmp.mi = i, tmp.ma = smx[i + 1].ma;
		else if (a[i] > a[smx[i + 1].ma])
			tmp.mi = smx[i + 1].mi, tmp.ma = i;
		else tmp = smx[i + 1];
		smx[i] = tmp;
	}
	for (int i = m - 1; i > 0; --i) {
		if (b[i] < b[smy[i + 1].mi])
			tmp.mi = i, tmp.ma = smy[i + 1].ma;
		else if (b[i] > b[smy[i + 1].ma])
			tmp.mi = smy[i + 1].mi, tmp.ma = i;
		else tmp = smy[i + 1];
		smy[i] = tmp;
	}
	node xl = pmx[n], yl = pmy[m];
	if (a[xl.mi] >= b[yl.mi] || b[yl.ma] <= a[xl.ma]) return 0;
	return check(xl.mi, yl.ma) && check2(xl.mi, yl.ma, n, m);
}
signed main() {
	if (online)
		freopen("expand.in", "r", stdin),
		freopen("expand.out", "w", stdout);
	ios::sync_with_stdio(0);
	read(); n = read(); m = read(); k = read();
	for (int i = 1; i <= n; ++i) ta[i] = read();
	for (int i = 1; i <= m; ++i) tb[i] = read();
	memcpy(a, ta, sizeof a);
	memcpy(b, tb, sizeof b);
	bool ty = solve(n, m); swap(a, b);
	putchar((ty || solve(m, n)) ^ 48);
	for (int i = 1; i <= k; ++i) {
		memcpy(a, ta, sizeof a);
		memcpy(b, tb, sizeof b);
		p1 = read(); p2 = read();
		for (int j = 1; j <= p1; ++j)
			l = read(), r = read(), a[l] = r;
		for (int j = 1; j <= p2; ++j)
			l = read(), r = read(), b[l] = r;
		bool ty = solve(n, m); swap(a, b);
		putchar((ty || solve(m, n)) ^ 48);
	}
	return 0;
}