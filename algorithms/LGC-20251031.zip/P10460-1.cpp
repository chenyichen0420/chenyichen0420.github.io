#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int r=0; char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') r=(r<<3)+(r<<1)+(c^48),c=getchar();
	return r;
}
inline void write(int x){
	if(x>9) write(x/10);
	putchar(x%10+'0');
	return;
}
inline void wrote(int args){
	write(args); putchar('\n');
}
inline void writen(string ss="There's no weakness.\n"){
	for(int i=0;i<ss.size();++i) putchar(ss[i]);
}
struct node{
	int s,t,d;
	node(int a=0,int b=0,int c=0){
		s=a,t=b,d=c;
	}
}v[200005];
int t,n,l,r,mid,tmp;
inline void reed(node& l){
	l.s=read(); l.t=read(); l.d=read();
}
inline int gvl(int vl,int i){
	if(vl<v[i].s) return 0;
	if(vl>=v[i].t) return (v[i].t-v[i].s)/v[i].d+1;
	return (vl-v[i].s)/v[i].d+1;
}
inline bool check(int val){
	tmp=0;
	for(int i=1;i<=n;++i)
		tmp+=gvl(val,i);
	return tmp&1;
}
inline int solve(int val){
	tmp=0;
	for(int i=1;i<=n;++i)
		tmp+=(val>=v[i].s&&val<=v[i].t&&((val-v[i].s)%v[i].d==0));
	return tmp;
}
signed main(){
	t=read();
	while(t--){
		n=read();
		for(int i=1;i<=n;++i) reed(v[i]);
		l=0,r=(1ll<<31)-1;
		while(l<r){
			mid=(long long)l+r>>1;
			if(check(mid)) r=mid;
			else l=mid+1;
		}
		if(l==(1ll<<31)-1&&!check(l)) writen();
		else write(l),putchar(' '),wrote(solve(l));
	}
	return 0;
}