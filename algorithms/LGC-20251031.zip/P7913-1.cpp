#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 0;
//#define BRF
struct node { int l, r; }v1[100005], v2[100005];
int n, m1, m2, a1[100005], a2[100005], vi, ans;
set<int>s; unordered_map<int, int>id;
inline bool cmp(const node& l, const node& r) {
	return l.l < r.l;
}
vector<int>v;
inline void tmin(int& l, const int& r) {
	(l > r) && (l = r);
}
class seg_tree {
	struct node {
		int l, r, v;
	}re[100005 << 4];
	inline void pup(int p) {
		re[p].v = min(re[p << 1].v, re[p << 1 | 1].v);
	}
public:
	inline void build(int l, int r, int p) {
		re[p].l = l, re[p].r = r;
		if (re[p].l == re[p].r) {
			re[p].v = 0x3f3f3f3f; return;
		}
		build(l, l + r >> 1, p << 1);
		build((l + r >> 1) + 1, r, p << 1 | 1);
		pup(p);
	}
	inline int que(int rp, int p) {
		if (re[p].r <= rp || re[p].l == re[p].r) return re[p].v;
		int ret = que(rp, p << 1);
		if (re[p << 1].r < rp) tmin(ret, que(rp, p << 1 | 1));
		return ret;
	}
	inline void chg(int ps, int v, int p) {
		if (re[p].l == re[p].r) {
			re[p].v = v; return;
		}
		if (ps <= re[p << 1].r) chg(ps, v, p << 1);
		else chg(ps, v, p << 1 | 1); pup(p);
	}
}st;
signed main() {
	if (online)
		freopen("airport.in", "r", stdin),
		freopen("airport.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin >> n >> m1 >> m2;
	for (int i = 1; i <= m1; ++i)
		cin >> v1[i].l >> v1[i].r,
		s.emplace(v1[i].l),
		s.emplace(v1[i].r);
	for (int vp : s) id[vp] = ++vi;
	for (int i = 1; i <= m1; ++i)
		v1[i].l = id[v1[i].l],
		v1[i].r = id[v1[i].r];
	sort(v1 + 1, v1 + m1 + 1, cmp); st.build(1, m1 * 3, 1);
	v.emplace_back(v1[1].r); st.chg(v1[1].r, 0, 1); a1[1]++;
	for (int i = 2; i <= m1; ++i) {
#ifdef BRF
		int cn = 0;
		for (int j = 0; j != v.size(); ++j)
			if (v[j] < v1[i].l) {
				cn = j + 1; v[j] = v1[i].r;
				break;
			}
		if (!cn) v.emplace_back(v1[i].r), cn = v.size();
		a1[cn]++; if (v.size() > n) v.pop_back();
#else
		int cn = st.que(v1[i].l, 1);
		if (cn == 0x3f3f3f3f) {
			v.emplace_back(v1[i].r); cn = v.size() - 1;
			st.chg(v1[i].r, v.size() - 1, 1);
		}
		else {
			st.chg(v[cn], 0x3f3f3f3f, 1);
			v[cn] = v1[i].r; st.chg(v1[i].r, cn, 1);
		}
		a1[cn + 1]++;
#endif
	}
	for (int i = 1; i <= n; ++i) a1[i] += a1[i - 1];
	s.clear(); vi = 0; id.clear(); v.clear();
	for (int i = 1; i <= m2; ++i)
		cin >> v2[i].l >> v2[i].r,
		s.emplace(v2[i].l),
		s.emplace(v2[i].r);
	for (int vp : s) id[vp] = ++vi;
	for (int i = 1; i <= m2; ++i)
		v2[i].l = id[v2[i].l],
		v2[i].r = id[v2[i].r];
	sort(v2 + 1, v2 + m2 + 1, cmp); st.build(1, m2 * 3, 1);
	v.emplace_back(v2[1].r); st.chg(v2[1].r, 0, 1); a2[1]++;
	for (int i = 2; i <= m2; ++i) {
#ifdef BRF
		int cn = 0;
		for (int j = 0; j != v.size(); ++j)
			if (v[j] < v2[i].l) {
				cn = j + 1; v[j] = v2[i].r;
				break;
			}
		if (!cn) v.emplace_back(v2[i].r), cn = v.size();
		a2[cn]++; if (v.size() > n) v.pop_back();
#else
		int cn = st.que(v2[i].l, 1);
		if (cn == 0x3f3f3f3f) {
			v.emplace_back(v2[i].r); cn = v.size() - 1;
			st.chg(v2[i].r, v.size() - 1, 1);
		}
		else {
			st.chg(v[cn], 0x3f3f3f3f, 1);
			v[cn] = v2[i].r; st.chg(v2[i].r, cn, 1);
		}
		a2[cn + 1]++;
#endif
	}
	for (int i = 1; i <= n; ++i) a2[i] += a2[i - 1];

	for (int i = 0; i <= n; ++i) ans = max(ans, a1[i] + a2[n - i]);
	cout << ans << endl;
}